---
name: commands-base
description: Shared base for the Claude video commands (/orbit, /liquid-glass-graph, /match-cut...). A Remotion project with every effect plus the cutout script. Not used on its own; every command skill uses it.
---

# Commands base

`project/` is a Remotion project (1080x1920, 30 fps) with every effect in `src/fx/` and `cutout.py` to cut the person out with a transparent background (rembg, u2net_human_seg model, ProRes 4444).

When a command skill asks for it, copy `project/` to `./commands-fx` in the user's folder and run `npm install`. If it already exists, reuse it.
