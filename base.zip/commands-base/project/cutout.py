# Cuts the person out of a clip with rembg and writes a ProRes 4444 with alpha.
# Alpha gets a temporal median, interior hole fill and a small average so the edge
# does not flicker and the body never goes see-through.
import subprocess, sys, os, glob
import numpy as np
from PIL import Image
from rembg import remove, new_session

SRC = sys.argv[1]
OUT = sys.argv[2]
WORK = sys.argv[3]
FPS = sys.argv[4] if len(sys.argv) > 4 else "24"
# u2net_human_seg is trained on people only: it keeps a dark t-shirt solid where it
# meets a dark desk, where plain u2net goes semi-transparent.
MODEL = sys.argv[5] if len(sys.argv) > 5 else "u2net_human_seg"

frames = os.path.join(WORK, "in")
cut = os.path.join(WORK, "cut")
os.makedirs(frames, exist_ok=True)
os.makedirs(cut, exist_ok=True)

# 1. explode to png
subprocess.run(
    ["ffmpeg", "-y", "-i", SRC, os.path.join(frames, "f_%04d.png")],
    check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
)
files = sorted(glob.glob(os.path.join(frames, "f_*.png")))
print(f"{len(files)} frames", flush=True)

# 2. matte each frame, keep the alpha channels so they can be smoothed after
session = new_session(MODEL)
rgbs, alphas = [], []
for i, f in enumerate(files):
    im = Image.open(f).convert("RGB")
    out = remove(im, session=session)  # RGBA
    arr = np.array(out)
    rgbs.append(arr[:, :, :3])
    alphas.append(arr[:, :, 3].astype(np.float32))
    if (i + 1) % 20 == 0:
        print(f"  matted {i+1}/{len(files)}", flush=True)

# 3. temporal clean-up on alpha only.
#    a) 5 frame median: a hole that appears in a single frame is voted out,
#       where a plain mean only dims it into a see-through patch.
#    b) fill the holes inside the silhouette (chest next to the mic, the gap
#       between an arm and the body): anything fully enclosed by the person is person.
#    c) 3 frame mean on top, so the edge itself still does not crawl.
from scipy.ndimage import binary_fill_holes
n = len(alphas)
med = []
for i in range(n):
    lo, hi = max(0, i - 2), min(n, i + 3)
    med.append(np.median(alphas[lo:hi], axis=0))
filled = []
for a in med:
    solid = binary_fill_holes(a > 128)
    filled.append(np.where(solid, np.maximum(a, 255.0), a))
smooth = []
for i in range(n):
    lo, hi = max(0, i - 1), min(n, i + 2)
    smooth.append(np.mean(filled[lo:hi], axis=0))

for i, f in enumerate(files):
    a = np.clip(smooth[i], 0, 255).astype(np.uint8)
    rgba = np.dstack([rgbs[i], a])
    Image.fromarray(rgba, "RGBA").save(os.path.join(cut, os.path.basename(f)))

# 4. rebuild with alpha, carry the original audio over
subprocess.run(
    ["ffmpeg", "-y", "-framerate", FPS, "-i", os.path.join(cut, "f_%04d.png"),
     "-i", SRC, "-map", "0:v", "-map", "1:a?",
     "-c:v", "prores_ks", "-profile:v", "4444", "-pix_fmt", "yuva444p10le",
     "-c:a", "pcm_s16le", OUT],
    check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
)
print("done ->", OUT)
