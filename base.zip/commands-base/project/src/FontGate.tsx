export { FontGate } from "./kit/text";
