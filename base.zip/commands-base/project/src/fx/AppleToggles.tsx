/**
 * /apple-ui-toggles — clean iOS rows, each one its own soft pill (like Settings on iPhone),
 * stacked in front of the chest. The switches flip on one line at a time.
 *   4-30   rows rise in one by one (stagger), soft shadows under each
 *   30..   each flip: knob travels with a stretch, track fills green from the knob,
 *          the row's label darkens, the row lifts a few px and settles, tiny camera kick
 *   after the last: a "Done" pill drops in under the stack, the camera pushes in
 */
import React from "react";
import { interpolate, useCurrentFrame } from "remotion";
import { EXPO_OUT, BACK_OUT, SOFT, p } from "../kit";
import { ClipProps, Scene, SANS } from "./common";

export const TOGGLES_DUR = 100;

const ROWS = ["One prompt", "Paste into Claude", "Pick the effect", "Perfect result"];
const FLIPS = [28, 40, 52, 64];
const GREEN = "#34C759";

const Switch: React.FC<{ t: number; travel: number }> = ({ t, travel }) => {
  const W = 128;
  const H = 76;
  const K = 66;
  const stretch = 1 + 0.3 * Math.sin(Math.min(1, travel) * Math.PI);
  const kw = K * stretch;
  const x0 = 5;
  const x1 = W - K - 5;
  const left = x0 + (x1 - x0) * t - (kw - K) * t;
  return (
    <div style={{ position: "relative", width: W, height: H, borderRadius: H / 2, background: "#E9E9EE", overflow: "hidden", flex: "none" }}>
      <div style={{ position: "absolute", inset: 0, borderRadius: H / 2, background: GREEN, clipPath: `inset(0 ${100 - Math.min(100, t * 100)}% 0 0 round ${H / 2}px)` }} />
      <div style={{ position: "absolute", top: 5, left, width: kw, height: K, borderRadius: K / 2, background: "#fff", boxShadow: "0 3px 8px rgba(0,0,0,0.16), 0 1px 1px rgba(0,0,0,0.08)" }} />
    </div>
  );
};

export const AppleToggles: React.FC<{ clip: ClipProps; top?: number }> = ({ clip, top = 1000 }) => {
  const f = useCurrentFrame();
  const W = 760;
  const RH = 116;
  const GAP = 20;
  const x = (1080 - W) / 2;
  const last = FLIPS[FLIPS.length - 1];
  const done = p(f, last + 10, last + 22, BACK_OUT);


  const rows = (
    <>
      {ROWS.map((label, i) => {
        const y = top + i * (RH + GAP);
        const rin = p(f, 4 + i * 4, 22 + i * 4, EXPO_OUT);
        const at = FLIPS[i];
        const t = p(f, at, at + 9, BACK_OUT);
        const travel = p(f, at, at + 9, (v) => v);
        const lift = Math.sin(p(f, at, at + 12, (v) => v) * Math.PI) * 6;
        const lit = p(f, at, at + 8);
        return (
          <div key={label} style={{ position: "absolute", left: x, top: y, width: W, height: RH, transform: `translateY(${(1 - rin) * 60 - lift}px) scale(${0.96 + 0.04 * rin})`, opacity: rin }}>
            <div style={{ position: "absolute", left: 30, right: 30, bottom: -16, height: 40, borderRadius: "50%", background: "rgba(0,0,0,0.28)", filter: "blur(16px)" }} />
            <div style={{ position: "absolute", inset: 0, borderRadius: 32, background: "rgba(248,247,251,0.96)", boxShadow: "inset 0 1px 0 #fff, 0 1px 0 rgba(0,0,0,0.04)", display: "flex", alignItems: "center", padding: "0 26px 0 36px" }}>
              <div style={{ flex: 1, fontFamily: SANS, fontSize: 42, fontWeight: 500, letterSpacing: -0.6, color: `rgba(20,20,24,${0.62 + 0.36 * lit})` }}>{label}</div>
              <Switch t={Math.min(1.06, t)} travel={travel} />
            </div>
          </div>
        );
      })}
      <div style={{ position: "absolute", left: 540 - 120, top: top + ROWS.length * (RH + GAP) + 6, width: 240, height: 72, borderRadius: 36, background: "rgba(248,247,251,0.96)", display: "flex", alignItems: "center", justifyContent: "center", gap: 10, transform: `translateY(${(1 - done) * -30}px) scale(${done})`, opacity: done, boxShadow: "0 12px 30px rgba(0,0,0,0.3)" }}>
        <div style={{ width: 34, height: 34, borderRadius: 17, background: GREEN, display: "grid", placeItems: "center" }}>
          <svg width={22} height={22} viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth={3.4} strokeLinecap="round" strokeLinejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5" /></svg>
        </div>
        <div style={{ fontFamily: SANS, fontWeight: 600, fontSize: 34, color: "#141418" }}>Done</div>
      </div>
    </>
  );

  return <Scene clip={clip} dur={TOGGLES_DUR} push={[1, 1.1]} origin={[540, top + 200]} kicks={FLIPS} focus={p(f, 4, 24, SOFT) * 0.3} front={rows} />;
};
