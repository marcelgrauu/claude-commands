/**
 * /glass-type — giant 3D glass letters standing in the room, behind you.
 * Each letter is built like a real slab of glass:
 *   cast shadow on the wall (anchors it in the room)
 *   extrusion: stacked slices, darker at the back, so the thickness reads
 *   face: the room refracted (blurred, lifted plate, shifted) + a cool tint
 *   bevel light: bright top-left rim, dim bottom-right
 *   specular band that crosses the word once
 * Letters rise one by one out of the desk line with real motion blur and a
 * small tilt that settles; your head covers the bottom of the word.
 */
import React from "react";
import { staticFile, useCurrentFrame } from "remotion";
import { EASE, prog, track, velocityOf } from "../kit/motion";
import { MotionBlur } from "../kit/fx";
import { ClipProps, Scene, TIGHT } from "./common";

export const GLASS_TYPE_DUR = 100;

const WORD = "EDIT";
const SIZE = 310;
const TOP = 390; // the cap covers the bottom quarter of the middle letters
const DEPTH = 14;

const riseY = (f: number, i: number) => track(f, [[6 + i * 5, 380], [30 + i * 5, 0, EASE.out]]);
const tilt = (f: number, i: number) => track(f, [[6 + i * 5, -58], [34 + i * 5, 0, EASE.out]]);

export const GlassType: React.FC<{ clip: ClipProps; cut: ClipProps; plate: string }> = ({ clip, cut, plate }) => {
  const f = useCurrentFrame();
  const sweep = prog(f, 44, 84, EASE.inOut);
  const letters = WORD.split("");
  const glyph: React.CSSProperties = { fontFamily: TIGHT, fontWeight: 900, fontSize: SIZE, lineHeight: 1, letterSpacing: -8, whiteSpace: "pre" };

  const word = (
    <div style={{ position: "absolute", left: 0, top: TOP, width: 1080, display: "flex", justifyContent: "center", gap: 2 }}>
      {letters.map((ch, i) => {
        const y = riseY(f, i);
        const vy = velocityOf((t) => riseY(t, i), f);
        const on = prog(f, 6 + i * 5, 14 + i * 5, EASE.out);
        return (
          <div key={i} style={{ position: "relative", transform: `perspective(1400px) translateY(${y}px) rotateX(${tilt(f, i)}deg)`, transformOrigin: "50% 100%", opacity: on }}>
            <MotionBlur id={`gt${i}`} vy={vy} shutter={0.6}>
              <div style={{ position: "relative" }}>
                {/* cast shadow on the wall, offset down-right like the key light from the left */}
                <div style={{ ...glyph, position: "absolute", left: 26, top: 34, color: "rgba(0,0,0,0.42)", filter: "blur(14px)" }}>{ch}</div>
                {/* extrusion: front slice lightest, back slices darker */}
                {Array.from({ length: DEPTH }).map((_, k) => {
                  const d = DEPTH - k;
                  const shade = 40 + k * 7;
                  return (
                    <div key={k} style={{ ...glyph, position: k === 0 ? "relative" : "absolute", left: d * 1.2, top: d * 1.6, color: `rgba(${shade},${shade + 10},${shade + 18},${k === 0 ? 0.55 : 0.16})` }}>{ch}</div>
                  );
                })}
                {/* face: the room seen through the glass */}
                <div style={{ ...glyph, position: "absolute", left: 0, top: 0, color: "transparent", backgroundImage: `url(${staticFile(plate)})`, backgroundSize: "1240px 2204px", backgroundPosition: `${-170 - i * 182}px ${-TOP + 60}px`, WebkitBackgroundClip: "text", backgroundClip: "text" }}>{ch}</div>
                {/* cool glass tint, denser at the bottom like real thickness */}
                <div style={{ ...glyph, position: "absolute", left: 0, top: 0, color: "transparent", backgroundImage: "linear-gradient(180deg, rgba(215,232,245,0.14) 0%, rgba(150,175,195,0.32) 100%)", WebkitBackgroundClip: "text", backgroundClip: "text" }}>{ch}</div>
                {/* bevel: bright top-left edge, dim bottom-right */}
                <div style={{ ...glyph, position: "absolute", left: 0, top: 0, color: "transparent", WebkitTextStroke: "3px rgba(255,255,255,0.9)", WebkitMaskImage: "linear-gradient(135deg, #000 0%, rgba(0,0,0,0.55) 45%, rgba(0,0,0,0.12) 100%)", maskImage: "linear-gradient(135deg, #000 0%, rgba(0,0,0,0.55) 45%, rgba(0,0,0,0.12) 100%)" }}>{ch}</div>
                {/* specular band */}
                <div style={{ ...glyph, position: "absolute", left: 0, top: 0, color: "transparent", backgroundImage: `linear-gradient(112deg, transparent ${sweep * 300 - 110 - i * 24}%, rgba(255,255,255,0.8) ${sweep * 300 - 98 - i * 24}%, transparent ${sweep * 300 - 86 - i * 24}%)`, WebkitBackgroundClip: "text", backgroundClip: "text" }}>{ch}</div>
              </div>
            </MotionBlur>
          </div>
        );
      })}
    </div>
  );

  return <Scene clip={clip} cut={cut} dur={GLASS_TYPE_DUR} push={[1, 1.06]} origin={[540, 640]} kicks={[30]} back={word} />;
};
