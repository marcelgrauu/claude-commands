/**
 * Grid effects, part 1: /carrusel-3d, /flash, /muro, /claude-beside-me, /marco-roto.
 * Same rules as the featured ones: frame-driven, camera always moving,
 * transform and filter on separate elements, last frame holds.
 */
import React from "react";
import { AbsoluteFill, Img, interpolate, staticFile, useCurrentFrame } from "remotion";
import { EXPO_OUT, BACK_OUT, QUINT_INOUT, SOFT, p } from "../kit";
import { Clip, ClipProps, Cutout, MONO, SANS, TIGHT, Y } from "./common";
import { Asterisk } from "../ui/ClaudePhone";

export const GRID_DUR = 96;

const Cover: React.FC<{ img: string; word: string; w: number; h: number; tone?: string }> = ({ img, word, w, h, tone = Y }) => (
  <div style={{ width: w, height: h, borderRadius: 22, overflow: "hidden", position: "relative", background: "#111", boxShadow: "0 24px 50px rgba(0,0,0,0.5)", border: "2px solid rgba(255,255,255,0.85)" }}>
    <Img src={staticFile(img)} style={{ width: w, height: h, objectFit: "cover" }} />
    <div style={{ position: "absolute", inset: 0, background: "linear-gradient(180deg, rgba(0,0,0,0) 40%, rgba(0,0,0,0.75))" }} />
    <div style={{ position: "absolute", left: 14, right: 14, bottom: 16, fontFamily: TIGHT, fontWeight: 800, fontSize: w * 0.17, lineHeight: 0.92, letterSpacing: -1.5, color: tone }}>{word}</div>
    <div style={{ position: "absolute", left: 12, top: 12, fontFamily: SANS, fontWeight: 700, fontSize: w * 0.075, color: "#fff" }}>▶ {(1.2 + word.length / 3).toFixed(1)}M</div>
  </div>
);

/* ---------------------------------------------------------- /carrusel-3d */
export const PovCarouselSpin: React.FC<{ clip: ClipProps; cut: ClipProps; covers: { img: string; word: string }[]; swipes: number[] }> = ({ clip, cut, covers, swipes }) => {
  const f = useCurrentFrame();
  const n = covers.length;
  const intro = p(f, 0, 26, EXPO_OUT);
  let ang = f * 0.35 + (1 - intro) * -90;
  swipes.forEach((s) => (ang += 360 / n * 1.5 * p(f, s, s + 22, EXPO_OUT)));
  const R = 470;
  const push = interpolate(f, [0, GRID_DUR], [1, 1.05], { easing: SOFT });
  return (
    <AbsoluteFill style={{ background: "#000", overflow: "hidden" }}>
      <AbsoluteFill style={{ transform: `scale(${push})`, transformOrigin: "540px 800px" }}>
        <Clip {...clip} />
        <div style={{ position: "absolute", inset: 0, perspective: 1300, perspectiveOrigin: "540px 760px" }}>
          <div style={{ position: "absolute", left: 560, top: 560, transformStyle: "preserve-3d", transform: `translateZ(-300px) rotateX(-10deg) rotateY(${ang}deg) scale(${0.6 + 0.4 * intro})` }}>
            {covers.map((c, i) => {
              const a = (i / n) * 360;
              return (
                <div key={i} style={{ position: "absolute", left: -125, top: -222, transform: `rotateY(${a}deg) translateZ(${R}px)`, backfaceVisibility: "hidden" }}>
                  <Cover img={c.img} word={c.word} w={250} h={444} />
                </div>
              );
            })}
          </div>
        </div>
        <Cutout {...cut} />
      </AbsoluteFill>
    </AbsoluteFill>
  );
};

/* ---------------------------------------------------------- /flash */
export const ShutterStrike: React.FC<{ clip: ClipProps; stills: string[] }> = ({ clip, stills }) => {
  const f = useCurrentFrame();
  const hits = [10, 26, 42, 60];
  const pos = [
    { x: 120, y: 300, r: -9 },
    { x: 560, y: 420, r: 7 },
    { x: 150, y: 900, r: 5 },
    { x: 330, y: 560, r: -2 },
  ];
  const flash = hits.reduce((s, h) => s + (f >= h ? Math.max(0, 1 - (f - h) / 3) : 0), 0);
  const kick = hits.reduce((s, h) => s + 0.03 * Math.max(0, 1 - Math.abs(f - h - 1) / 5), 0);
  const streak = p(f, 72, 84, QUINT_INOUT);
  return (
    <AbsoluteFill style={{ background: "#0B0B0B", overflow: "hidden" }}>
      <AbsoluteFill style={{ filter: "blur(18px) brightness(0.45)", transform: "scale(1.1)" }}>
        <Clip {...clip} />
      </AbsoluteFill>
      <AbsoluteFill style={{ transform: `scale(${1 + kick})`, transformOrigin: "540px 900px" }}>
        {stills.slice(0, 4).map((s, i) => {
          const h = hits[i];
          const t = p(f, h, h + 6, EXPO_OUT);
          const big = i === 3;
          const w = big ? 520 : 400;
          return f >= h ? (
            <div key={i} style={{ position: "absolute", left: pos[i].x, top: pos[i].y, transform: `rotate(${pos[i].r}deg) scale(${1.5 - 0.5 * t})`, opacity: Math.min(1, t * 3) }}>
              <div style={{ background: "#FAFAF7", padding: "18px 18px 70px", boxShadow: "0 30px 70px rgba(0,0,0,0.6)" }}>
                <Img src={staticFile(s)} style={{ width: w, height: w * 1.2, objectFit: "cover", display: "block", filter: big ? "none" : "grayscale(0.35) contrast(1.05)" }} />
                <div style={{ position: "absolute", left: 22, bottom: 20, fontFamily: MONO, fontSize: 20, letterSpacing: 3, color: "#555" }}>{["TAKE 01", "TAKE 02", "TAKE 03", "THE ONE"][i]}</div>
              </div>
            </div>
          ) : null;
        })}
        {/* the strike: a light streak that cuts across the stack */}
        <div style={{ position: "absolute", left: -200, top: 1080, width: 1500, height: 10, background: `linear-gradient(90deg, transparent, ${Y} 30%, #fff 50%, ${Y} 70%, transparent)`, transform: `rotate(-14deg) scaleX(${streak})`, transformOrigin: "0 50%", boxShadow: `0 0 40px ${Y}`, opacity: 0.95 }} />
      </AbsoluteFill>
      <AbsoluteFill style={{ background: "#fff", opacity: Math.min(0.7, flash) }} />
    </AbsoluteFill>
  );
};

/* ---------------------------------------------------------- /muro */
const NOTES = [
  { x: 40, y: 140, w: 330, r: -4, k: "paper", t: "Claude edits your videos now" },
  { x: 640, y: 120, w: 380, r: 3, k: "tweet", t: "I sent it my clips. It sent back the finished reel." },
  { x: 410, y: 300, w: 270, r: -2, k: "yellow", t: "ONE COMMAND" },
  { x: 60, y: 470, w: 300, r: 5, k: "thumb", t: "img1" },
  { x: 740, y: 450, w: 300, r: -6, k: "paper", t: "The new editor never sleeps" },
  { x: 30, y: 800, w: 280, r: -3, k: "tweet", t: "Claude made this? Yes." },
  { x: 790, y: 770, w: 260, r: 4, k: "thumb", t: "img2" },
];

export const HeadlineWall: React.FC<{ clip: ClipProps; cut: ClipProps; imgs: string[] }> = ({ clip, cut, imgs }) => {
  const f = useCurrentFrame();
  const push = interpolate(f, [0, GRID_DUR], [1, 1.06], { easing: SOFT });
  return (
    <AbsoluteFill style={{ background: "#000", overflow: "hidden" }}>
      <AbsoluteFill style={{ transform: `scale(${push})`, transformOrigin: "540px 760px" }}>
        <Clip {...clip} />
        {NOTES.map((n, i) => {
          const t = p(f, 6 + i * 6, 18 + i * 6, BACK_OUT);
          const drift = Math.sin((f + i * 20) / 30) * 3;
          const body =
            n.k === "thumb" ? (
              <div style={{ width: n.w, height: n.w * 0.62, borderRadius: 10, overflow: "hidden", border: "6px solid #fff" }}>
                <Img src={staticFile(imgs[n.t === "img1" ? 0 : 1])} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
              </div>
            ) : (
              <div style={{ width: n.w, padding: "20px 22px", borderRadius: n.k === "tweet" ? 18 : 4, background: n.k === "tweet" ? "#15171A" : n.k === "yellow" ? Y : "#F3EFE6", color: n.k === "tweet" ? "#fff" : "#141414", fontFamily: n.k === "paper" ? "AG, serif" : TIGHT, fontWeight: n.k === "paper" ? 600 : 800, fontSize: n.k === "yellow" ? 46 : 34, lineHeight: 1.1, letterSpacing: n.k === "yellow" ? -1.5 : -0.5 }}>
                {n.k === "tweet" && <div style={{ fontFamily: SANS, fontWeight: 500, fontSize: 20, color: "rgba(255,255,255,0.55)", marginBottom: 8 }}>@creator · 2h</div>}
                {n.t}
              </div>
            );
          return (
            <div key={i} style={{ position: "absolute", left: n.x, top: n.y + drift, transform: `rotate(${n.r}deg) scale(${0.4 + 0.6 * t})`, opacity: Math.min(1, t * 2), boxShadow: "0 18px 40px rgba(0,0,0,0.5)" }}>
              <div style={{ position: "absolute", left: "50%", top: -14, width: 90, height: 28, marginLeft: -45, background: "rgba(240,235,220,0.7)", transform: "rotate(-3deg)", zIndex: 2 }} />
              {body}
            </div>
          );
        })}
        <Cutout {...cut} />
      </AbsoluteFill>
    </AbsoluteFill>
  );
};

/* ---------------------------------------------------------- /claude-beside-me */
export const ClaudeBesideMe: React.FC<{ clip: ClipProps; cut: ClipProps }> = ({ clip, cut }) => {
  const f = useCurrentFrame();
  const swing = p(f, 4, 30, EXPO_OUT);
  const reply = "Done. Your reel is ready.";
  const n = Math.max(0, Math.min(reply.length, Math.floor((f - 38) / 1.1)));
  const push = interpolate(f, [0, GRID_DUR], [1, 1.05], { easing: SOFT });
  return (
    <AbsoluteFill style={{ background: "#000", overflow: "hidden" }}>
      <AbsoluteFill style={{ transform: `scale(${push})`, transformOrigin: "640px 760px" }}>
        <Clip {...clip} />
        <div style={{ position: "absolute", inset: 0, perspective: 1600 }}>
          <div style={{ position: "absolute", left: 470, top: 440, width: 560, height: 420, borderRadius: 30, background: "#FAF9F5", boxShadow: "0 40px 90px rgba(0,0,0,0.55)", transformOrigin: "0% 50%", transform: `translateX(${(1 - swing) * -300}px) rotateY(${-14 - (1 - swing) * 50}deg) scale(${0.6 + 0.4 * swing})`, opacity: Math.min(1, swing * 2), overflow: "hidden" }}>
            <div style={{ position: "absolute", left: 24, top: 22, display: "flex", gap: 10 }}>
              {["#FF5F57", "#FEBC2E", "#28C840"].map((c) => <div key={c} style={{ width: 16, height: 16, borderRadius: 8, background: c }} />)}
            </div>
            <div style={{ position: "absolute", left: 0, right: 0, top: 16, display: "flex", justifyContent: "center", alignItems: "center", gap: 8 }}>
              <Asterisk size={26} />
              <div style={{ fontFamily: SANS, fontWeight: 600, fontSize: 24, color: "#3D3929" }}>Claude</div>
            </div>
            <div style={{ position: "absolute", right: 26, top: 80, background: "#EFEADD", borderRadius: 18, padding: "12px 18px", fontFamily: MONO, fontSize: 24, color: "#3D3929", opacity: p(f, 26, 32) }}>/claude-beside-me</div>
            <div style={{ position: "absolute", left: 28, top: 160, right: 28, fontFamily: TIGHT, fontWeight: 700, fontSize: 36, lineHeight: 1.2, color: "#1F1E1B" }}>{reply.slice(0, n)}{n < reply.length && f > 36 && <span style={{ color: "#D97757" }}>▍</span>}</div>
            {[260, 300, 340].map((y, i) => <div key={y} style={{ position: "absolute", left: 28, top: y, height: 18, width: [420, 340, 260][i], borderRadius: 9, background: "#ECE7DA", opacity: p(f, 60 + i * 4, 70 + i * 4) }} />)}
            <div style={{ position: "absolute", top: 0, bottom: 0, width: 200, left: `${-40 + p(f, 30, 70, QUINT_INOUT) * 140}%`, background: "linear-gradient(100deg, transparent, rgba(255,255,255,0.8), transparent)" }} />
          </div>
        </div>
        <Cutout {...cut} />
        <div style={{ position: "absolute", left: 150, top: 1180, padding: "16px 26px", borderRadius: 40, display: "flex", alignItems: "center", gap: 12, background: "rgba(255,255,255,0.16)", border: "1.5px solid rgba(255,255,255,0.4)", boxShadow: "inset 0 1px 0 rgba(255,255,255,0.5), 0 14px 30px rgba(0,0,0,0.35)", transform: `translateY(${Math.sin(f / 14) * 8}px) scale(${p(f, 20, 34, BACK_OUT)})` }}>
          <Asterisk size={34} color="#fff" />
          <div style={{ fontFamily: SANS, fontWeight: 600, fontSize: 30, color: "#fff" }}>Claude</div>
        </div>
      </AbsoluteFill>
    </AbsoluteFill>
  );
};

/* ---------------------------------------------------------- /marco-roto */
export const FrameBreak: React.FC<{ clip: ClipProps; cut: ClipProps }> = ({ clip, cut }) => {
  const f = useCurrentFrame();
  const t = p(f, 0, 24, EXPO_OUT);
  // the full screen shot shrinks into a reel card that sits below your head:
  // the body stays inside the card, the head breaks out over its top edge
  const X0 = lerpN(0, 170, t);
  const X1 = lerpN(1080, 910, t);
  const Y0 = lerpN(0, 900, t);
  const Y1 = lerpN(1920, 1760, t);
  const r = 40 * t;
  const icon = (d: string) => <svg width={52} height={52} viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth={1.9} strokeLinejoin="round" strokeLinecap="round"><path d={d} /></svg>;
  // the cutout shows inside the card, plus a column above it where the head comes through
  const clipPath = `polygon(${X0}px ${Y1}px, ${X0}px ${Y0}px, 300px ${Y0}px, 300px 0px, 800px 0px, 800px ${Y0}px, ${X1}px ${Y0}px, ${X1}px ${Y1}px)`;
  return (
    <AbsoluteFill style={{ background: "#000", overflow: "hidden" }}>
      <AbsoluteFill style={{ filter: `blur(${16 * t}px) brightness(${1 - 0.45 * t})`, transform: "scale(1.06)" }}>
        <Clip {...clip} />
      </AbsoluteFill>
      <div style={{ position: "absolute", left: X0, top: Y0, width: X1 - X0, height: Y1 - Y0, borderRadius: r, overflow: "hidden", boxShadow: `0 40px 90px rgba(0,0,0,${0.6 * t})` }}>
        <div style={{ position: "absolute", left: -X0, top: -Y0, width: 1080, height: 1920 }}><Clip {...clip} /></div>
      </div>
      <div style={{ position: "absolute", left: X0, top: Y0, width: X1 - X0, height: Y1 - Y0, borderRadius: r, boxShadow: `inset 0 0 0 ${2 * t}px rgba(255,255,255,0.5)` }} />
      {/* the person breaks out over the top edge */}
      <AbsoluteFill style={{ clipPath, WebkitClipPath: clipPath }}><Cutout {...cut} /></AbsoluteFill>
      {/* the reel's own UI sits on top of everything inside the card */}
      <div style={{ position: "absolute", left: X0, top: Y0, width: X1 - X0, height: Y1 - Y0, borderRadius: r, overflow: "hidden" }}>
        <div style={{ position: "absolute", right: 18, bottom: 150, display: "flex", flexDirection: "column", gap: 26, alignItems: "center", color: "#fff", fontFamily: SANS, fontWeight: 600, fontSize: 21, opacity: t }}>
          {[["M12 20.3s-7.4-4.5-9.2-9C1.6 8.2 3.5 5 6.8 5c2 0 3.6 1.1 5.2 3 1.6-1.9 3.2-3 5.2-3 3.3 0 5.2 3.2 4 6.3-1.8 4.5-9.2 9-9.2 9z", "48.2K"], ["M20.66 17A9.99 9.99 0 1 0 17.07 20.62L22 22z", "1,204"], ["M22 3L9.22 10.08M11.7 20.33L22 3H2l7.22 7.08z", "9,870"]].map(([d, n]) => (
            <div key={n} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 4 }}>{icon(d)}{n}</div>
          ))}
        </div>
        <div style={{ position: "absolute", left: 22, bottom: 30, display: "flex", alignItems: "center", gap: 12, color: "#fff", fontFamily: SANS, fontWeight: 700, fontSize: 26, opacity: t }}>
          <div style={{ width: 48, height: 48, borderRadius: 24, background: Y }} />marcelgrauu<span style={{ border: "2px solid rgba(255,255,255,0.85)", borderRadius: 12, padding: "4px 14px", fontSize: 22, fontWeight: 600 }}>Follow</span>
        </div>
        <div style={{ position: "absolute", left: 0, right: 0, bottom: 0, height: 4, background: "rgba(255,255,255,0.25)", opacity: t }}><div style={{ width: `${(f / GRID_DUR) * 100}%`, height: "100%", background: "#fff" }} /></div>
      </div>
    </AbsoluteFill>
  );
};

const lerpN = (a: number, b: number, t: number) => a + (b - a) * t;
