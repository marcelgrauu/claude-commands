/**
 * Grid effects, part 2: /zoom-digital, /iphone, /particulas, /antes-despues,
 * /tarjeta-cristal, /palabras, /cursor.
 */
import React from "react";
import { AbsoluteFill, Img, interpolate, staticFile, useCurrentFrame } from "remotion";
import { EXPO_OUT, EXPO_IN, BACK_OUT, QUINT_INOUT, SOFT, p, hash, Pointer, arc } from "../kit";
import { Clip, ClipProps, Cutout, GlassPane, Sweep, MONO, SANS, TIGHT, Y } from "./common";
import { Asterisk } from "../ui/ClaudePhone";
import { GRID_DUR } from "./Grid1";

/* ---------------------------------------------------------- /zoom-digital */
export const DigitalZoom: React.FC<{ clip: ClipProps }> = ({ clip }) => {
  const f = useCurrentFrame();
  const z = interpolate(f, [0, 14, 22, 86, GRID_DUR], [1, 1, 1.55, 1.62, 1.62], { easing: EXPO_OUT, extrapolateRight: "clamp" });
  // speed blur only while the punch moves
  const speed = Math.abs(z - interpolate(f - 1, [0, 14, 22, 86, GRID_DUR], [1, 1, 1.55, 1.62, 1.62], { easing: EXPO_OUT, extrapolateLeft: "clamp", extrapolateRight: "clamp" }));
  const blur = Math.min(10, speed * 120);
  const w1 = p(f, 18, 32, EXPO_OUT);
  const w2 = p(f, 26, 40, EXPO_OUT);
  return (
    <AbsoluteFill style={{ background: "#000", overflow: "hidden" }}>
      <AbsoluteFill style={{ transform: `scale(${z})`, transformOrigin: "530px 840px" }}>
        <AbsoluteFill style={{ filter: blur > 0.3 ? `blur(${blur}px)` : "none" }}>
          <Clip {...clip} />
        </AbsoluteFill>
      </AbsoluteFill>
      {/* zoom lines during the punch */}
      <AbsoluteFill style={{ background: `repeating-conic-gradient(from 0deg at 50% 44%, rgba(255,255,255,${0.16 * Math.min(1, blur / 6)}) 0deg 1.2deg, transparent 1.2deg 9deg)`, WebkitMaskImage: "radial-gradient(circle at 50% 44%, transparent 30%, #000 70%)", maskImage: "radial-gradient(circle at 50% 44%, transparent 30%, #000 70%)" }} />
      <div style={{ position: "absolute", left: 0, right: 0, top: 1240, textAlign: "center" }}>
        <div style={{ fontFamily: TIGHT, fontWeight: 800, fontSize: 120, letterSpacing: -5, color: "#fff", lineHeight: 0.95, opacity: w1, transform: `scale(${1.4 - 0.4 * w1})` }}>
          <span style={{ filter: `blur(${(1 - w1) * 16}px)`, display: "inline-block" }}>video</span>
        </div>
        <div style={{ fontFamily: TIGHT, fontWeight: 300, fontSize: 120, letterSpacing: -5, lineHeight: 0.95, opacity: w2, transform: `scale(${1.4 - 0.4 * w2})` }}>
          <span style={{ filter: `blur(${(1 - w2) * 16}px)`, display: "inline-block", color: Y }}>editing</span>
        </div>
      </div>
    </AbsoluteFill>
  );
};

/* ---------------------------------------------------------- /iphone */
export const PhoneMockup: React.FC<{ clip: ClipProps }> = ({ clip }) => {
  const f = useCurrentFrame();
  const t = p(f, 4, 26, EXPO_OUT);
  const bob = Math.sin(f / 16) * 10;
  const msgs = [
    { at: 30, me: true, txt: "/phone-mockup" },
    { at: 44, me: false, txt: "Done. Your phone is floating right next to you." },
    { at: 62, me: false, txt: "Want your app on the screen?" },
  ];
  const push = interpolate(f, [0, GRID_DUR], [1, 1.05], { easing: SOFT });
  const W = 310;
  const H = 640;
  return (
    <AbsoluteFill style={{ background: "#000", overflow: "hidden" }}>
      <AbsoluteFill style={{ transform: `scale(${push})`, transformOrigin: "640px 800px" }}>
        <Clip {...clip} />
      </AbsoluteFill>
      <div style={{ position: "absolute", inset: 0, perspective: 1400 }}>
        <div style={{ position: "absolute", left: 680, top: 470, width: W, height: H, transform: `translateY(${(1 - t) * 300 + bob}px) rotateY(${-22 + (1 - t) * -40}deg) rotateZ(${4 - 2 * t}deg)`, opacity: Math.min(1, t * 2), transformStyle: "preserve-3d" }}>
          {/* frame */}
          <div style={{ position: "absolute", inset: 0, borderRadius: 56, background: "linear-gradient(135deg,#9a9a9e,#3a3a3e 30%,#1a1a1c 70%,#77777b)", boxShadow: "0 50px 90px rgba(0,0,0,0.6)" }} />
          <div style={{ position: "absolute", inset: 8, borderRadius: 50, background: "#0B0B0C", overflow: "hidden" }}>
            <div style={{ position: "absolute", left: "50%", top: 14, width: 100, height: 30, marginLeft: -50, borderRadius: 15, background: "#000", zIndex: 2 }} />
            <div style={{ position: "absolute", left: 0, right: 0, top: 64, display: "flex", justifyContent: "center", alignItems: "center", gap: 8 }}>
              <Asterisk size={24} /><div style={{ fontFamily: SANS, fontSize: 20, color: "#EEE", fontWeight: 600 }}>Claude</div>
            </div>
            {msgs.map((m, i) => {
              const k = p(f, m.at, m.at + 10, BACK_OUT);
              return (
                <div key={i} style={{ position: "absolute", top: 130 + i * 120, left: m.me ? undefined : 18, right: m.me ? 18 : undefined, maxWidth: 250, padding: "14px 16px", borderRadius: 20, background: m.me ? "#3B302B" : "#262624", color: m.me ? "#E07A5A" : "#F2F1EC", fontFamily: m.me ? MONO : SANS, fontSize: 20, lineHeight: 1.3, opacity: k, transform: `translateY(${(1 - k) * 20}px) scale(${0.9 + 0.1 * k})`, transformOrigin: m.me ? "100% 100%" : "0 100%" }}>
                  {m.txt}
                </div>
              );
            })}
            <div style={{ position: "absolute", left: 16, right: 16, bottom: 24, height: 56, borderRadius: 28, background: "#262624", display: "flex", alignItems: "center", padding: "0 18px", color: "#777", fontFamily: SANS, fontSize: 18 }}>Reply to Claude…</div>
            {/* glass reflection */}
            <div style={{ position: "absolute", inset: 0, background: "linear-gradient(120deg, rgba(255,255,255,0.14) 0%, transparent 35%)" }} />
          </div>
        </div>
      </div>
    </AbsoluteFill>
  );
};

/* ---------------------------------------------------------- /particulas */
const PN = 420;
const BOX = { x: 330, y: 360, w: 420, h: 420 };
const COLS = 21;
export const ScreenPush: React.FC<{ clip: ClipProps }> = ({ clip }) => {
  const f = useCurrentFrame();
  const cell = BOX.w / COLS;
  const filled = Math.min(PN, Math.floor(p(f, 8, 74, (x) => x) * PN));
  const words = ["give it", "enough", "detail"];
  return (
    <AbsoluteFill style={{ background: "#000", overflow: "hidden" }}>
      {/* top: the graphic */}
      <div style={{ position: "absolute", left: 0, right: 0, top: 0, height: 960, background: "#F4F3EF", overflow: "hidden" }}>
        <div style={{ position: "absolute", inset: 0, backgroundImage: "linear-gradient(rgba(0,0,0,0.05) 1px, transparent 1px), linear-gradient(90deg, rgba(0,0,0,0.05) 1px, transparent 1px)", backgroundSize: "40px 40px" }} />
        {/* container */}
        <div style={{ position: "absolute", left: BOX.x - 8, top: BOX.y, width: BOX.w + 16, height: BOX.h + 8, borderLeft: "5px solid #111", borderRight: "5px solid #111", borderBottom: "5px solid #111", borderRadius: "0 0 10px 10px" }} />
        {["01", "02", "03"].map((l, i) => (
          <div key={l} style={{ position: "absolute", left: [BOX.x - 70, BOX.x + BOX.w / 2 - 20, BOX.x + BOX.w + 32][i], top: [BOX.y + 160, BOX.y + BOX.h + 30, BOX.y + 160][i], fontFamily: MONO, fontSize: 26, color: "#111", opacity: p(f, 8 + i * 6, 18 + i * 6) }}>{l}</div>
        ))}
        {Array.from({ length: PN }).map((_, i) => {
          const start = 8 + (i / PN) * 66;
          if (f < start) return null;
          const col = i % COLS;
          const row = Math.floor(i / COLS);
          const tx = BOX.x + col * cell + cell / 2;
          const ty = BOX.y + BOX.h - row * cell - cell / 2;
          const sx = 540 + (hash(i, 2) - 0.5) * 260;
          const sy = -40 - hash(i, 3) * 120;
          const u = p(f, start, start + 16, EXPO_IN);
          const bounce = p(f, start + 16, start + 22, BACK_OUT);
          const x = sx + (tx - sx) * u;
          const y = sy + (ty - sy) * u - (1 - bounce) * (u >= 1 ? 6 : 0);
          const c = hash(i, 7) > 0.82 ? "#111" : Y;
          return <div key={i} style={{ position: "absolute", left: x - cell * 0.42, top: y - cell * 0.42, width: cell * 0.84, height: cell * 0.84, borderRadius: "50%", background: c, boxShadow: c === Y ? "inset 0 -2px 0 rgba(0,0,0,0.15)" : undefined }} />;
        })}
        <div style={{ position: "absolute", left: 0, right: 0, top: 820, textAlign: "center", fontFamily: TIGHT, fontWeight: 800, fontSize: 64, letterSpacing: -2.5, color: "#111" }}>
          {words.map((w, i) => <span key={w} style={{ opacity: p(f, 40 + i * 8, 50 + i * 8), marginRight: 16, color: i === 2 ? "#111" : "#111", background: i === 2 ? Y : undefined, padding: i === 2 ? "0 10px" : undefined }}>{w}</span>)}
        </div>
        <div style={{ position: "absolute", left: BOX.x + BOX.w + 30, top: BOX.y, fontFamily: MONO, fontSize: 22, color: "#666" }}>{filled}</div>
      </div>
      {/* bottom: the clip */}
      <div style={{ position: "absolute", left: 0, right: 0, top: 960, height: 960, overflow: "hidden" }}>
        <div style={{ position: "absolute", left: 0, top: -420, width: 1080, height: 1920 }}><Clip {...clip} /></div>
      </div>
    </AbsoluteFill>
  );
};

/* ---------------------------------------------------------- /antes-despues */
export const BeforeAfter: React.FC<{ clip: ClipProps; cut: ClipProps }> = ({ clip, cut }) => {
  const f = useCurrentFrame();
  const w = p(f, 16, 48, QUINT_INOUT);
  const edge = w * 1180 - 50;
  return (
    <AbsoluteFill style={{ background: "#000", overflow: "hidden" }}>
      <Clip {...clip} />
      {/* the white studio, revealed left to right, above the desk line */}
      <div style={{ position: "absolute", inset: 0, clipPath: `inset(0 ${Math.max(0, 1080 - edge)}px 0 0)`, WebkitMaskImage: "linear-gradient(to bottom, #000 0%, #000 65.5%, transparent 67%)", maskImage: "linear-gradient(to bottom, #000 0%, #000 65.5%, transparent 67%)" }}>
        <div style={{ position: "absolute", inset: 0, background: "radial-gradient(ellipse 70% 45% at 50% 40%, #FFFFFF 0%, #F1F0EC 55%, #DAD8D2 100%)" }} />
      </div>
      <Cutout {...cut} />
      {/* the seam */}
      {w > 0 && w < 1 && <div style={{ position: "absolute", top: 0, bottom: 0, left: edge - 3, width: 6, background: "#fff", boxShadow: `0 0 30px 8px ${Y}` }} />}
      <div style={{ position: "absolute", left: 40, top: 60, fontFamily: MONO, fontSize: 26, letterSpacing: 5, color: w > 0.5 ? "#111" : "#fff", background: w > 0.5 ? "rgba(255,255,255,0.7)" : "rgba(0,0,0,0.4)", padding: "8px 16px", borderRadius: 10 }}>{w > 0.5 ? "AFTER" : "BEFORE"}</div>
    </AbsoluteFill>
  );
};

/* ---------------------------------------------------------- /tarjeta-cristal */
export const GlassCard: React.FC<{ clip: ClipProps }> = ({ clip }) => {
  const f = useCurrentFrame();
  const t = p(f, 4, 26, EXPO_OUT);
  const x = 590;
  const y = 330;
  const W = 400;
  const H = 470;
  const push = interpolate(f, [0, GRID_DUR], [1, 1.05], { easing: SOFT });
  const r1 = p(f, 14, 30, EXPO_OUT);
  const r2 = p(f, 20, 36, EXPO_OUT);
  const r3 = p(f, 30, 44, EXPO_OUT);
  return (
    <AbsoluteFill style={{ background: "#000", overflow: "hidden" }}>
      <AbsoluteFill style={{ transform: `scale(${push})`, transformOrigin: "540px 800px" }}>
        <Clip {...clip} />
      </AbsoluteFill>
      <div style={{ position: "absolute", inset: 0, perspective: 1500 }}>
        <div style={{ position: "absolute", inset: 0, transformOrigin: `${x + W / 2}px ${y + H / 2}px`, transform: `translateX(${(1 - t) * 220}px) rotateY(${(1 - t) * -35 - 8}deg)`, opacity: Math.min(1, t * 2) }}>
          <GlassPane x={x} y={y} w={W} h={H} r={44} clip={clip} blur={22} lift={0.8} mag={1.08} tint="rgba(20,30,70,0.30)">
            <div style={{ position: "absolute", left: 48, top: 44, fontFamily: SANS, fontWeight: 200, fontSize: 26, letterSpacing: 6, color: "rgba(255,255,255,0.5)" }}>01 / 05</div>
            <div style={{ position: "absolute", left: 44, top: 110, fontFamily: TIGHT, fontWeight: 800, fontSize: 86, lineHeight: 0.86, letterSpacing: -5, color: "#fff", opacity: r1, transform: `translateY(${(1 - r1) * 40}px)` }}>Seedance</div>
            <div style={{ position: "absolute", left: 44, top: 192, fontFamily: TIGHT, fontWeight: 100, fontSize: 86, lineHeight: 0.86, letterSpacing: -3, color: Y, opacity: r2, transform: `translateY(${(1 - r2) * 40}px)` }}>2.5</div>
            <div style={{ position: "absolute", left: 48, right: 40, top: 320, fontFamily: SANS, fontWeight: 300, fontSize: 28, lineHeight: 1.35, color: "rgba(255,255,255,0.68)", opacity: r3 }}>1080p video with native audio, up to 15 seconds.</div>
            <Sweep t={p(f, 40, 70, QUINT_INOUT)} r={44} opacity={0.3} />
          </GlassPane>
        </div>
      </div>
    </AbsoluteFill>
  );
};

/* ---------------------------------------------------------- /palabras */
export const WordStack: React.FC<{ clip: ClipProps }> = ({ clip }) => {
  const f = useCurrentFrame();
  const words = [
    { w: "PASTE", at: 6, light: false },
    { w: "THE", at: 16, light: false },
    { w: "COMMAND", at: 26, light: true },
  ];
  const push = interpolate(f, [0, GRID_DUR], [1, 1.05], { easing: SOFT });
  return (
    <AbsoluteFill style={{ background: "#000", overflow: "hidden" }}>
      <AbsoluteFill style={{ transform: `scale(${push})`, transformOrigin: "540px 800px" }}>
        <Clip {...clip} />
      </AbsoluteFill>
      <AbsoluteFill style={{ background: "linear-gradient(90deg, rgba(0,0,0,0.45), transparent 60%)" }} />
      <div style={{ position: "absolute", left: 60, top: 240 }}>
        {words.map(({ w, at, light }) => {
          const t = p(f, at, at + 12, EXPO_OUT);
          return (
            <div key={w} style={{ overflow: "visible", height: 150, WebkitMaskImage: t < 1 ? "linear-gradient(to bottom, #000 70%, transparent 100%)" : undefined }}>
              <div style={{ transform: `translateY(${(1 - t) * 120}px) skewY(${(1 - t) * 6}deg)`, opacity: t }}>
                <div style={{ fontFamily: TIGHT, fontWeight: light ? 100 : 900, fontSize: 168, lineHeight: 0.9, letterSpacing: light ? -4 : -9, color: light ? Y : "#fff", filter: `blur(${(1 - t) * 14}px)` }}>{w}</div>
              </div>
            </div>
          );
        })}
      </div>
    </AbsoluteFill>
  );
};

/* ---------------------------------------------------------- /cursor */
export const CursorClick: React.FC<{ clip: ClipProps; result: string }> = ({ clip, result }) => {
  const f = useCurrentFrame();
  const bt = p(f, 2, 18, BACK_OUT);
  const move = p(f, 10, 34, QUINT_INOUT);
  const [cx, cy] = arc(move, [980, 1700], [560, 1215], 0.3);
  const press = f >= 34 && f < 40;
  const ripple = p(f, 35, 55, EXPO_OUT);
  const res = p(f, 44, 60, BACK_OUT);
  const done = f >= 36;
  return (
    <AbsoluteFill style={{ background: "#000", overflow: "hidden" }}>
      <Clip {...clip} />
      {/* result */}
      <div style={{ position: "absolute", left: 330, top: 110, width: 420, height: 560, borderRadius: 30, overflow: "hidden", border: "4px solid rgba(255,255,255,0.9)", boxShadow: "0 40px 90px rgba(0,0,0,0.6)", transform: `scale(${0.5 + 0.5 * res}) translateY(${(1 - res) * 120}px)`, opacity: Math.min(1, res * 2) }}>
        <Img src={staticFile(result)} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
        <div style={{ position: "absolute", left: 20, top: 20, background: "#0A0A0A", color: Y, fontFamily: TIGHT, fontWeight: 800, fontSize: 30, padding: "6px 14px", borderRadius: 10 }}>4K</div>
      </div>
      {/* button */}
      <div style={{ position: "absolute", left: 540 - 190, top: 1160, width: 380, height: 116, borderRadius: 60, background: done ? Y : "rgba(255,255,255,0.16)", border: "1.5px solid rgba(255,255,255,0.45)", boxShadow: "inset 0 1px 0 rgba(255,255,255,0.5), 0 20px 40px rgba(0,0,0,0.4)", display: "grid", placeItems: "center", transform: `scale(${bt * (press ? 0.93 : 1)})`, fontFamily: TIGHT, fontWeight: 800, fontSize: 46, letterSpacing: -1.5, color: done ? "#0A0A0A" : "#fff" }}>
        Generate ✦
      </div>
      {f >= 35 && <div style={{ position: "absolute", left: 540 - 200, top: 1218 - 200, width: 400, height: 400, borderRadius: 200, border: `3px solid ${Y}`, transform: `scale(${0.3 + ripple * 1.2})`, opacity: 1 - ripple }} />}
      <Pointer x={cx} y={cy} pressed={press} size={86} />
    </AbsoluteFill>
  );
};
