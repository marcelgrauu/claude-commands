/**
 * Grid effects, part 3: /jiggle-delete and /reel-feed (from @justyn.ai's list).
 */
import React from "react";
import { AbsoluteFill, OffthreadVideo, interpolate, staticFile, useCurrentFrame } from "remotion";
import { EXPO_OUT, BACK_OUT, QUINT_INOUT, SOFT, p } from "../kit";
import { Clip, ClipProps, MONO, SANS, TIGHT, Y } from "./common";
import { Asterisk } from "../ui/ClaudePhone";
import { GRID_DUR } from "./Grid1";

/* ---------------------------------------------------------- /jiggle-delete */
const APPS = [
  { name: "CapCut", bg: "#0B0B0B", node: <div style={{ fontFamily: TIGHT, fontWeight: 800, fontSize: 46, color: "#fff", letterSpacing: -2 }}>CC</div> },
  { name: "Edits", bg: "linear-gradient(135deg,#FF2D87,#7B2CFF 55%,#1E90FF)", node: <div style={{ width: 54, height: 54, borderRadius: 14, border: "6px solid #fff" }} /> },
  { name: "InShot", bg: "linear-gradient(160deg,#FF5A5F,#E0245E)", node: <div style={{ width: 50, height: 50, borderRadius: 25, border: "7px solid #fff" }} /> },
  { name: "Premiere", bg: "#1E0A3C", node: <div style={{ fontFamily: TIGHT, fontWeight: 800, fontSize: 48, color: "#C9A7FF", border: "3px solid #C9A7FF", borderRadius: 10, padding: "0 6px", lineHeight: 1.1 }}>Pr</div> },
];
const DEL = [30, 44, 58, 72]; // frame each app gets deleted

export const JiggleDelete: React.FC<{ clip: ClipProps }> = ({ clip }) => {
  const f = useCurrentFrame();
  const enter = p(f, 2, 18, EXPO_OUT);
  const ICON = 150;
  const GAP = 44;
  const claudeIn = p(f, 80, 92, BACK_OUT);
  const push = interpolate(f, [0, GRID_DUR], [1, 1.04], { easing: SOFT });
  // positions: alive apps slide to fill the gaps
  const alive = (i: number, fr: number) => fr < DEL[i] + 6;
  const slot = (i: number) => APPS.slice(0, i).reduce((acc, _, k) => acc + 1 - p(f, DEL[k] + 4, DEL[k] + 14, QUINT_INOUT), 0);
  const W = 4 * ICON + 3 * GAP + 80;
  return (
    <AbsoluteFill style={{ background: "#000", overflow: "hidden" }}>
      <AbsoluteFill style={{ transform: `scale(${push})`, transformOrigin: "540px 800px" }}>
        <Clip {...clip} />
      </AbsoluteFill>
      <div style={{ position: "absolute", left: (1080 - W) / 2, top: 1360, width: W, height: 300, borderRadius: 48, background: "rgba(250,250,247,0.92)", boxShadow: "0 30px 70px rgba(0,0,0,0.45), inset 0 1px 0 #fff", transform: `translateY(${(1 - enter) * 200}px) scale(${0.9 + 0.1 * enter})`, opacity: Math.min(1, enter * 2) }}>
        <div style={{ position: "absolute", left: 40, top: 24, right: 40, display: "flex", justifyContent: "space-between", fontFamily: MONO, fontSize: 20, letterSpacing: 4, color: "rgba(0,0,0,0.45)" }}>
          <span>EDIT MODE</span><span>{APPS.filter((_, k) => f < DEL[k]).length ? `${APPS.filter((_, k) => f < DEL[k]).length} apps` : "1 app"}</span>
        </div>
        {APPS.map((a, i) => {
          const gone = p(f, DEL[i], DEL[i] + 7, (x) => x);
          const x = 40 + slot(i) * (ICON + GAP);
          const wob = Math.sin(f * 1.6 + i * 1.3) * 2.6;
          if (gone >= 1) return null;
          return (
            <div key={a.name} style={{ position: "absolute", left: x, top: 72, width: ICON, transform: `rotate(${wob}deg) scale(${1 - gone})`, opacity: 1 - gone, transition: "none" }}>
              <div style={{ width: ICON, height: ICON, borderRadius: 36, background: a.bg, display: "grid", placeItems: "center", boxShadow: "0 8px 18px rgba(0,0,0,0.18)" }}>{a.node}</div>
              <div style={{ position: "absolute", left: -12, top: -12, width: 40, height: 40, borderRadius: 20, background: "rgba(60,60,60,0.85)", display: "grid", placeItems: "center", transform: `scale(${f >= DEL[i] - 3 ? 1.25 : 1})` }}>
                <div style={{ width: 18, height: 4, borderRadius: 2, background: "#fff" }} />
              </div>
              <div style={{ textAlign: "center", marginTop: 12, fontFamily: SANS, fontSize: 24, fontWeight: 500, color: "#222" }}>{a.name}</div>
            </div>
          );
        })}
        {/* what is left */}
        {f >= 78 && (
          <div style={{ position: "absolute", left: (W - ICON) / 2, top: 72, width: ICON, transform: `scale(${claudeIn})` }}>
            <div style={{ width: ICON, height: ICON, borderRadius: 36, background: "linear-gradient(160deg,#E58A69,#C9603F)", display: "grid", placeItems: "center", boxShadow: `0 0 0 6px rgba(255,229,0,${0.6 * claudeIn}), 0 12px 30px rgba(201,96,63,0.5)` }}><Asterisk size={84} color="#FFF5EE" /></div>
            <div style={{ textAlign: "center", marginTop: 12, fontFamily: SANS, fontSize: 24, fontWeight: 600, color: "#222" }}>Claude</div>
          </div>
        )}
      </div>
      {/* poof ring on each delete */}
      {DEL.map((d, i) => {
        const r = p(f, d, d + 14, EXPO_OUT);
        if (f < d || r >= 1) return null;
        const x = (1080 - W) / 2 + 40 + i * 0 + slotAt(i, d) * (ICON + GAP) + ICON / 2;
        return <div key={d} style={{ position: "absolute", left: x - 90, top: 1360 + 72 + ICON / 2 - 90, width: 180, height: 180, borderRadius: 90, border: `3px solid ${Y}`, transform: `scale(${0.4 + r})`, opacity: 1 - r }} />;
      })}
    </AbsoluteFill>
  );
};
const slotAt = (i: number, fr: number) => APPS.slice(0, i).filter((_, k) => fr < DEL[k] + 6).length;

/* ---------------------------------------------------------- /reel-feed */
const FEED = [
  { src: "clip", user: "marcelgrauu", cap: "Claude edited this entire video", likes: "48.2K", com: "3,104" },
  { src: "fx/orbit.mp4", user: "ai.creator", cap: "How do I do this? One command.", likes: "212K", com: "9,870" },
  { src: "fx/glass-type.mp4", user: "edit.lab", cap: "Glass letters in 10 seconds", likes: "96.4K", com: "2,311" },
  { src: "fx/liquid-glass-graph.mp4", user: "marcelgrauu", cap: "Comment COMMANDS and I'll send it", likes: "1.2M", com: "41.7K" },
];
const SWIPES = [26, 48, 70];

const IgIcon: React.FC<{ d: string; label: string }> = ({ d, label }) => (
  <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 6 }}>
    <svg width={62} height={62} viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth={1.8} strokeLinejoin="round" strokeLinecap="round" style={{ filter: "drop-shadow(0 2px 4px rgba(0,0,0,0.5))" }}><path d={d} /></svg>
    <div style={{ fontFamily: SANS, fontWeight: 600, fontSize: 24, color: "#fff", textShadow: "0 1px 3px rgba(0,0,0,0.6)" }}>{label}</div>
  </div>
);

export const ReelFeed: React.FC<{ clip: ClipProps }> = ({ clip }) => {
  const f = useCurrentFrame();
  const intro = p(f, 0, 14, EXPO_OUT);
  let pos = 0;
  SWIPES.forEach((s) => (pos += p(f, s, s + 12, QUINT_INOUT)));
  const vel = SWIPES.reduce((v, s) => v + (p(f, s, s + 12, QUINT_INOUT) - p(f - 1, s, s + 12, QUINT_INOUT)), 0);
  return (
    <AbsoluteFill style={{ background: "#000", overflow: "hidden" }}>
      <div style={{ position: "absolute", inset: 0, transform: `scale(${1.08 - 0.08 * intro})`, borderRadius: 0 }}>
        {FEED.map((it, i) => {
          const y = (i - pos) * 1920;
          if (y < -1920 || y > 1920) return null;
          return (
            <div key={i} style={{ position: "absolute", left: 0, top: y, width: 1080, height: 1920, overflow: "hidden" }}>
              <div style={{ position: "absolute", inset: 0, filter: Math.abs(vel) > 0.02 ? `blur(${Math.min(12, Math.abs(vel) * 90)}px)` : "none" }}>
                {it.src === "clip" ? <Clip {...clip} /> : <OffthreadVideo src={staticFile(it.src)} muted startFrom={30} style={{ width: 1080, height: 1920 }} />}
              </div>
              <div style={{ position: "absolute", inset: 0, background: "linear-gradient(180deg, rgba(0,0,0,0.35) 0%, transparent 14%, transparent 70%, rgba(0,0,0,0.6) 100%)" }} />
              {/* right rail */}
              <div style={{ position: "absolute", right: 30, bottom: 300, display: "flex", flexDirection: "column", gap: 40 }}>
                <IgIcon d="M12 21s-7.5-4.6-9.3-9.2C1.4 8.4 3.6 5 7 5c2 0 3.4 1.1 5 3 1.6-1.9 3-3 5-3 3.4 0 5.6 3.4 4.3 6.8C19.5 16.4 12 21 12 21z" label={it.likes} />
                <IgIcon d="M21 12a8.5 8.5 0 0 1-12.6 7.4L3 21l1.6-5.2A8.5 8.5 0 1 1 21 12z" label={it.com} />
                <IgIcon d="M22 3L11 13M22 3l-7 18-4-8-8-4z" label="Share" />
              </div>
              <div style={{ position: "absolute", left: 36, right: 170, bottom: 120 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 16, fontFamily: SANS, fontWeight: 700, fontSize: 32, color: "#fff" }}>
                  <div style={{ width: 64, height: 64, borderRadius: 32, background: i % 2 ? "#3A3A3A" : Y, border: "3px solid #fff" }} />
                  {it.user}
                  <span style={{ border: "2px solid #fff", borderRadius: 12, padding: "4px 16px", fontSize: 26 }}>Follow</span>
                </div>
                <div style={{ marginTop: 18, fontFamily: SANS, fontSize: 30, color: "#fff", lineHeight: 1.3, textShadow: "0 1px 3px rgba(0,0,0,0.6)" }}>{it.cap}</div>
              </div>
            </div>
          );
        })}
      </div>
      {/* top bar of the app */}
      <div style={{ position: "absolute", left: 40, right: 40, top: 70, display: "flex", justifyContent: "space-between", alignItems: "center", fontFamily: TIGHT, fontWeight: 800, fontSize: 48, color: "#fff", textShadow: "0 2px 6px rgba(0,0,0,0.5)", opacity: intro }}>
        <span>Reels</span>
        <svg width={52} height={52} viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth={2}><circle cx="11" cy="11" r="7" /><path d="M20 20l-4-4" strokeLinecap="round" /></svg>
      </div>
    </AbsoluteFill>
  );
};
