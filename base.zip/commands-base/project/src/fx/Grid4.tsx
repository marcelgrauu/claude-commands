/**
 * Grid effects, part 4: the seven that were missing.
 * /typewriter-cut, /reel-fan, /growth-chart, /pixel-title, /couch-wall, /checklist, /all-at-once
 */
import React, { useEffect, useLayoutEffect, useRef, useState } from "react";
import { AbsoluteFill, Loop, OffthreadVideo, Img, continueRender, delayRender, interpolate, staticFile, useCurrentFrame } from "remotion";
import { EXPO_OUT, BACK_OUT, QUINT_INOUT, SOFT, p, hash } from "../kit";
import { ClipProps, Scene, MONO, SANS, TIGHT, Y } from "./common";

export const G4_DUR = 100;

/* small playing reel card used by fan, wall and all-at-once */
const Reel: React.FC<{ src: string; w: number; h: number; views?: string; r?: number }> = ({ src, w, h, views, r = 16 }) => (
  <div style={{ width: w, height: h, borderRadius: r, overflow: "hidden", background: "#111", border: "3px solid rgba(255,255,255,0.95)", boxShadow: "0 18px 40px rgba(0,0,0,0.5)", position: "relative" }}>
    <Loop durationInFrames={70}><OffthreadVideo src={staticFile(src)} muted startFrom={20} style={{ width: w, height: h, objectFit: "cover" }} /></Loop>
    {views && <>
      <div style={{ position: "absolute", left: 0, right: 0, bottom: 0, height: h * 0.3, background: "linear-gradient(transparent, rgba(0,0,0,0.7))" }} />
      <div style={{ position: "absolute", left: 8, bottom: 8, fontFamily: SANS, fontWeight: 700, fontSize: Math.max(14, w * 0.12), color: "#fff" }}>▶ {views}</div>
    </>}
  </div>
);

/* ---------------------------------------------------------- /typewriter-cut */
const TYPED = [
  "I gave Claude my raw clips and went to make coffee. When I came back the",
  "reel was cut, captioned and colour graded. I did not touch a timeline once.",
  "Every effect you see here came from one line typed into the chat. No plugin,",
  "no template, no editor. Just the command and a clip shot on a tripod.",
];
export const TypewriterCut: React.FC<{ clip: ClipProps; cut: ClipProps }> = ({ clip, cut }) => {
  const f = useCurrentFrame();
  const PAGES = 9;
  const cutAt = [0, 10, 18, 25, 31, 36, 40, 44, 48];
  let pg = 0;
  for (let i = 0; i < PAGES; i++) if (f >= cutAt[i]) pg = i;
  const since = f - cutAt[pg];
  const flick = pg > 0 && since < 3 ? (3 - since) * 18 : 0;
  const paperIn = p(f, 0, 14, EXPO_OUT);
  const page = (
    <div style={{ position: "absolute", left: 110, top: 120, width: 860, height: 760, transform: `translateY(${(1 - paperIn) * -500 - flick}px) rotate(${-2 + Math.sin(pg) * 1.4}deg)`, opacity: paperIn }}>
      <div style={{ position: "absolute", inset: 0, background: "#F4EFE3", boxShadow: "0 30px 70px rgba(0,0,0,0.5)", borderRadius: 4 }} />
      <div style={{ position: "absolute", inset: 0, backgroundImage: "radial-gradient(rgba(0,0,0,0.06) 1px, transparent 1.2px)", backgroundSize: "5px 5px" }} />
      <div style={{ position: "absolute", left: 60, right: 60, top: 70, fontFamily: "'Courier New', Courier, monospace", fontSize: 31, lineHeight: 1.75, color: "#2B2720" }}>
        {Array.from({ length: 11 }).map((_, k) => {
          const t = TYPED[(k + pg) % TYPED.length];
          const n = k === 10 ? Math.min(t.length, Math.max(0, Math.floor((since) * 6))) : t.length;
          return <div key={k} style={{ whiteSpace: "nowrap", overflow: "hidden", opacity: 0.88 - (k % 3) * 0.06 }}>{t.slice(0, n)}</div>;
        })}
      </div>
    </div>
  );
  // the locked word never moves: it sits outside the flicking page
  const word = (
    <div style={{ position: "absolute", left: 540 - 190, top: 360, width: 380, textAlign: "center", opacity: p(f, 8, 14) }}>
      <span style={{ fontFamily: "'Courier New', Courier, monospace", fontWeight: 700, fontSize: 92, color: "#C8231E", background: "rgba(244,239,227,0.96)", padding: "4px 18px", border: "4px solid #C8231E", borderRadius: 6, letterSpacing: 4 }}>EDIT</span>
    </div>
  );
  return <Scene clip={clip} cut={cut} dur={G4_DUR} push={[1, 1.06]} origin={[540, 700]} kicks={cutAt.slice(1)} back={<>{page}{word}</>} />;
};

/* ---------------------------------------------------------- /reel-fan */
export const FanLayer: React.FC<{ f: number; reels: string[]; at?: number }> = ({ f, reels, at = 4 }) => {
  const n = reels.length;
  return (
    <>
      {reels.map((src, i) => {
        const k = p(f, at + i * 2, at + 20 + i * 2, BACK_OUT);
        const ang = (i - (n - 1) / 2) * 15 * k;
        const lift = Math.abs(i - (n - 1) / 2) * 14 * k;
        return (
          <div key={i} style={{ position: "absolute", left: 545 - 95, top: 260 + lift, transformOrigin: "50% 160%", transform: `rotate(${ang + Math.sin((f + i * 9) / 24) * 1.2}deg) scale(${0.5 + 0.5 * k})`, opacity: Math.min(1, k * 2) }}>
            <Reel src={src} w={190} h={338} views={["1.2M", "860K", "3.4M", "2.1M", "910K", "4.8M", "1.7M"][i % 7]} />
          </div>
        );
      })}
    </>
  );
};
export const ReelFan: React.FC<{ clip: ClipProps; cut: ClipProps; reels: string[] }> = ({ clip, cut, reels }) => {
  const f = useCurrentFrame();
  return <Scene clip={clip} cut={cut} dur={G4_DUR} push={[1, 1.06]} origin={[545, 700]} back={<FanLayer f={f} reels={reels} />} />;
};

/* ---------------------------------------------------------- /growth-chart */
const BARS = [0.22, 0.34, 0.31, 0.5, 0.62, 0.78, 1];
export const GrowthChart: React.FC<{ clip: ClipProps; cut: ClipProps }> = ({ clip, cut }) => {
  const f = useCurrentFrame();
  const BW = 92;
  const GAP = 30;
  const X0 = (1080 - (BARS.length * BW + (BARS.length - 1) * GAP)) / 2 + 20;
  const BASE = 900;
  const MAXH = 640;
  const count = Math.round(interpolate(p(f, 14, 76, QUINT_INOUT), [0, 1], [0, 250000]));
  const bars = (
    <div style={{ position: "absolute", inset: 0, perspective: 1600, perspectiveOrigin: "540px 500px" }}>
      {BARS.map((v, i) => {
        const g = p(f, 12 + i * 5, 40 + i * 5, BACK_OUT);
        const h = MAXH * v * g;
        const last = i === BARS.length - 1;
        const D = 34; // fake depth of the 3D box
        return (
          <div key={i} style={{ position: "absolute", left: X0 + i * (BW + GAP), top: BASE - h, width: BW, height: h }}>
            {/* side */}
            <div style={{ position: "absolute", left: BW, top: -D / 2, width: D * 0.7, height: h + D / 2, background: last ? "#B79F00" : "#2C2C30", transform: "skewY(-35deg)", transformOrigin: "0 100%" }} />
            {/* top */}
            <div style={{ position: "absolute", left: 0, top: -D * 0.5, width: BW, height: D * 0.5, background: last ? "#FFF27A" : "#5A5A60", transform: "skewX(-55deg)", transformOrigin: "0 100%" }} />
            {/* front */}
            <div style={{ position: "absolute", inset: 0, background: last ? `linear-gradient(180deg, ${Y}, #D9BF00)` : "linear-gradient(180deg,#46464C,#2A2A2E)", boxShadow: last ? `0 0 40px rgba(255,229,0,0.35)` : undefined }} />
          </div>
        );
      })}
      <div style={{ position: "absolute", left: X0 - 20, top: BASE, width: BARS.length * (BW + GAP) + 20, height: 3, background: "rgba(255,255,255,0.4)" }} />
    </div>
  );
  const number = (
    <div style={{ position: "absolute", left: 0, right: 0, top: 120, textAlign: "center", opacity: p(f, 10, 22) }}>
      <div style={{ fontFamily: MONO, fontSize: 26, letterSpacing: 8, color: "rgba(255,255,255,0.75)" }}>FOLLOWERS</div>
      <div style={{ fontFamily: TIGHT, fontWeight: 800, fontSize: 150, letterSpacing: -7, color: "#fff", lineHeight: 1, fontVariantNumeric: "tabular-nums", textShadow: "0 6px 30px rgba(0,0,0,0.5)" }}>{count.toLocaleString("en-US")}</div>
    </div>
  );
  return <Scene clip={clip} cut={cut} dur={G4_DUR} push={[1, 1.05]} origin={[540, 760]} kicks={[76]} back={bars} hud={number} />;
};

/* ---------------------------------------------------------- /pixel-title */
const pxCache = new Map<string, { x: number; y: number }[]>();
const PixelCanvas: React.FC<{ word: string; f: number }> = ({ word, f }) => {
  const ref = useRef<HTMLCanvasElement>(null);
  const [handle] = useState(() => delayRender("pixel font"));
  const [ready, setReady] = useState(false);
  useEffect(() => {
    (document as any).fonts.load('900 200px "HN"').then(() => { setReady(true); continueRender(handle); });
  }, [handle]);
  useLayoutEffect(() => {
    if (!ready) return;
    const W = 1080;
    const H = 420;
    const cv = ref.current!;
    const ctx = cv.getContext("2d")!;
    if (!pxCache.has(word)) {
      const o = document.createElement("canvas");
      o.width = W; o.height = H;
      const g = o.getContext("2d")!;
      g.fillStyle = "#fff"; g.textAlign = "center"; g.textBaseline = "middle";
      let fs = 230; g.font = `900 ${fs}px "HN"`;
      const w = g.measureText(word).width;
      if (w > W * 0.88) { fs *= (W * 0.88) / w; g.font = `900 ${fs}px "HN"`; }
      g.fillText(word, W / 2, H / 2);
      const d = g.getImageData(0, 0, W, H).data;
      const pts: { x: number; y: number }[] = [];
      for (let y = 0; y < H; y += 11) for (let x = 0; x < W; x += 11) if (d[(y * W + x) * 4 + 3] > 128) pts.push({ x, y });
      pxCache.set(word, pts);
    }
    const pts = pxCache.get(word)!;
    ctx.clearRect(0, 0, W, H);
    pts.forEach((pt, i) => {
      const st = 4 + hash(i, 4) * 30;
      const e = p(f, st, st + 22, EXPO_OUT);
      const sx = 540 + (hash(i, 1) - 0.5) * 1600;
      const sy = 210 + (hash(i, 2) - 0.5) * 1400;
      const x = sx + (pt.x - sx) * e;
      const y = sy + (pt.y - sy) * e;
      const yellow = hash(i, 9) > 0.86;
      ctx.globalAlpha = 0.25 + 0.75 * e;
      ctx.fillStyle = yellow ? Y : "#fff";
      ctx.beginPath();
      ctx.arc(x, y, 4.2, 0, Math.PI * 2);
      ctx.fill();
    });
    ctx.globalAlpha = 1;
  }, [f, ready, word]);
  return <canvas ref={ref} width={1080} height={420} style={{ position: "absolute", left: 0, top: 170, width: 1080, height: 420, filter: "drop-shadow(0 0 10px rgba(255,255,255,0.35))" }} />;
};
export const PixelTitle: React.FC<{ clip: ClipProps; cut: ClipProps; word?: string }> = ({ clip, cut, word = "COMMANDS" }) => {
  const f = useCurrentFrame();
  return <Scene clip={clip} cut={cut} dur={G4_DUR} push={[1, 1.05]} origin={[540, 600]} back={<PixelCanvas word={word} f={f} />} />;
};

/* ---------------------------------------------------------- /couch-wall */
export const CouchWall: React.FC<{ clip: ClipProps; cut: ClipProps; reels: string[] }> = ({ clip, cut, reels }) => {
  const f = useCurrentFrame();
  const COLS = 4;
  const TW = 200;
  const TH = 300;
  const GX = (1080 - (COLS * TW + (COLS - 1) * 22)) / 2;
  const wall = (
    <>
      {Array.from({ length: 12 }).map((_, i) => {
        const r = Math.floor(i / COLS);
        const c = i % COLS;
        const k = p(f, 4 + (r * COLS + c) * 2.2, 18 + (r * COLS + c) * 2.2, BACK_OUT);
        return (
          <div key={i} style={{ position: "absolute", left: GX + c * (TW + 22), top: 70 + r * (TH + 24), transform: `scale(${0.4 + 0.6 * k}) rotate(${(hash(i, 3) - 0.5) * 3}deg)`, opacity: Math.min(1, k * 2) }}>
            <Reel src={reels[i % reels.length]} w={TW} h={TH} r={12} views={["2.1M", "640K", "1.3M", "4.4M", "780K", "3.2M", "1.1M", "920K", "5.6M", "2.7M", "1.9M", "830K"][i]} />
          </div>
        );
      })}
    </>
  );
  const total = Math.round(interpolate(p(f, 20, 80, QUINT_INOUT), [0, 1], [0, 27]));
  const label = (
    <div style={{ position: "absolute", left: 0, right: 0, top: 1300, textAlign: "center", opacity: p(f, 30, 42), transform: `translateY(${(1 - p(f, 30, 44, EXPO_OUT)) * 40}px)` }}>
      <div style={{ fontFamily: TIGHT, fontWeight: 800, fontSize: 120, letterSpacing: -5, color: "#fff", lineHeight: 0.9, textShadow: "0 8px 30px rgba(0,0,0,0.6)" }}>{total}M views</div>
      <div style={{ fontFamily: SANS, fontWeight: 500, fontSize: 36, color: "rgba(255,255,255,0.85)", marginTop: 12 }}>all edited by Claude</div>
    </div>
  );
  return <Scene clip={clip} cut={cut} dur={G4_DUR} push={[1, 1.05]} origin={[540, 760]} back={wall} front={label} />;
};

/* ---------------------------------------------------------- /checklist */
const STEPS = ["Drop your clips", "Type the command", "Post the reel"];
const TICKS = [30, 46, 62];
export const Checklist: React.FC<{ clip: ClipProps }> = ({ clip }) => {
  const f = useCurrentFrame();
  const enter = p(f, 4, 22, EXPO_OUT);
  const doneN = TICKS.filter((t) => f >= t + 4).length;
  const card = (
    <div style={{ position: "absolute", left: 120, top: 1010, width: 840, transform: `translateY(${(1 - enter) * 140}px) scale(${0.94 + 0.06 * enter})`, opacity: enter }}>
      <div style={{ borderRadius: 40, background: "rgba(248,247,251,0.97)", boxShadow: "0 30px 70px rgba(0,0,0,0.45)", padding: "34px 40px 22px" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 14 }}>
          <div style={{ fontFamily: SANS, fontWeight: 700, fontSize: 44, color: "#FF9F0A", letterSpacing: -0.5 }}>Today</div>
          <div style={{ fontFamily: SANS, fontWeight: 600, fontSize: 30, color: "rgba(0,0,0,0.4)", fontVariantNumeric: "tabular-nums" }}>{doneN} of {STEPS.length}</div>
        </div>
        {STEPS.map((s, i) => {
          const t = p(f, TICKS[i], TICKS[i] + 8, BACK_OUT);
          const strike = p(f, TICKS[i] + 3, TICKS[i] + 12, QUINT_INOUT);
          return (
            <div key={s} style={{ display: "flex", alignItems: "center", gap: 26, padding: "22px 0", borderTop: i ? "1.5px solid rgba(0,0,0,0.07)" : undefined }}>
              <div style={{ position: "relative", width: 56, height: 56, borderRadius: 28, border: `3px solid ${t > 0.05 ? "#FF9F0A" : "rgba(0,0,0,0.22)"}`, flex: "none" }}>
                <div style={{ position: "absolute", inset: 5, borderRadius: 23, background: "#FF9F0A", transform: `scale(${t})` }} />
                {t > 0.3 && <svg width={56} height={56} viewBox="0 0 24 24" style={{ position: "absolute", left: -3, top: -3 }} fill="none" stroke="#fff" strokeWidth={2.8} strokeLinecap="round" strokeLinejoin="round"><path d="M7 12.5l3.2 3.2L17.5 8.5" /></svg>}
              </div>
              <div style={{ position: "relative", fontFamily: SANS, fontWeight: 500, fontSize: 44, color: `rgba(20,20,24,${1 - 0.5 * strike})` }}>
                {s}
                <div style={{ position: "absolute", left: 0, top: "54%", height: 3, width: `${strike * 100}%`, background: "rgba(20,20,24,0.5)" }} />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
  return <Scene clip={clip} dur={G4_DUR} push={[1, 1.08]} origin={[540, 1200]} kicks={TICKS} focus={p(f, 4, 22, SOFT) * 0.3} front={card} />;
};

/* ---------------------------------------------------------- /all-at-once */
// orbit + fan on the same beat: the fan opens behind the head while reels orbit around it
export const AllAtOnce: React.FC<{ clip: ClipProps; cut: ClipProps; reels: string[] }> = ({ clip, cut, reels }) => {
  const f = useCurrentFrame();
  const n = 6;
  const orbit = (near: boolean) =>
    Array.from({ length: n }).map((_, i) => {
      const k = p(f, 4 + i * 2, 26 + i * 2, EXPO_OUT);
      const a = (i / n) * Math.PI * 2 + f * 0.035 + k * 1.5;
      const s = Math.sin(a);
      if (near ? s <= 0 : s > 0) return null;
      const x = 545 + 450 * Math.cos(a) * k;
      const y = 560 + 70 * s * k;
      const depth = (s + 1) / 2;
      return (
        <div key={i} style={{ position: "absolute", left: x - 55, top: y - 98, transform: `scale(${(0.7 + 0.45 * depth) * k}) rotateY(${-Math.cos(a) * 30}deg)`, opacity: k }}>
          <div style={{ filter: depth < 0.5 ? `blur(${(0.5 - depth) * 4}px) brightness(${0.7 + 0.6 * depth})` : undefined }}>
            <Reel src={reels[(i + 3) % reels.length]} w={110} h={196} r={14} />
          </div>
        </div>
      );
    });
  return <Scene clip={clip} cut={cut} dur={G4_DUR} push={[1, 1.07]} origin={[545, 760]} back={<><FanLayer f={f} reels={reels.slice(0, 5)} at={2} />{orbit(false)}</>} front={<>{orbit(true)}</>} />;
};
