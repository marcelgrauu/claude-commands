/**
 * Grid effects, part 6: the rest of @justyn.ai's list.
 * /kinetic-hook, /gravity-drop, /giant-captions, /prompt-bar, /storyboard-deck, /icon-strike,
 * /file-drop, /nle-timeline, /grade-slider, /eyedropper-grade, /film-look, /title-card,
 * /playing-grid, /video-card, /comment-cta, /comment-drop
 */
import React from "react";
import { AbsoluteFill, Img, Loop, OffthreadVideo, interpolate, staticFile, useCurrentFrame } from "remotion";
import { EXPO_OUT, EXPO_IN, BACK_OUT, QUINT_INOUT, SOFT, p, hash, Pointer, arc } from "../kit";
import { Clip, ClipProps, Cutout, Scene, FilmGrain, MONO, SANS, TIGHT, Y } from "./common";

export const G6_DUR = 100;

const Pill: React.FC<{ children: React.ReactNode; style?: React.CSSProperties }> = ({ children, style }) => (
  <div style={{ borderRadius: 40, background: "rgba(248,247,251,0.97)", boxShadow: "0 24px 60px rgba(0,0,0,0.4)", ...style }}>{children}</div>
);

/* ---------------------------------------------------------- /kinetic-hook */
// the hook line slams in word by word, each word a different weight, size and block
export const KineticHook: React.FC<{ clip: ClipProps; cut: ClipProps }> = ({ clip, cut }) => {
  const f = useCurrentFrame();
  const W = [
    { t: "STOP", at: 4, size: 200, w: 900, bg: Y, c: "#0A0A0A", x: 80, y: 110, r: -3 },
    { t: "editing", at: 12, size: 130, w: 300, bg: "", c: "#fff", x: 130, y: 330, r: 0, serif: true },
    { t: "BY HAND", at: 20, size: 140, w: 900, bg: "#0A0A0A", c: "#fff", x: 330, y: 460, r: 2 },
  ];
  const kicks = W.map((w) => w.at + 2);
  const words = W.map((w) => {
    const k = p(f, w.at, w.at + 8, BACK_OUT);
    return (
      <div key={w.t} style={{ position: "absolute", left: w.x, top: w.y, transform: `rotate(${w.r}deg) scale(${1.6 - 0.6 * k})`, opacity: Math.min(1, k * 3), transformOrigin: "0 50%" }}>
        <div style={{ display: "inline-block", padding: w.bg ? "0 26px" : 0, background: w.bg || undefined, fontFamily: w.serif ? "AG, serif" : TIGHT, fontStyle: w.serif ? "italic" : "normal", fontWeight: w.w, fontSize: w.size, lineHeight: 1.02, letterSpacing: w.serif ? -2 : -9, color: w.c, textShadow: w.bg ? undefined : "0 6px 24px rgba(0,0,0,0.5)" }}>{w.t}</div>
      </div>
    );
  });
  return <Scene clip={clip} cut={cut} dur={G6_DUR} push={[1, 1.05]} origin={[540, 700]} kicks={kicks} back={<>{words}</>} />;
};

/* ---------------------------------------------------------- /gravity-drop */
// letters fall from above with gravity, bounce and settle into the word
export const GravityDrop: React.FC<{ clip: ClipProps; cut: ClipProps }> = ({ clip, cut }) => {
  const f = useCurrentFrame();
  const word = "DROP";
  const letters = word.split("").map((ch, i) => {
    const st = 6 + i * 5;
    const t = Math.max(0, f - st) / 30;
    // ballistic fall with two damped bounces
    const g = 3600;
    const drop = 900;
    let y = -drop;
    const tf = Math.sqrt((2 * drop) / g);
    if (t < tf) y = -drop + 0.5 * g * t * t;
    else {
      let tt = t - tf;
      let v = g * tf * 0.42;
      y = 0;
      for (let b = 0; b < 3; b++) {
        const tb = (2 * v) / g;
        if (tt < tb) { y = -(v * tt - 0.5 * g * tt * tt); break; }
        tt -= tb; v *= 0.4;
      }
    }
    const squash = Math.max(0, 1 - Math.abs(t - tf) * 18) * 0.18;
    return (
      <span key={i} style={{ display: "inline-block", transform: `translateY(${f < st ? -2000 : y}px) scale(${1 + squash}, ${1 - squash}) rotate(${(hash(i, 2) - 0.5) * 8 * Math.max(0, 1 - t)}deg)`, transformOrigin: "50% 100%" }}>{ch}</span>
    );
  });
  const title = (
    <>
      <div style={{ position: "absolute", left: 0, right: 0, top: 180, textAlign: "center", fontFamily: "AG, serif", fontStyle: "italic", fontSize: 110, color: Y, opacity: p(f, 2, 10) }}>gravity</div>
      <div style={{ position: "absolute", left: 0, right: 0, top: 300, textAlign: "center", fontFamily: "AG, serif", fontWeight: 600, fontSize: 280, letterSpacing: -8, color: "#F5F1E8", lineHeight: 1, textShadow: "0 12px 40px rgba(0,0,0,0.45)" }}>{letters}</div>
    </>
  );
  return <Scene clip={clip} cut={cut} dur={G6_DUR} push={[1, 1.05]} origin={[540, 700]} kicks={[16, 21, 26, 31]} back={title} />;
};

/* ---------------------------------------------------------- /giant-captions */
// one giant caption word behind you, the small caption under it, both in sync
const CAPS = [{ w: "GIANT", s: "giant" }, { w: "CAPTIONS", s: "captions" }, { w: "HIT", s: "hit" }, { w: "HARDER", s: "harder." }];
export const GiantCaptions: React.FC<{ clip: ClipProps; cut: ClipProps }> = ({ clip, cut }) => {
  const f = useCurrentFrame();
  const idx = Math.min(CAPS.length - 1, Math.floor(f / 22));
  const since = f - idx * 22;
  const k = p(since, 0, 8, EXPO_OUT);
  const big = (
    <div style={{ position: "absolute", left: -60, right: -60, top: 300, textAlign: "center", fontFamily: TIGHT, fontWeight: 900, fontSize: CAPS[idx].w.length > 6 ? 170 : CAPS[idx].w.length > 4 ? 205 : 320, letterSpacing: -10, color: idx % 2 ? Y : "#fff", lineHeight: 1, transform: `scale(${1.25 - 0.25 * k})`, opacity: k, textShadow: "0 14px 50px rgba(0,0,0,0.45)" }}>{CAPS[idx].w}</div>
  );
  const small = (
    <div style={{ position: "absolute", left: 0, right: 0, top: 1240, textAlign: "center" }}>
      <span style={{ fontFamily: SANS, fontWeight: 800, fontSize: 64, color: "#fff", background: "rgba(0,0,0,0.55)", padding: "8px 22px", borderRadius: 14 }}>{CAPS.slice(0, idx + 1).map((c) => c.s).join(" ")}</span>
    </div>
  );
  return <Scene clip={clip} cut={cut} dur={G6_DUR} push={[1, 1.05]} origin={[540, 700]} kicks={[0, 22, 44, 66]} back={big} front={small} />;
};

/* ---------------------------------------------------------- /prompt-bar */
// a clean prompt bar floats over your head, the prompt types itself and sends
export const PromptBar: React.FC<{ clip: ClipProps }> = ({ clip }) => {
  const f = useCurrentFrame();
  const enter = p(f, 2, 18, EXPO_OUT);
  const txt = "Add captions, cut the silences, make it pop";
  const n = Math.max(0, Math.min(txt.length, Math.floor((f - 16) / 0.85)));
  const SEND = 70;
  const sent = p(f, SEND, SEND + 10, EXPO_OUT);
  const bar = (
    <div style={{ position: "absolute", left: 70, top: 260, width: 940, transform: `translateY(${(1 - enter) * -60 - sent * 30}px) scale(${0.95 + 0.05 * enter})`, opacity: enter * (1 - sent * 0.15) }}>
      <div style={{ fontFamily: MONO, fontSize: 22, letterSpacing: 6, color: "rgba(255,255,255,0.8)", marginBottom: 14, marginLeft: 10 }}>PROMPT</div>
      <Pill style={{ display: "flex", alignItems: "center", padding: "26px 26px 26px 40px", gap: 20 }}>
        <div style={{ flex: 1, fontFamily: SANS, fontSize: 38, color: n ? "#141418" : "#9A9AA2", whiteSpace: "nowrap", overflow: "hidden" }}>
          {n ? txt.slice(0, n) : "Describe the edit…"}{f > 14 && f < SEND && Math.floor(f / 6) % 2 === 0 && <span style={{ color: "#D97757" }}>▍</span>}
        </div>
        <div style={{ width: 78, height: 78, borderRadius: 39, background: f >= SEND ? Y : "#141418", display: "grid", placeItems: "center", transform: `scale(${1 - 0.15 * Math.sin(p(f, SEND, SEND + 6, (x) => x) * Math.PI)})` }}>
          <svg width={38} height={38} viewBox="0 0 24 24" fill="none" stroke={f >= SEND ? "#111" : "#fff"} strokeWidth={2.6} strokeLinecap="round" strokeLinejoin="round"><path d="M12 19V5M6 11l6-6 6 6" /></svg>
        </div>
      </Pill>
    </div>
  );
  return <Scene clip={clip} dur={G6_DUR} push={[1, 1.05]} origin={[540, 600]} kicks={[SEND]} front={bar} />;
};

/* ---------------------------------------------------------- /storyboard-deck */
// a deck of storyboard frames deals out in a row across your chest
export const StoryboardDeck: React.FC<{ clip: ClipProps; frames: string[] }> = ({ clip, frames }) => {
  const f = useCurrentFrame();
  const n = Math.min(5, frames.length);
  const deck = frames.slice(0, n).map((src, i) => {
    const k = p(f, 8 + i * 6, 24 + i * 6, EXPO_OUT);
    const x = interpolate(k, [0, 1], [440, 60 + i * 196]);
    const r = interpolate(k, [0, 1], [-8 + i * 3, (i - 2) * 2]);
    return (
      <div key={i} style={{ position: "absolute", left: x, top: 1240 + Math.abs(i - 2) * 10 * k, width: 180, transform: `rotate(${r}deg)`, zIndex: i }}>
        <div style={{ background: "#FAFAF7", padding: 10, paddingBottom: 46, boxShadow: "0 18px 40px rgba(0,0,0,0.45)", borderRadius: 6 }}>
          <Img src={staticFile(src)} style={{ width: 160, height: 220, objectFit: "cover", display: "block", borderRadius: 3 }} />
          <div style={{ position: "absolute", left: 12, bottom: 12, fontFamily: MONO, fontSize: 16, color: "#555" }}>SHOT {String(i + 1).padStart(2, "0")}</div>
        </div>
      </div>
    );
  });
  return <Scene clip={clip} dur={G6_DUR} push={[1, 1.05]} origin={[540, 1200]} front={<>{deck}</>} />;
};

/* ---------------------------------------------------------- /icon-strike */
// the old editing apps get struck out one by one, a word in serif italic above
const ICONS = [
  { bg: "#0B0B0B", node: <div style={{ fontFamily: TIGHT, fontWeight: 800, fontSize: 52, color: "#fff" }}>CC</div> },
  { bg: "linear-gradient(135deg,#FF2D87,#7B2CFF 55%,#1E90FF)", node: <div style={{ width: 60, height: 60, borderRadius: 16, border: "7px solid #fff" }} /> },
  { bg: "#1E0A3C", node: <div style={{ fontFamily: TIGHT, fontWeight: 800, fontSize: 52, color: "#C9A7FF" }}>Pr</div> },
];
export const IconStrike: React.FC<{ clip: ClipProps; cut: ClipProps }> = ({ clip, cut }) => {
  const f = useCurrentFrame();
  const icons = ICONS.map((ic, i) => {
    const k = p(f, 4 + i * 5, 18 + i * 5, BACK_OUT);
    const st = p(f, 34 + i * 10, 42 + i * 10, QUINT_INOUT);
    const x = [130, 450, 770][i];
    return (
      <div key={i} style={{ position: "absolute", left: x, top: 290, width: 180, height: 180, transform: `scale(${k}) rotate(${(i - 1) * 6}deg)`, opacity: 1 - st * 0.45 }}>
        <div style={{ width: 180, height: 180, borderRadius: 44, background: ic.bg, display: "grid", placeItems: "center", boxShadow: "0 20px 40px rgba(0,0,0,0.45)" }}>{ic.node}</div>
        <svg width={240} height={240} style={{ position: "absolute", left: -30, top: -30, overflow: "visible" }}>
          <path d="M 20 220 L 220 20" stroke="#FF3B30" strokeWidth={16} strokeLinecap="round" pathLength={1} strokeDasharray={`${st} 1`} />
        </svg>
      </div>
    );
  });
  const word = <div style={{ position: "absolute", left: 0, right: 0, top: 130, textAlign: "center", fontFamily: "AG, serif", fontStyle: "italic", fontSize: 110, color: "#fff", opacity: p(f, 30, 40), textShadow: "0 6px 24px rgba(0,0,0,0.5)" }}>no more <span style={{ color: Y }}>apps</span></div>;
  return <Scene clip={clip} cut={cut} dur={G6_DUR} push={[1, 1.05]} origin={[540, 600]} kicks={[38, 48, 58]} back={<>{icons}{word}</>} />;
};

/* ---------------------------------------------------------- /file-drop */
// a dashed drop zone, your clip file flies in, upload bar fills, "Ready"
export const FileDrop: React.FC<{ clip: ClipProps; thumb: string }> = ({ clip, thumb }) => {
  const f = useCurrentFrame();
  const zone = p(f, 2, 16, EXPO_OUT);
  const fly = p(f, 18, 38, QUINT_INOUT);
  const [x, y] = arc(fly, [980, 1500], [540, 420], 0.3);
  const up = p(f, 40, 76, QUINT_INOUT);
  const ready = p(f, 78, 88, BACK_OUT);
  const ui = (
    <>
      <div style={{ position: "absolute", left: 180, top: 210, width: 720, height: 420, borderRadius: 40, background: "rgba(248,247,251,0.92)", border: `4px dashed ${fly >= 1 ? "#34C759" : "rgba(0,0,0,0.25)"}`, transform: `scale(${0.9 + 0.1 * zone})`, opacity: zone, boxShadow: "0 24px 60px rgba(0,0,0,0.35)" }}>
        {fly < 0.95 && <div style={{ position: "absolute", left: 0, right: 0, top: 150, textAlign: "center" }}>
          <svg width={70} height={70} viewBox="0 0 24 24" fill="none" stroke="#6E6E78" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round"><path d="M12 4v11M7 10l5 5 5-5M5 20h14" /></svg>
          <div style={{ fontFamily: SANS, fontWeight: 600, fontSize: 36, color: "#4A4A52", marginTop: 10 }}>Drop raw footage</div>
        </div>}
        {fly >= 0.95 && (
          <div style={{ position: "absolute", left: 40, right: 40, top: 240 }}>
            <div style={{ display: "flex", justifyContent: "space-between", fontFamily: MONO, fontSize: 24, color: "#4A4A52" }}><span>raw_take_01.mov</span><span>{Math.round(up * 100)}%</span></div>
            <div style={{ height: 14, borderRadius: 7, background: "#E5E4EA", marginTop: 14, overflow: "hidden" }}><div style={{ width: `${up * 100}%`, height: "100%", background: "#34C759" }} /></div>
            <div style={{ marginTop: 20, fontFamily: SANS, fontWeight: 700, fontSize: 34, color: "#1E9E4A", transform: `scale(${ready})`, transformOrigin: "0 50%", opacity: ready }}>✓ Ready to edit</div>
          </div>
        )}
      </div>
      {f >= 18 && (
        <div style={{ position: "absolute", left: x - 70, top: y - (fly >= 1 ? 30 : 90), width: 140, height: 180, transform: `rotate(${(1 - fly) * 18}deg) scale(${1.2 - 0.4 * fly})`, borderRadius: 16, overflow: "hidden", border: "4px solid #fff", boxShadow: "0 20px 40px rgba(0,0,0,0.45)" }}>
          <Img src={staticFile(thumb)} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
        </div>
      )}
    </>
  );
  return <Scene clip={clip} dur={G6_DUR} push={[1, 1.04]} origin={[540, 500]} kicks={[38]} front={ui} />;
};

/* ---------------------------------------------------------- /nle-timeline */
// A real editing timeline slides up across the chest as a dark glass panel: ruler, a caption
// track, a filmstrip video track, the voice waveform and the music bed. The clips build in,
// the dead air on the voice gets flagged, cut, and everything ripples left. Then the yellow
// playhead runs and the timecode counts with it.
const NLE_SIL: [number, number][] = [[0.27, 0.35], [0.6, 0.67]];
const NLE_GONE = NLE_SIL.reduce((a, [s, e]) => a + (e - s), 0);
// where a point of the timeline lands after the ripple (r = 0 before, 1 after)
const ripple = (x: number, r: number) => x - NLE_SIL.reduce((a, [s, e]) => a + Math.max(0, Math.min(x, e) - s), 0) * r;
const Wave: React.FC<{ seed: number; w: number; h: number; color: string; dense?: number }> = ({ seed, w, h, color, dense = 5 }) => (
  <svg width={w} height={h} style={{ position: "absolute", left: 0, top: 0 }}>
    {Array.from({ length: Math.max(1, Math.floor(w / dense)) }, (_, i) => {
      const a = 0.18 + 0.82 * Math.abs(Math.sin(i * 0.37 + seed) * Math.sin(i * 0.11 + seed * 2.1)) * (0.6 + 0.4 * hash(i, seed));
      const bh = Math.max(2, a * (h - 10));
      return <rect key={i} x={i * dense + 1} y={(h - bh) / 2} width={Math.max(1.5, dense - 2.2)} height={bh} rx={1} fill={color} />;
    })}
  </svg>
);
export const NleTimeline: React.FC<{ clip: ClipProps; still?: string }> = ({ clip, still = "thumbs/talk3_1.jpg" }) => {
  const f = useCurrentFrame();
  const up = p(f, 2, 22, EXPO_OUT);
  const flag = p(f, 34, 42, EXPO_OUT);
  const cutOut = p(f, 44, 50, EXPO_OUT);
  const rip = p(f, 48, 60, QUINT_INOUT);
  const head = p(f, 60, G6_DUR, (x) => x) * (1 - NLE_GONE);
  const PW = 1000;
  const L = 74;
  const TW = PW - L - 26;
  const X = (u: number) => L + ripple(u, rip) * TW;
  const frames = Math.round(head * 30 * 24);
  const tc = `00:00:${String(Math.floor(frames / 24)).padStart(2, "0")}:${String(frames % 24).padStart(2, "0")}`;
  const ROWS = { t: 112, v: 160, a1: 284, a2: 372 };
  // one clip on the timeline: grows in from its left edge, follows the ripple
  const seg = (u0: number, u1: number, at: number, top: number, h: number, body: (w: number) => React.ReactNode, bg: string) => {
    const g = p(f, at, at + 14, EXPO_OUT);
    const x0 = X(u0);
    const w = Math.max(0, (X(u1) - x0) * g - 3);
    return (
      <div style={{ position: "absolute", left: x0, top, width: w, height: h, borderRadius: 9, overflow: "hidden", background: bg, boxShadow: "inset 0 0 0 1px rgba(255,255,255,0.10)" }}>{body(w)}</div>
    );
  };
  // voice and video split around the silences, so the cut pieces can drop out
  const SPANS: [number, number][] = [[0, 0.27], [0.35, 0.6], [0.67, 1]];
  const panel = (
    <div style={{ position: "absolute", left: 40, top: 1150, width: PW, height: 452, transform: `translateY(${(1 - up) * 520}px)`, opacity: Math.min(1, up * 2.5) }}>
      <div style={{ position: "absolute", inset: 0, borderRadius: 34, background: "rgba(16,16,18,0.86)", backdropFilter: "blur(30px) saturate(1.4)", WebkitBackdropFilter: "blur(30px) saturate(1.4)", boxShadow: "0 40px 90px rgba(0,0,0,0.55), inset 0 0 0 1px rgba(255,255,255,0.09), inset 0 1px 0 rgba(255,255,255,0.14)" }} />
      {/* header: transport, timecode, Claude's state */}
      <div style={{ position: "absolute", left: 28, right: 24, top: 20, height: 40, display: "flex", alignItems: "center", gap: 18 }}>
        <svg width={22} height={22} viewBox="0 0 24 24"><path d="M7 4.5v15l12-7.5z" fill="#fff" /></svg>
        <div style={{ fontFamily: SANS, fontWeight: 700, fontSize: 30, letterSpacing: -0.5, color: "#fff", fontVariantNumeric: "tabular-nums" }}>{tc}</div>
        <div style={{ flex: 1 }} />
        <div style={{ display: "flex", alignItems: "center", gap: 10, height: 40, padding: "0 16px", borderRadius: 20, background: "rgba(255,255,255,0.08)", fontFamily: SANS, fontWeight: 500, fontSize: 21, color: "rgba(255,255,255,0.86)" }}>
          <span style={{ width: 9, height: 9, borderRadius: 5, background: Y, boxShadow: `0 0 10px ${Y}` }} />
          {f < 34 ? "Claude is editing" : f < 60 ? "Cutting the dead air" : "Ready to export"}
        </div>
      </div>
      {/* ruler */}
      <div style={{ position: "absolute", left: L, width: TW, top: 74, height: 26, borderBottom: "1px solid rgba(255,255,255,0.08)" }}>
        {Array.from({ length: 41 }, (_, i) => (
          <div key={i} style={{ position: "absolute", left: (i / 40) * TW, bottom: 0, width: 1, height: i % 5 === 0 ? 12 : 6, background: "rgba(255,255,255,0.28)" }}>
            {i % 10 === 0 && <div style={{ position: "absolute", left: 4, bottom: 8, fontFamily: MONO, fontSize: 15, color: "rgba(255,255,255,0.4)", whiteSpace: "nowrap" }}>{`00:${String(i / 2).padStart(2, "0")}`}</div>}
          </div>
        ))}
      </div>
      {/* track labels */}
      {([["T", ROWS.t, 36], ["V1", ROWS.v, 112], ["A1", ROWS.a1, 76], ["A2", ROWS.a2, 52]] as const).map(([l, t, h]) => (
        <div key={l} style={{ position: "absolute", left: 26, top: t, height: h, display: "flex", alignItems: "center", fontFamily: MONO, fontSize: 17, letterSpacing: 1, color: "rgba(255,255,255,0.42)" }}>{l}</div>
      ))}
      {/* captions */}
      {[[0.02, 0.13], [0.15, 0.26], [0.36, 0.5], [0.52, 0.59], [0.68, 0.84], [0.86, 0.98]].map(([a, b], i) => (
        <React.Fragment key={`t${i}`}>{seg(a, b, 12 + i * 2, ROWS.t, 36, () => <div style={{ padding: "0 10px", lineHeight: "36px", fontFamily: SANS, fontWeight: 700, fontSize: 15, color: "#0A0A0A", whiteSpace: "nowrap" }}>{["STOP", "editing", "by hand", "one", "prompt", "done"][i]}</div>, Y)}</React.Fragment>
      ))}
      {/* video filmstrip and voice, split around the silences */}
      {SPANS.map(([a, b], i) => (
        <React.Fragment key={`v${i}`}>
          {seg(a, b, 6 + i * 3, ROWS.v, 112, (w) => (
            <div style={{ display: "flex", height: "100%" }}>
              {Array.from({ length: Math.ceil(w / 63) + 1 }, (_, k) => (
                <Img key={k} src={staticFile(still)} style={{ flex: "none", width: 63, height: 112, objectFit: "cover", objectPosition: `${50 + Math.sin(k * 1.7 + i) * 8}% 30%`, borderRight: "1px solid rgba(0,0,0,0.5)", filter: "saturate(0.9)" }} />
              ))}
            </div>
          ), "#222")}
          {seg(a, b, 9 + i * 3, ROWS.a1, 76, (w) => <Wave seed={i * 3 + 1} w={Math.max(1, w)} h={76} color="rgba(255,255,255,0.78)" />, "rgba(255,255,255,0.10)")}
        </React.Fragment>
      ))}
      {/* the dead air: flagged, then cut out before the ripple closes it */}
      {NLE_SIL.map(([s, e], i) => {
        const x0 = X(s);
        const w = Math.max(0, X(e) - x0 - 3);
        return (
          <React.Fragment key={`s${i}`}>
            {[ROWS.v, ROWS.a1].map((t, j) => (
              <div key={j} style={{ position: "absolute", left: x0, top: t, width: w, height: j === 0 ? 112 : 76, borderRadius: 9, overflow: "hidden", opacity: p(f, 8 + i * 3, 20 + i * 3, EXPO_OUT) * (1 - cutOut), transform: `scaleY(${1 - cutOut * 0.3})`,
                background: `repeating-linear-gradient(135deg, rgba(255,255,255,${0.05 + flag * 0.04}) 0 6px, transparent 6px 12px)`, boxShadow: `inset 0 0 0 ${1 + flag}px rgba(255,90,70,${0.15 + flag * 0.65})` }}>
                {j === 1 && <Wave seed={9 + i} w={Math.max(1, w)} h={76} color={`rgba(255,255,255,${0.16 * (1 - flag * 0.5)})`} dense={6} />}
              </div>
            ))}
            <div style={{ position: "absolute", left: x0 + w / 2, top: ROWS.v - 30, transform: `translateX(-50%) scale(${0.9 + flag * 0.1})`, opacity: flag * (1 - cutOut), padding: "3px 9px", borderRadius: 8, background: "rgba(255,90,70,0.9)", fontFamily: SANS, fontWeight: 700, fontSize: 14, color: "#fff", whiteSpace: "nowrap" }}>dead air</div>
          </React.Fragment>
        );
      })}
      {/* music bed */}
      {seg(0, 1, 16, ROWS.a2, 52, (w) => <Wave seed={21} w={Math.max(1, w)} h={52} color="rgba(255,229,0,0.55)" dense={4} />, "rgba(255,229,0,0.10)")}
      {/* playhead */}
      <div style={{ position: "absolute", left: L + head * TW - 1, top: 84, bottom: 22, width: 2, background: Y, boxShadow: `0 0 12px rgba(255,229,0,0.6)`, opacity: p(f, 18, 26, EXPO_OUT) }}>
        <div style={{ position: "absolute", left: -8, top: -6, width: 18, height: 18, borderRadius: "5px 5px 9px 9px", background: Y }} />
      </div>
    </div>
  );
  return <Scene clip={clip} dur={G6_DUR} push={[1, 1.04]} origin={[540, 1100]} kicks={[46]} front={panel} />;
};

/* ---------------------------------------------------------- /grade-slider */
// a before/after slider sweeps across: flat log on the left, graded on the right
export const GradeSlider: React.FC<{ clip: ClipProps }> = ({ clip }) => {
  const f = useCurrentFrame();
  const pos = interpolate(f, [0, 12, 40, 62, 84, G6_DUR], [0.9, 0.9, 0.2, 0.75, 0.5, 0.5], { easing: QUINT_INOUT, extrapolateRight: "clamp" });
  const X = pos * 1080;
  return (
    <AbsoluteFill style={{ background: "#000", overflow: "hidden" }}>
      <AbsoluteFill style={{ filter: "contrast(1.28) saturate(1.55) brightness(1.02) sepia(0.18)" }}><Clip {...clip} /></AbsoluteFill>
      <AbsoluteFill style={{ clipPath: `inset(0 ${1080 - X}px 0 0)`, filter: "contrast(0.62) saturate(0.25) brightness(1.18)" }}><Clip {...clip} /></AbsoluteFill>
      <div style={{ position: "absolute", left: X - 2, top: 0, bottom: 0, width: 4, background: "#fff", boxShadow: "0 0 20px rgba(0,0,0,0.4)" }} />
      <div style={{ position: "absolute", left: X - 40, top: 1130, width: 80, height: 80, borderRadius: 40, background: "#fff", display: "grid", placeItems: "center", boxShadow: "0 10px 30px rgba(0,0,0,0.4)" }}>
        <svg width={40} height={40} viewBox="0 0 24 24" fill="none" stroke="#111" strokeWidth={2.6} strokeLinecap="round" strokeLinejoin="round"><path d="M9 6l-6 6 6 6M15 6l6 6-6 6" /></svg>
      </div>
      <div style={{ position: "absolute", left: Math.min(X - 190, 40), top: 1150, fontFamily: MONO, fontSize: 26, letterSpacing: 5, color: "#fff", background: "rgba(0,0,0,0.5)", padding: "8px 14px", borderRadius: 10, opacity: X > 250 ? 1 : 0 }}>BEFORE</div>
      <div style={{ position: "absolute", left: Math.max(X + 60, 0), top: 1150, fontFamily: MONO, fontSize: 26, letterSpacing: 5, color: "#111", background: Y, padding: "8px 14px", borderRadius: 10, opacity: X < 820 ? 1 : 0 }}>AFTER</div>
      <FilmGrain />
    </AbsoluteFill>
  );
};

/* ---------------------------------------------------------- /eyedropper-grade */
// an eyedropper samples colours off the shot and builds the grade palette
const SW = [{ x: 300, y: 500, c: "#2B2E36", hex: "#2B2E36" }, { x: 760, y: 420, c: "#C8C9CB", hex: "#C8C9CB" }, { x: 560, y: 880, c: "#C9957A", hex: "#C9957A" }, { x: 520, y: 1700, c: "#8C4F2E", hex: "#8C4F2E" }];
export const EyedropperGrade: React.FC<{ clip: ClipProps }> = ({ clip }) => {
  const f = useCurrentFrame();
  const seg = Math.min(SW.length - 1, Math.floor(Math.max(0, f - 8) / 18));
  const local = Math.max(0, f - 8 - seg * 18) / 18;
  const from = seg === 0 ? [980, 1600] as [number, number] : [SW[seg - 1].x, SW[seg - 1].y] as [number, number];
  const [x, y] = arc(QUINT_INOUT(Math.min(1, local * 1.4)), from, [SW[seg].x, SW[seg].y], 0.2);
  const picked = SW.filter((_, i) => f >= 8 + i * 18 + 13).length;
  const graded = p(f, 82, 96, SOFT);
  return (
    <AbsoluteFill style={{ background: "#000", overflow: "hidden" }}>
      <AbsoluteFill style={{ filter: `contrast(${1 + 0.15 * graded}) saturate(${1 + 0.3 * graded}) sepia(${0.15 * graded})` }}><Clip {...clip} /></AbsoluteFill>
      <svg width={70} height={70} viewBox="0 0 24 24" style={{ position: "absolute", left: x - 6, top: y - 64, filter: "drop-shadow(0 4px 8px rgba(0,0,0,0.5))" }} fill="#fff" stroke="#111" strokeWidth={1.2}><path d="M20.7 5.6l-2.3-2.3a1 1 0 0 0-1.4 0l-3 3-1-1-1.4 1.4 1 1L4 16.3V20h3.7l8.6-8.6 1 1 1.4-1.4-1-1 3-3a1 1 0 0 0 0-1.4z" /></svg>
      {f >= 8 + seg * 18 + 13 && <div style={{ position: "absolute", left: SW[seg].x - 40, top: SW[seg].y - 40, width: 80, height: 80, borderRadius: 40, border: `4px solid ${Y}`, transform: `scale(${p(f, 8 + seg * 18 + 13, 8 + seg * 18 + 20, EXPO_OUT) * 1.4})`, opacity: 1 - p(f, 8 + seg * 18 + 13, 8 + seg * 18 + 20) }} />}
      <div style={{ position: "absolute", left: 60, right: 60, top: 1260, padding: "22px 26px", borderRadius: 30, background: "rgba(248,247,251,0.96)", display: "flex", gap: 18, boxShadow: "0 24px 60px rgba(0,0,0,0.4)", opacity: p(f, 4, 14) }}>
        {SW.map((s, i) => (
          <div key={i} style={{ flex: 1, opacity: i < picked ? 1 : 0.25, transform: `scale(${i < picked ? 1 : 0.9})` }}>
            <div style={{ height: 90, borderRadius: 16, background: i < picked ? s.c : "#E5E4EA" }} />
            <div style={{ fontFamily: MONO, fontSize: 20, color: "#333", marginTop: 8 }}>{i < picked ? s.hex : "------"}</div>
          </div>
        ))}
      </div>
      <FilmGrain />
    </AbsoluteFill>
  );
};

/* ---------------------------------------------------------- /film-look */
// the shot becomes 16mm film: gate, sprockets, weave, halation, light leak, grain
export const FilmLook: React.FC<{ clip: ClipProps }> = ({ clip }) => {
  const f = useCurrentFrame();
  const on = p(f, 6, 20, SOFT);
  const weave = [Math.sin(f * 1.7) * 2 * on, Math.cos(f * 2.3) * 3 * on];
  const leak = Math.max(0, Math.sin((f - 20) / 14)) * on;
  return (
    <AbsoluteFill style={{ background: "#0B0906", overflow: "hidden" }}>
      <AbsoluteFill style={{ transform: `translate(${weave[0]}px, ${weave[1]}px) scale(${1 - 0.12 * on})` }}>
        <AbsoluteFill style={{ filter: `sepia(${0.35 * on}) contrast(${1 + 0.12 * on}) saturate(${1 - 0.2 * on}) brightness(${1 + 0.05 * on})`, borderRadius: 30 * on, overflow: "hidden" }}><Clip {...clip} /></AbsoluteFill>
        <AbsoluteFill style={{ background: `radial-gradient(ellipse at 85% 20%, rgba(255,110,40,${0.45 * leak}), transparent 50%)`, mixBlendMode: "screen", borderRadius: 30 * on }} />
      </AbsoluteFill>
      {/* sprockets */}
      {[0, 1].map((side) => (
        <div key={side} style={{ position: "absolute", top: 0, bottom: 0, [side ? "right" : "left"]: 18, width: 44, opacity: on, backgroundImage: "repeating-linear-gradient(180deg, transparent 0 34px, #E9E2D2 34px 70px)", WebkitMaskImage: "linear-gradient(90deg,#000,#000)", transform: `translateY(${(f * 9) % 70}px)` } as React.CSSProperties} />
      ))}
      <div style={{ position: "absolute", left: 90, bottom: 60, fontFamily: MONO, fontSize: 22, color: "#E9B36A", letterSpacing: 3, opacity: on }}>KODAK 250D  ▸  {String(12 + Math.floor(f / 8)).padStart(3, "0")}</div>
      <FilmGrain opacity={0.16} />
      {Math.floor(f / 5) % 7 === 0 && <AbsoluteFill style={{ background: "rgba(255,240,220,0.06)" }} />}
    </AbsoluteFill>
  );
};

/* ---------------------------------------------------------- /title-card */
// a full frame title card with timecode, then it wipes open on the shot
export const TitleCard: React.FC<{ clip: ClipProps; title?: string }> = ({ clip, title = "THE EDIT" }) => {
  const f = useCurrentFrame();
  const t = p(f, 4, 22, EXPO_OUT);
  const open = p(f, 52, 72, QUINT_INOUT);
  return (
    <AbsoluteFill style={{ background: "#000", overflow: "hidden" }}>
      <Clip {...clip} />
      <AbsoluteFill style={{ background: "#14301F", clipPath: `inset(0 0 ${open * 100}% 0)` }}>
        <div style={{ position: "absolute", left: 0, right: 0, top: 760, textAlign: "center", fontFamily: MONO, fontSize: 30, color: "#E9C46A", letterSpacing: 4, opacity: t }}>00:00:{String(14 + Math.floor(f / 30)).padStart(2, "0")}:{String(f % 30).padStart(2, "0")}</div>
        <div style={{ position: "absolute", left: 0, right: 0, top: 830, textAlign: "center", fontFamily: "AG, serif", fontWeight: 500, fontSize: 170, letterSpacing: 6, color: "#F3EEE2", opacity: t, transform: `scale(${1.08 - 0.08 * t})` }}>{title}</div>
        <div style={{ position: "absolute", left: 340, right: 340, top: 1060, height: 2, background: "#E9C46A", transform: `scaleX(${p(f, 14, 34, EXPO_OUT)})` }} />
      </AbsoluteFill>
      <FilmGrain />
    </AbsoluteFill>
  );
};

/* ---------------------------------------------------------- /playing-grid */
// you shrink into one tile of a grid of playing videos with big labels
export const PlayingGrid: React.FC<{ clip: ClipProps; reels: string[] }> = ({ clip, reels }) => {
  const f = useCurrentFrame();
  const g = p(f, 6, 30, QUINT_INOUT);
  const COLS = 3;
  const TW = 330;
  const TH = 586;
  const GX = (1080 - COLS * TW - 2 * 15) / 2;
  const GY = (1920 - 3 * TH - 2 * 15) / 2;
  const tiles = Array.from({ length: 9 }).map((_, i) => {
    const c = i % COLS;
    const r = Math.floor(i / COLS);
    const x = GX + c * (TW + 15);
    const y = GY + r * (TH + 15);
    const me = i === 4;
    const label = ["A SINGLE", "", "BIGGER", "", "", "OF THIS", "", "SECOND", ""][i];
    if (me) {
      const X = interpolate(g, [0, 1], [0, x]);
      const Yp = interpolate(g, [0, 1], [0, y]);
      const W = interpolate(g, [0, 1], [1080, TW]);
      return (
        <div key={i} style={{ position: "absolute", left: X, top: Yp, width: W, height: W * (1920 / 1080), borderRadius: 18 * g, overflow: "hidden", zIndex: 2 }}>
          <div style={{ width: 1080, height: 1920, transform: `scale(${W / 1080})`, transformOrigin: "0 0" }}><Clip {...clip} /></div>
        </div>
      );
    }
    const k = p(f, 18 + i * 2, 32 + i * 2, EXPO_OUT);
    return (
      <div key={i} style={{ position: "absolute", left: x, top: y, width: TW, height: TH, borderRadius: 18, overflow: "hidden", opacity: k, transform: `scale(${0.9 + 0.1 * k})`, background: "#111" }}>
        <Loop durationInFrames={70}><OffthreadVideo src={staticFile(reels[i % reels.length])} muted startFrom={20} style={{ width: TW, height: TH, objectFit: "cover" }} /></Loop>
        {label && <div style={{ position: "absolute", left: 16, top: 16, fontFamily: TIGHT, fontWeight: 900, fontSize: 52, lineHeight: 0.95, color: "#fff", letterSpacing: -2, textShadow: "0 4px 14px rgba(0,0,0,0.6)" }}>{label}</div>}
      </div>
    );
  });
  return (
    <AbsoluteFill style={{ background: "#0E0E0F", overflow: "hidden" }}>
      {tiles}
      <FilmGrain />
    </AbsoluteFill>
  );
};

/* ---------------------------------------------------------- /video-card */
// the shot shrinks into a widescreen video card with a title and a scrubber
export const VideoCard: React.FC<{ clip: ClipProps }> = ({ clip }) => {
  const f = useCurrentFrame();
  const g = p(f, 8, 32, QUINT_INOUT);
  const CW = 960;
  const CH = 540;
  const cx = 60;
  const cy = 520;
  const x = interpolate(g, [0, 1], [0, cx]);
  const y = interpolate(g, [0, 1], [0, cy]);
  const w = interpolate(g, [0, 1], [1080, CW]);
  const h = interpolate(g, [0, 1], [1920, CH]);
  const meta = p(f, 30, 44, EXPO_OUT);
  return (
    <AbsoluteFill style={{ background: "#14301F", overflow: "hidden" }}>
      <AbsoluteFill style={{ background: "radial-gradient(ellipse at 50% 30%, #1F4A30, #0D2015 70%)", opacity: g }} />
      <div style={{ position: "absolute", left: x, top: y, width: w, height: h, borderRadius: 30 * g, overflow: "hidden", boxShadow: g > 0.1 ? "0 30px 70px rgba(0,0,0,0.5)" : undefined }}>
        <div style={{ position: "absolute", left: (w - 1080 * Math.max(w / 1080, h / 1920)) / 2, top: interpolate(g, [0, 1], [(h - 1920 * Math.max(w / 1080, h / 1920)) / 2, h * 0.46 - 860 * Math.max(w / 1080, h / 1920)]), width: 1080, height: 1920, transform: `scale(${Math.max(w / 1080, h / 1920)})`, transformOrigin: "0 0" }}><Clip {...clip} /></div>
        <div style={{ position: "absolute", left: 24, right: 24, bottom: 20, height: 6, borderRadius: 3, background: "rgba(255,255,255,0.35)", opacity: meta }}><div style={{ width: `${30 + f * 0.5}%`, height: "100%", borderRadius: 3, background: "#fff" }} /></div>
      </div>
      <div style={{ position: "absolute", left: cx + 6, top: cy + CH + 40, opacity: meta, transform: `translateY(${(1 - meta) * 30}px)` }}>
        <div style={{ fontFamily: "AG, serif", fontWeight: 500, fontSize: 70, color: "#F3EEE2" }}>Video card</div>
        <div style={{ fontFamily: MONO, fontSize: 26, color: "#E9C46A", marginTop: 8, letterSpacing: 2 }}>02 · The raw take · 0:28</div>
      </div>
      <FilmGrain />
    </AbsoluteFill>
  );
};

/* ---------------------------------------------------------- /comment-cta */
// your comment pops in, then the auto reply lands under it
export const CommentCta: React.FC<{ clip: ClipProps; keyword?: string }> = ({ clip, keyword = "COMMANDS" }) => {
  const f = useCurrentFrame();
  const a = p(f, 8, 20, BACK_OUT);
  const b = p(f, 40, 52, BACK_OUT);
  const heart = p(f, 26, 34, BACK_OUT);
  const ui = (
    <>
      <Pill style={{ position: "absolute", left: 100, top: 230, width: 880, padding: "24px 28px", display: "flex", alignItems: "center", gap: 20, transform: `scale(${a})`, transformOrigin: "0 50%", opacity: a }}>
        <div style={{ width: 64, height: 64, borderRadius: 32, background: "#C9C9D1" }} />
        <div style={{ flex: 1 }}>
          <div style={{ fontFamily: SANS, fontWeight: 600, fontSize: 24, color: "#6E6E78" }}>you · now</div>
          <div style={{ fontFamily: SANS, fontWeight: 800, fontSize: 46, color: "#141418" }}>{keyword}</div>
        </div>
        <svg width={44} height={44} viewBox="0 0 24 24" style={{ transform: `scale(${1 + heart * 0.3})` }} fill={heart > 0.5 ? "#FF3B30" : "none"} stroke={heart > 0.5 ? "#FF3B30" : "#6E6E78"} strokeWidth={2}><path d="M12 21s-7.5-4.6-9.3-9.2C1.4 8.4 3.6 5 7 5c2 0 3.4 1.1 5 3 1.6-1.9 3-3 5-3 3.4 0 5.6 3.4 4.3 6.8C19.5 16.4 12 21 12 21z" /></svg>
      </Pill>
      <Pill style={{ position: "absolute", left: 180, top: 400, width: 800, padding: "20px 26px", display: "flex", alignItems: "center", gap: 18, transform: `scale(${b})`, transformOrigin: "0 0", opacity: b }}>
        <div style={{ width: 56, height: 56, borderRadius: 28, background: Y, display: "grid", placeItems: "center", fontFamily: TIGHT, fontWeight: 800, fontSize: 22 }}>MG</div>
        <div>
          <div style={{ fontFamily: SANS, fontWeight: 600, fontSize: 22, color: "#6E6E78" }}>marcelgrauu · now</div>
          <div style={{ fontFamily: SANS, fontWeight: 600, fontSize: 36, color: "#141418" }}>Sent. Check your DMs 📩</div>
        </div>
      </Pill>
    </>
  );
  return <Scene clip={clip} dur={G6_DUR} push={[1, 1.05]} origin={[540, 500]} kicks={[10, 42]} front={ui} />;
};

/* ---------------------------------------------------------- /comment-drop */
// a comment box, the keyword letters drop in giant from above into it, Post lights up
export const CommentDrop: React.FC<{ clip: ClipProps; keyword?: string }> = ({ clip, keyword = "EDIT" }) => {
  const f = useCurrentFrame();
  const box = p(f, 2, 14, EXPO_OUT);
  const chars = keyword.split("");
  const typed = chars.filter((_, i) => f >= 14 + i * 9 + 9).length;
  const ui = (
    <>
      {chars.map((ch, i) => {
        const st = 14 + i * 9;
        const t = p(f, st, st + 9, EXPO_IN);
        if (f < st || f >= st + 9) return null;
        return <div key={i} style={{ position: "absolute", left: 300 + i * 120, top: -200 + t * 560, fontFamily: TIGHT, fontWeight: 900, fontSize: 220 - t * 160, color: "#fff", textShadow: "0 10px 30px rgba(0,0,0,0.5)" }}>{ch}</div>;
      })}
      <Pill style={{ position: "absolute", left: 90, top: 330, width: 900, padding: "22px 22px 22px 30px", display: "flex", alignItems: "center", gap: 20, transform: `scale(${0.92 + 0.08 * box})`, opacity: box }}>
        <div style={{ width: 60, height: 60, borderRadius: 30, background: "#C9C9D1" }} />
        <div style={{ flex: 1, fontFamily: SANS, fontWeight: typed ? 800 : 400, fontSize: 44, color: typed ? "#141418" : "#9A9AA2" }}>{typed ? keyword.slice(0, typed) : "Add a comment…"}</div>
        <div style={{ padding: "14px 28px", borderRadius: 30, background: typed === chars.length ? "#141418" : "#E5E4EA", color: typed === chars.length ? "#fff" : "#9A9AA2", fontFamily: SANS, fontWeight: 700, fontSize: 30 }}>Post</div>
      </Pill>
    </>
  );
  return <Scene clip={clip} dur={G6_DUR} push={[1, 1.05]} origin={[540, 500]} kicks={chars.map((_, i) => 14 + i * 9 + 9)} front={ui} />;
};

void Cutout;
void hash;
void Pointer;
