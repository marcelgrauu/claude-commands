/**
 * Grid effects, part 7: Marcel's set.
 * /hero-number, /notif-stack, /comment-rain, /price-strike, /progress-track, /callout,
 * /search-bar, /prompt-card, /stamp, /brand-lockup, /orbit-posters
 */
import React from "react";
import { interpolate, useCurrentFrame } from "remotion";
import { EXPO_OUT, BACK_OUT, QUINT_INOUT, SOFT, p, hash } from "../kit";
import { ClipProps, Scene, MONO, SANS, TIGHT, Y } from "./common";
import { Asterisk } from "../ui/ClaudePhone";

export const G7_DUR = 100;

const Pill: React.FC<{ children: React.ReactNode; style?: React.CSSProperties }> = ({ children, style }) => (
  <div style={{ borderRadius: 34, background: "rgba(248,247,251,0.96)", boxShadow: "0 20px 50px rgba(0,0,0,0.38)", ...style }}>{children}</div>
);

/* ---------------------------------------------------------- /hero-number */
export const HeroNumber: React.FC<{ clip: ClipProps; cut: ClipProps }> = ({ clip, cut }) => {
  const f = useCurrentFrame();
  const v = Math.round(interpolate(p(f, 6, 66, QUINT_INOUT), [0, 1], [0, 950]));
  const big = (
    <div style={{ position: "absolute", left: 0, right: 0, top: 200, textAlign: "center", opacity: p(f, 2, 10) }}>
      <div style={{ fontFamily: SANS, fontWeight: 600, fontSize: 34, color: "rgba(255,255,255,0.8)", letterSpacing: 2 }}>new followers in 30 days</div>
      <div style={{ fontFamily: TIGHT, fontWeight: 900, fontSize: 250, letterSpacing: -12, lineHeight: 0.9, color: "#fff", fontVariantNumeric: "tabular-nums", textShadow: "0 10px 40px rgba(0,0,0,0.35)" }}><span style={{ color: Y }}>+</span>{v}K</div>
    </div>
  );
  return <Scene clip={clip} cut={cut} dur={G7_DUR} push={[1, 1.05]} origin={[540, 700]} kicks={[66]} back={big} />;
};

/* ---------------------------------------------------------- /notif-stack */
const NOTIFS = [
  { app: "Claude", t: "Your reel is ready", c: "#D97757", ic: <Asterisk size={34} color="#fff" /> },
  { app: "Instagram", t: "1,204 people liked your reel", c: "linear-gradient(45deg,#F9A825,#E91E63,#7B1FA2)", ic: <div style={{ width: 26, height: 26, borderRadius: 8, border: "4px solid #fff" }} /> },
  { app: "Messages", t: "Can you send me the command?", c: "#34C759", ic: <div style={{ width: 28, height: 22, borderRadius: 11, background: "#fff" }} /> },
  { app: "Stripe", t: "Payment received · $700", c: "#635BFF", ic: <div style={{ fontFamily: TIGHT, fontWeight: 800, fontSize: 30, color: "#fff" }}>S</div> },
];
export const NotifStack: React.FC<{ clip: ClipProps }> = ({ clip }) => {
  const f = useCurrentFrame();
  const items = NOTIFS.map((n, i) => {
    const at = 6 + i * 14;
    const k = p(f, at, at + 12, BACK_OUT);
    const pushDown = NOTIFS.slice(i + 1).reduce((a, _, j) => a + p(f, 6 + (i + 1 + j) * 14, 6 + (i + 1 + j) * 14 + 10, EXPO_OUT), 0);
    const y = 110 + pushDown * 158;
    const depth = pushDown;
    return (
      <Pill key={i} style={{ position: "absolute", left: 60 + depth * 14, right: 60 + depth * 14, top: y, padding: "22px 26px", display: "flex", gap: 20, alignItems: "center", transform: `translateY(${(1 - k) * -220}px) scale(${1 - depth * 0.03})`, opacity: Math.min(1, k * 2) * (1 - depth * 0.12), zIndex: 10 - i }}>
        <div style={{ width: 74, height: 74, borderRadius: 18, background: n.c, display: "grid", placeItems: "center", flex: "none" }}>{n.ic}</div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: "flex", justifyContent: "space-between", fontFamily: SANS, fontSize: 26, color: "rgba(0,0,0,0.5)" }}><b style={{ color: "#141418" }}>{n.app}</b><span>now</span></div>
          <div style={{ fontFamily: SANS, fontSize: 32, color: "#141418", marginTop: 4, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{n.t}</div>
        </div>
      </Pill>
    );
  });
  return <Scene clip={clip} dur={G7_DUR} push={[1, 1.04]} origin={[540, 500]} kicks={[8, 22, 36, 50]} front={<>{items.reverse()}</>} />;
};

/* ---------------------------------------------------------- /comment-rain */
const USERS = ["laura.ai", "pau_edits", "nora.mp4", "jordi.reels", "ana.creates", "marc_ai", "lia.video", "tom.cuts"];
export const CommentRain: React.FC<{ clip: ClipProps; keyword?: string }> = ({ clip, keyword = "COMMANDS" }) => {
  const f = useCurrentFrame();
  const items = USERS.map((u, i) => {
    const at = 4 + i * 6;
    const k = p(f, at, at + 12, BACK_OUT);
    const x = [60, 520, 90, 560, 40, 500, 120, 540][i];
    const y = [150, 230, 380, 470, 620, 1240, 1380, 1520][i] - (f - at) * 0.6;
    return (
      <div key={u} style={{ position: "absolute", left: x, top: y, transform: `scale(${k}) rotate(${(hash(i, 2) - 0.5) * 6}deg)`, opacity: Math.min(1, k * 2), display: "flex", alignItems: "center", gap: 14, padding: "14px 22px 14px 14px", borderRadius: 40, background: "rgba(20,20,22,0.88)", border: "1px solid rgba(255,255,255,0.12)", boxShadow: "0 14px 30px rgba(0,0,0,0.4)" }}>
        <div style={{ width: 52, height: 52, borderRadius: 26, background: `hsl(${hash(i, 5) * 360},55%,60%)` }} />
        <div>
          <div style={{ fontFamily: SANS, fontSize: 20, color: "rgba(255,255,255,0.6)" }}>{u}</div>
          <div style={{ fontFamily: SANS, fontWeight: 800, fontSize: 32, color: "#fff" }}>{keyword}</div>
        </div>
      </div>
    );
  });
  return <Scene clip={clip} dur={G7_DUR} push={[1, 1.04]} origin={[540, 800]} front={<>{items}</>} />;
};

/* ---------------------------------------------------------- /price-strike */
export const PriceStrike: React.FC<{ clip: ClipProps; cut: ClipProps }> = ({ clip, cut }) => {
  const f = useCurrentFrame();
  const strike = p(f, 22, 34, QUINT_INOUT);
  const free = p(f, 40, 50, BACK_OUT);
  const back = (
    <div style={{ position: "absolute", left: 0, right: 0, top: 220, textAlign: "center", opacity: p(f, 2, 12) }}>
      <div style={{ fontFamily: SANS, fontWeight: 600, fontSize: 36, color: "rgba(255,255,255,0.8)" }}>The full command pack</div>
      <div style={{ position: "relative", display: "inline-block", fontFamily: TIGHT, fontWeight: 800, fontSize: 260, letterSpacing: -12, color: "#fff", lineHeight: 1, opacity: 1 - strike * 0.5 }}>
        $49
        <div style={{ position: "absolute", left: -20, right: -20, top: "48%", height: 22, borderRadius: 11, background: "#FF3B30", transform: `rotate(-9deg) scaleX(${strike})`, transformOrigin: "0 50%" }} />
      </div>
    </div>
  );
  const stamp = (
    <div style={{ position: "absolute", left: 540 - 230, top: 470, width: 460, textAlign: "center", padding: "18px 0", borderRadius: 20, background: Y, color: "#0A0A0A", fontFamily: TIGHT, fontWeight: 900, fontSize: 110, letterSpacing: -4, transform: `rotate(8deg) scale(${2.4 - 1.4 * free})`, opacity: Math.min(1, free * 3), boxShadow: "0 20px 50px rgba(0,0,0,0.45)" }}>FREE</div>
  );
  return <Scene clip={clip} cut={cut} dur={G7_DUR} push={[1, 1.05]} origin={[540, 600]} kicks={[46]} back={back} front={stamp} />;
};

/* ---------------------------------------------------------- /progress-track */
const STEPS3 = ["Clip", "Command", "Reel"];
export const ProgressTrack: React.FC<{ clip: ClipProps }> = ({ clip }) => {
  const f = useCurrentFrame();
  const enter = p(f, 2, 18, EXPO_OUT);
  const fill = p(f, 14, 80, QUINT_INOUT);
  const card = (
    <Pill style={{ position: "absolute", left: 70, right: 70, top: 220, padding: "34px 44px 30px", transform: `translateY(${(1 - enter) * -60}px)`, opacity: enter }}>
      <div style={{ display: "flex", justifyContent: "space-between", fontFamily: SANS, fontWeight: 700, fontSize: 38, color: "#141418" }}><span>Building your reel</span><span style={{ color: "#D97757", fontVariantNumeric: "tabular-nums" }}>{Math.round(fill * 100)}%</span></div>
      <div style={{ position: "relative", height: 16, borderRadius: 8, background: "#E5E4EA", margin: "34px 18px 0" }}>
        <div style={{ position: "absolute", left: 0, top: 0, bottom: 0, width: `${fill * 100}%`, borderRadius: 8, background: `linear-gradient(90deg,#D97757,${Y})` }} />
        {STEPS3.map((s, i) => {
          const at = i / 2;
          const lit = fill >= at - 0.001;
          return <div key={s} style={{ position: "absolute", left: `${at * 100}%`, top: 8, width: 44, height: 44, marginLeft: -22, marginTop: -22, borderRadius: 22, background: lit ? "#141418" : "#fff", border: `4px solid ${lit ? "#141418" : "#D0CFD6"}`, transform: `scale(${lit ? 1.1 : 1})` }} />;
        })}
      </div>
      <div style={{ display: "flex", justifyContent: "space-between", marginTop: 34, fontFamily: SANS, fontWeight: 600, fontSize: 28, color: "#6E6E78" }}>{STEPS3.map((s) => <span key={s}>{s}</span>)}</div>
    </Pill>
  );
  return <Scene clip={clip} dur={G7_DUR} push={[1, 1.04]} origin={[540, 500]} front={card} />;
};

/* ---------------------------------------------------------- /callout */
export const Callout: React.FC<{ clip: ClipProps }> = ({ clip }) => {
  const f = useCurrentFrame();
  const CO = [
    { at: 8, dot: [615, 700], label: "talking head", lx: 760, ly: 520 },
    { at: 22, dot: [400, 1130], label: "locked-off camera", lx: 90, ly: 1300 },
    { at: 36, dot: [560, 1260], label: "zero manual edits", lx: 640, ly: 1420 },
  ];
  const items = CO.map((c, i) => {
    const k = p(f, c.at, c.at + 12, QUINT_INOUT);
    const lab = p(f, c.at + 8, c.at + 18, BACK_OUT);
    return (
      <React.Fragment key={i}>
        <svg width={1080} height={1920} style={{ position: "absolute", left: 0, top: 0, overflow: "visible" }}>
          <circle cx={c.dot[0]} cy={c.dot[1]} r={10} fill={Y} opacity={p(f, c.at, c.at + 4)} />
          <circle cx={c.dot[0]} cy={c.dot[1]} r={10 + ((f - c.at) % 24) * 1.4} fill="none" stroke={Y} strokeWidth={2} opacity={f > c.at ? 1 - ((f - c.at) % 24) / 24 : 0} />
          <path d={`M ${c.dot[0]} ${c.dot[1]} L ${c.lx + 20} ${c.ly + 40}`} stroke="#fff" strokeWidth={3} pathLength={1} strokeDasharray={`${k} 1`} />
        </svg>
        <Pill style={{ position: "absolute", left: c.lx, top: c.ly, padding: "14px 24px", borderRadius: 30, transform: `scale(${lab})`, transformOrigin: "0 50%", opacity: lab, fontFamily: SANS, fontWeight: 700, fontSize: 32, color: "#141418", whiteSpace: "nowrap" }}>{c.label}</Pill>
      </React.Fragment>
    );
  });
  return <Scene clip={clip} dur={G7_DUR} push={[1, 1.04]} origin={[540, 900]} front={<>{items}</>} />;
};

/* ---------------------------------------------------------- /search-bar */
const RESULTS = [{ t: "20 video effects made in Claude", m: "reel · 0:28" }, { t: "Claude video commands pack", m: "guide · free" }, { t: "How to use /orbit", m: "tutorial · 1 min" }];
export const SearchBar: React.FC<{ clip: ClipProps }> = ({ clip }) => {
  const f = useCurrentFrame();
  const q = "claude video effects";
  const n = Math.max(0, Math.min(q.length, Math.floor((f - 10) / 1.1)));
  const ui = (
    <>
      <Pill style={{ position: "absolute", left: 70, right: 70, top: 200, height: 110, borderRadius: 55, display: "flex", alignItems: "center", gap: 20, padding: "0 36px", opacity: p(f, 2, 12) }}>
        <svg width={44} height={44} viewBox="0 0 24 24" fill="none" stroke="#6E6E78" strokeWidth={2.4}><circle cx="11" cy="11" r="7" /><path d="M20 20l-4-4" strokeLinecap="round" /></svg>
        <div style={{ fontFamily: SANS, fontSize: 40, color: n ? "#141418" : "#9A9AA2" }}>{n ? q.slice(0, n) : "Search"}{f > 8 && f < 40 && Math.floor(f / 6) % 2 === 0 && <span style={{ color: "#007AFF" }}>|</span>}</div>
      </Pill>
      {RESULTS.map((r, i) => {
        const k = p(f, 40 + i * 7, 52 + i * 7, EXPO_OUT);
        return (
          <Pill key={i} style={{ position: "absolute", left: 70, right: 70, top: 340 + i * 150, padding: "24px 32px", borderRadius: 28, transform: `translateY(${(1 - k) * -30}px)`, opacity: k }}>
            <div style={{ fontFamily: SANS, fontWeight: 700, fontSize: 34, color: "#141418" }}>{r.t}</div>
            <div style={{ fontFamily: SANS, fontSize: 24, color: "#6E6E78", marginTop: 6 }}>{r.m}</div>
          </Pill>
        );
      })}
    </>
  );
  return <Scene clip={clip} dur={G7_DUR} push={[1, 1.04]} origin={[540, 500]} front={ui} />;
};

/* ---------------------------------------------------------- /prompt-card */
const PLINES = ["Cut me out of my clip and", "orbit my reels around my head,", "in front of me and behind me."];
export const PromptCard: React.FC<{ clip: ClipProps }> = ({ clip }) => {
  const f = useCurrentFrame();
  const enter = p(f, 2, 16, EXPO_OUT);
  const copied = f >= 78;
  const card = (
    <div style={{ position: "absolute", left: 70, right: 70, top: 200, borderRadius: 34, background: "rgba(18,18,20,0.92)", border: "1px solid rgba(255,255,255,0.14)", padding: "30px 36px", boxShadow: "0 24px 60px rgba(0,0,0,0.5)", transform: `translateY(${(1 - enter) * -60}px)`, opacity: enter }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 18 }}>
        <span style={{ fontFamily: MONO, fontSize: 22, letterSpacing: 6, color: Y }}>PROMPT</span>
        <span style={{ padding: "10px 22px", borderRadius: 20, background: copied ? Y : "rgba(255,255,255,0.08)", color: copied ? "#111" : "#fff", fontFamily: SANS, fontWeight: 700, fontSize: 24, border: "1px solid rgba(255,255,255,0.2)", transform: `scale(${copied ? 1 + 0.12 * Math.max(0, 1 - (f - 78) / 6) : 1})` }}>{copied ? "Copied ✓" : "Copy"}</span>
      </div>
      {PLINES.map((l, i) => {
        const st = 12 + i * 20;
        const n = Math.max(0, Math.min(l.length, Math.floor((f - st) / 0.7)));
        return <div key={i} style={{ fontFamily: MONO, fontSize: 34, lineHeight: 1.5, color: "#F1EFE8", whiteSpace: "nowrap" }}>{l.slice(0, n)}{n > 0 && n < l.length && <span style={{ color: Y }}>▍</span>}</div>;
      })}
    </div>
  );
  return <Scene clip={clip} dur={G7_DUR} push={[1, 1.04]} origin={[540, 500]} kicks={[78]} front={card} />;
};

/* ---------------------------------------------------------- /stamp */
export const Stamp: React.FC<{ clip: ClipProps }> = ({ clip }) => {
  const f = useCurrentFrame();
  const HIT = 26;
  const k = p(f, HIT - 6, HIT, (x) => x * x);
  const shake = f >= HIT && f < HIT + 6 ? (hash(f, 3) - 0.5) * 18 : 0;
  const stamp = (
    <div style={{ position: "absolute", left: 540 - 300, top: 150, width: 600, textAlign: "center", transform: `translate(${shake}px, ${shake * 0.6}px) rotate(-12deg) scale(${(3 - 2 * k) * 0.8})`, opacity: Math.min(1, k * 2) }}>
      <div style={{ display: "inline-block", padding: "16px 40px", border: `12px solid ${Y}`, borderRadius: 24, fontFamily: TIGHT, fontWeight: 900, fontSize: 150, letterSpacing: -5, color: Y, textShadow: "0 0 30px rgba(255,229,0,0.5)", boxShadow: "0 0 50px rgba(255,229,0,0.3), inset 0 0 40px rgba(255,229,0,0.2)" }}>100% AI</div>
    </div>
  );
  return <Scene clip={clip} dur={G7_DUR} push={[1, 1.04]} origin={[540, 600]} kicks={[HIT, HIT + 2]} front={stamp} />;
};

/* ---------------------------------------------------------- /brand-lockup */
export const BrandLockup: React.FC<{ clip: ClipProps; brand?: string }> = ({ clip, brand = "Claude" }) => {
  const f = useCurrentFrame();
  const dim = p(f, 30, 48, SOFT);
  const a = p(f, 36, 50, EXPO_OUT);
  const x = p(f, 42, 54, BACK_OUT);
  const b = p(f, 48, 62, EXPO_OUT);
  const u = p(f, 58, 74, EXPO_OUT);
  const lock = (
    <div style={{ position: "absolute", left: 0, right: 0, top: 760, display: "flex", flexDirection: "column", alignItems: "center", gap: 26 }}>
      <div style={{ fontFamily: TIGHT, fontWeight: 900, fontSize: 150, letterSpacing: -7, color: "#fff", opacity: a, transform: `translateY(${(1 - a) * 40}px)` }}>marcelgrau.</div>
      <div style={{ fontFamily: TIGHT, fontWeight: 300, fontSize: 80, color: Y, transform: `scale(${x}) rotate(${(1 - x) * 90}deg)`, opacity: x }}>×</div>
      <div style={{ display: "flex", alignItems: "center", gap: 18, padding: "18px 44px", borderRadius: 60, background: "rgba(255,255,255,0.12)", border: "1.5px solid rgba(255,255,255,0.35)", opacity: b, transform: `translateY(${(1 - b) * 40}px)` }}>
        <Asterisk size={74} /><div style={{ fontFamily: SANS, fontWeight: 700, fontSize: 80, color: "#fff" }}>{brand}</div>
      </div>
      <div style={{ width: 420, height: 8, borderRadius: 4, background: Y, transform: `scaleX(${u})`, boxShadow: "0 0 20px rgba(255,229,0,0.6)" }} />
    </div>
  );
  return <Scene clip={clip} dur={G7_DUR} push={[1, 1.05]} origin={[540, 900]} focus={dim} hud={<><div style={{ position: "absolute", inset: 0, background: `rgba(6,6,8,${0.6 * dim})` }} />{lock}</>} />;
};

/* ---------------------------------------------------------- /orbit-posters */
const POSTERS = [
  { bg: Y, c: "#0A0A0A", t: "RAW" }, { bg: "#0A0A0A", c: Y, t: "AI" }, { bg: "#E5322D", c: "#fff", t: "2026" },
  { bg: "#F3EEE2", c: "#0A0A0A", t: "BOLD" }, { bg: "#1E3A8A", c: "#fff", t: "MG." }, { bg: "#0A0A0A", c: "#fff", t: "NEW" },
];
export const OrbitPosters: React.FC<{ clip: ClipProps; cut: ClipProps }> = ({ clip, cut }) => {
  const f = useCurrentFrame();
  const n = POSTERS.length;
  const poses = POSTERS.map((_, i) => {
    const k = p(f, 2 + i * 3, 24 + i * 3, EXPO_OUT);
    const a = (i / n) * Math.PI * 2 + f * 0.03 + k * 2;
    const s = Math.sin(a);
    return { i, k, a, s, x: 545 + 440 * Math.cos(a) * k, y: 620 + 80 * s * k + (1 - k) * 100 };
  });
  const poster = (q: (typeof poses)[0]) => {
    const P = POSTERS[q.i];
    const depth = (q.s + 1) / 2;
    return (
      <div key={q.i} style={{ position: "absolute", left: q.x - 80, top: q.y - 110, width: 160, height: 220, transform: `perspective(800px) rotateY(${-Math.cos(q.a) * 45}deg) scale(${(0.7 + 0.45 * depth) * q.k})`, opacity: q.k }}>
        <div style={{ position: "absolute", inset: 0, filter: depth < 0.5 ? `blur(${(0.5 - depth) * 4}px) brightness(${0.7 + 0.6 * depth})` : undefined }}>
          <div style={{ position: "absolute", inset: 0, background: P.bg, borderRadius: 6, boxShadow: "0 18px 36px rgba(0,0,0,0.45)", padding: 14, display: "flex", flexDirection: "column", justifyContent: "space-between" }}>
            <div style={{ fontFamily: SANS, fontSize: 13, fontWeight: 600, color: P.c, opacity: 0.7 }}>marcelgrau.</div>
            <div style={{ fontFamily: TIGHT, fontWeight: 900, fontSize: 56, lineHeight: 0.88, letterSpacing: -3, color: P.c }}>{P.t}</div>
          </div>
        </div>
      </div>
    );
  };
  const far = poses.filter((q) => q.s <= 0).sort((a, b) => a.s - b.s);
  const near = poses.filter((q) => q.s > 0).sort((a, b) => a.s - b.s);
  return <Scene clip={clip} cut={cut} dur={G7_DUR} push={[1, 1.06]} origin={[545, 760]} back={<>{far.map(poster)}</>} front={<>{near.map(poster)}</>} />;
};
