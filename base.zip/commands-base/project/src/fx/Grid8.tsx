/**
 * Grid effects, part 8: the ones still missing.
 * /logo-orbit (Charlie Hills) and the effects seen in @corbinsylk's "20 effects" grid:
 * /effect-list, /name-tag, /creator-list, /code-reveal, /hand-cards, /split-notes,
 * /app-tutorial, /caption-pill
 */
import React from "react";
import { AbsoluteFill, OffthreadVideo, staticFile, useCurrentFrame } from "remotion";
import { EASE, prog, track, lerp, velocityOf, hash } from "../kit/motion";
import { MotionBlur } from "../kit/fx";
import { Cursor } from "../kit/ui";
import { ClipProps, Scene, Tile, SANS, SERIF, MONO, Y } from "./common";
import { Asterisk } from "../ui/ClaudePhone";

export const G8_DUR = 100;

const ink = "#0E0E10";
const paper = "#F7F6F2";

/* ---------------------------------------------------------- /logo-orbit */
// Charlie Hills' spec: tool tiles on a tilted ellipse around the head, -6 degrees,
// thin line, near half sharp and in front, far half behind and softer; they spin in.
const LOGOS: { bg: string; node: React.ReactNode }[] = [
  { bg: "linear-gradient(160deg,#E58A69,#C9603F)", node: <Asterisk size={62} color="#FFF5EE" /> },
  { bg: "#0B0B0B", node: <div style={{ fontFamily: SANS, fontWeight: 900, fontSize: 42, color: "#fff", letterSpacing: -2 }}>CC</div> },
  { bg: "#1E0A3C", node: <div style={{ fontFamily: SANS, fontWeight: 900, fontSize: 42, color: "#C9A7FF", letterSpacing: -1 }}>Pr</div> },
  { bg: "#FFFFFF", node: <div style={{ fontFamily: SERIF, fontWeight: 700, fontSize: 52, color: "#111" }}>N</div> },
  { bg: "linear-gradient(135deg,#FF2D87,#7B2CFF 55%,#1E90FF)", node: <div style={{ width: 44, height: 44, borderRadius: 12, border: "6px solid #fff" }} /> },
  { bg: "#D8FF5E", node: <div style={{ fontFamily: SANS, fontWeight: 900, fontSize: 48, color: "#0B0B0B" }}>H</div> },
  { bg: "#10A37F", node: <svg width={50} height={50} viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth={1.8}>{[0, 60, 120].map((r) => <ellipse key={r} cx="12" cy="12" rx="9" ry="4.2" transform={`rotate(${r} 12 12)`} />)}</svg> },
  { bg: Y, node: <div style={{ fontFamily: SANS, fontWeight: 900, fontSize: 38, color: "#0A0A0A", letterSpacing: -1.5 }}>MG</div> },
];
const LCX = 540, LCY = 610, LRX = 360, LRY = 110, LTILT = (-6 * Math.PI) / 180, LS = 112;
const lPose = (i: number, f: number) => {
  const k = prog(f, 2 + i * 2, 24 + i * 2, EASE.out);
  const a = (i / LOGOS.length) * Math.PI * 2 + prog(f, 0, 36, EASE.out) * 2.8 + f * 0.028;
  const x0 = LRX * Math.cos(a) * k;
  const y0 = LRY * Math.sin(a) * k;
  return { x: LCX + x0 * Math.cos(LTILT) - y0 * Math.sin(LTILT), y: LCY + x0 * Math.sin(LTILT) + y0 * Math.cos(LTILT), s: Math.sin(a), k };
};
const LogoTile: React.FC<{ i: number }> = ({ i }) => {
  const f = useCurrentFrame();
  const { x, y, s, k } = lPose(i, f);
  const d = (s + 1) / 2;
  const vx = velocityOf((t) => lPose(i, t).x, f);
  return (
    <div style={{ position: "absolute", left: x - LS / 2, top: y - LS / 2, width: LS, height: LS, transform: `scale(${(0.66 + 0.42 * d) * lerp(0.9, 1, k)})`, opacity: Math.min(1, k * 2) }}>
      <MotionBlur id={`lo${i}`} vx={vx}>
        <div style={{ filter: d < 0.45 ? `blur(${((0.45 - d) * 6).toFixed(2)}px) brightness(${0.75 + 0.5 * d})` : undefined }}>
          <div style={{ width: LS, height: LS, borderRadius: 28, background: LOGOS[i].bg, display: "grid", placeItems: "center", boxShadow: "0 14px 30px rgba(0,0,0,0.4), inset 0 1.5px 0 rgba(255,255,255,0.4)" }}>{LOGOS[i].node}</div>
        </div>
      </MotionBlur>
    </div>
  );
};
const LogoRing: React.FC<{ near: boolean }> = ({ near }) => {
  const f = useCurrentFrame();
  const t = prog(f, 4, 34, EASE.out);
  const deg = (LTILT * 180) / Math.PI;
  return (
    <svg width={1080} height={1920} style={{ position: "absolute", left: 0, top: 0, overflow: "visible" }}>
      <defs><clipPath id={near ? "lrN" : "lrF"}><rect x={-200} y={near ? LCY : LCY - 400} width={1480} height={400} transform={`rotate(${deg} ${LCX} ${LCY})`} /></clipPath></defs>
      <g clipPath={`url(#${near ? "lrN" : "lrF"})`}>
        <ellipse cx={LCX} cy={LCY} rx={LRX} ry={LRY} transform={`rotate(${deg} ${LCX} ${LCY})`} fill="none" stroke="#5B8CFF" strokeWidth={near ? 2.4 : 1.4} pathLength={1} strokeDasharray={`${t} 1`} opacity={near ? 0.85 : 0.4} />
      </g>
    </svg>
  );
};
export const LogoOrbit: React.FC<{ clip: ClipProps; cut: ClipProps }> = ({ clip, cut }) => {
  const f = useCurrentFrame();
  const ids = LOGOS.map((_, i) => i);
  const far = ids.filter((i) => lPose(i, f).s <= 0);
  const near = ids.filter((i) => lPose(i, f).s > 0).sort((a, b) => lPose(a, f).s - lPose(b, f).s);
  return <Scene clip={clip} cut={cut} dur={G8_DUR} push={[1, 1.06]} origin={[540, 760]} back={<><LogoRing near={false} />{far.map((i) => <LogoTile key={i} i={i} />)}</>} front={<><LogoRing near />{near.map((i) => <LogoTile key={i} i={i} />)}</>} />;
};

/* ---------------------------------------------------------- /effect-list */
// the running list of the video, pinned top left, the current item lights up and the counter rolls
const ITEMS = ["orbit", "liquid glass graph", "match cut", "glass type", "apple ui toggles", "ui world", "screen push", "over the shoulder"];
export const EffectList: React.FC<{ clip: ClipProps }> = ({ clip }) => {
  const f = useCurrentFrame();
  const enter = prog(f, 2, 20, EASE.out);
  const cur = Math.min(ITEMS.length - 1, Math.floor(Math.max(0, f - 18) / 10));
  const hl = track(f, ITEMS.map((_, i) => [18 + i * 10, i, EASE.inOutHard] as [number, number, (t: number) => number]));
  const RH = 46;
  const panel = (
    <div style={{ position: "absolute", left: 50, top: 150, width: 470, padding: "26px 26px 22px", borderRadius: 30, background: "rgba(14,14,16,0.78)", border: "1.5px solid rgba(255,255,255,0.14)", boxShadow: "0 20px 50px rgba(0,0,0,0.45)", transform: `translateX(${(1 - enter) * -80}px)`, opacity: enter }}>
      <div style={{ display: "flex", justifyContent: "space-between", fontFamily: MONO, fontSize: 20, letterSpacing: 4, color: Y, marginBottom: 14 }}>
        <span>IN THIS VIDEO</span><span style={{ color: "#fff" }}>{String(cur + 1).padStart(2, "0")} / 64</span>
      </div>
      <div style={{ position: "relative" }}>
        <div style={{ position: "absolute", left: -10, right: -10, top: hl * RH, height: RH, borderRadius: 12, background: "#fff" }} />
        {ITEMS.map((t, i) => {
          const k = prog(f, 6 + i * 2, 18 + i * 2, EASE.out);
          const on = Math.max(0, 1 - Math.abs(hl - i));
          return (
            <div key={t} style={{ position: "relative", height: RH, display: "flex", alignItems: "center", gap: 14, opacity: k, transform: `translateX(${(1 - k) * -20}px)` }}>
              <span style={{ fontFamily: MONO, fontSize: 18, color: on > 0.5 ? "#666" : "rgba(255,255,255,0.4)", width: 26 }}>{String(i + 1).padStart(2, "0")}</span>
              <span style={{ fontFamily: SANS, fontWeight: 500, fontSize: 30, letterSpacing: -0.5, color: on > 0.5 ? ink : i < cur ? "rgba(255,255,255,0.45)" : "rgba(255,255,255,0.88)" }}>{t}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
  return <Scene clip={clip} dur={G8_DUR} push={[1, 1.04]} origin={[700, 800]} front={panel} />;
};

/* ---------------------------------------------------------- /name-tag */
// lower third: avatar ring, handle types in, a red Follow tag snaps on, one line of role under it
export const NameTag: React.FC<{ clip: ClipProps; handle?: string }> = ({ clip, handle = "marcelgrauu" }) => {
  const f = useCurrentFrame();
  const bar = prog(f, 6, 22, EASE.out);
  const n = Math.max(0, Math.min(handle.length, Math.floor((f - 14) / 1.4)));
  const tag = prog(f, 34, 42, EASE.back);
  const sub = prog(f, 40, 54, EASE.out);
  const tag2 = (
    <div style={{ position: "absolute", left: 70, top: 1370 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 20, padding: "16px 18px 16px 16px", borderRadius: 60, background: "rgba(12,12,14,0.82)", border: "1.5px solid rgba(255,255,255,0.14)", transform: `translateX(${(1 - bar) * -120}px)`, opacity: bar, clipPath: `inset(0 ${(1 - bar) * 70}% 0 0 round 60px)` }}>
        <div style={{ width: 76, height: 76, borderRadius: 38, padding: 4, background: `conic-gradient(${Y}, #FF7A00, ${Y})` }}>
          <div style={{ width: 68, height: 68, borderRadius: 34, overflow: "hidden", border: "3px solid #111" }}><Tile src="talk1-thumb" w={62} h={62} /></div>
        </div>
        <div style={{ fontFamily: SANS, fontWeight: 700, fontSize: 40, color: "#fff", letterSpacing: -0.6, minWidth: 250 }}>{handle.slice(0, n)}</div>
        <div style={{ padding: "12px 22px", borderRadius: 30, background: "#FF3B30", fontFamily: SANS, fontWeight: 700, fontSize: 28, color: "#fff", transform: `scale(${tag})`, opacity: tag }}>Follow</div>
      </div>
      <div style={{ marginTop: 14, marginLeft: 26, fontFamily: SERIF, fontStyle: "italic", fontSize: 40, color: "rgba(255,255,255,0.9)", opacity: sub, transform: `translateY(${(1 - sub) * 12}px)`, textShadow: "0 2px 10px rgba(0,0,0,0.5)" }}>makes videos with one line</div>
    </div>
  );
  return <Scene clip={clip} dur={G8_DUR} push={[1, 1.04]} origin={[400, 1300]} kicks={[38]} front={tag2} />;
};

/* ---------------------------------------------------------- /creator-list */
// a dark sheet of creator profiles scrolls past, stats rolling; one row gets picked
const CREATORS = [
  ["edit.lab", "312", "84K", "201"], ["ai.creator", "1,204", "540K", "198"], ["motion.daily", "644", "128K", "331"],
  ["marcelgrauu", "980", "212K", "402"], ["reel.school", "2,031", "1.1M", "96"], ["cuts.by.ana", "411", "62K", "512"],
];
export const CreatorList: React.FC<{ clip: ClipProps }> = ({ clip }) => {
  const f = useCurrentFrame();
  const sheet = prog(f, 2, 20, EASE.out);
  const scroll = track(f, [[10, 0], [56, 3 * 150, EASE.inOut]]);
  const pick = prog(f, 58, 66, EASE.back);
  const rows = (
    <div style={{ position: "absolute", left: 70, right: 70, top: 300, height: 700, borderRadius: 40, background: "rgba(16,16,18,0.92)", border: "1.5px solid rgba(255,255,255,0.1)", overflow: "hidden", transform: `translateY(${(1 - sheet) * 200}px)`, opacity: sheet, boxShadow: "0 30px 70px rgba(0,0,0,0.5)" }}>
      <div style={{ position: "absolute", left: 0, right: 0, top: 30 - scroll, WebkitMaskImage: "none" }}>
        {CREATORS.concat(CREATORS).map((c, i) => {
          const me = c[0] === "marcelgrauu" && i === 3;
          return (
            <div key={i} style={{ height: 150, display: "flex", alignItems: "center", gap: 22, padding: "0 32px", borderBottom: "1px solid rgba(255,255,255,0.07)", background: me ? `rgba(255,229,0,${0.12 * pick})` : undefined }}>
              <div style={{ width: 84, height: 84, borderRadius: 42, background: `hsl(${hash(i, 3) * 360},28%,${me ? 70 : 45}%)`, boxShadow: me ? `0 0 0 ${4 * pick}px ${Y}` : undefined }} />
              <div style={{ flex: 1 }}>
                <div style={{ fontFamily: SANS, fontWeight: 700, fontSize: 32, color: "#fff" }}>{c[0]} <span style={{ color: "#4D9BFF" }}>✓</span></div>
                <div style={{ display: "flex", gap: 34, marginTop: 8, fontFamily: SANS, fontSize: 22, color: "rgba(255,255,255,0.55)" }}>
                  <span><b style={{ color: "#fff" }}>{c[1]}</b> posts</span><span><b style={{ color: "#fff" }}>{c[2]}</b> followers</span><span><b style={{ color: "#fff" }}>{c[3]}</b> following</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
      <div style={{ position: "absolute", left: 0, right: 0, top: 0, height: 80, background: "linear-gradient(rgba(16,16,18,1), transparent)" }} />
      <div style={{ position: "absolute", left: 0, right: 0, bottom: 0, height: 80, background: "linear-gradient(transparent, rgba(16,16,18,1))" }} />
    </div>
  );
  return <Scene clip={clip} dur={G8_DUR} push={[1, 1.04]} origin={[540, 650]} focus={sheet * 0.4} kicks={[60]} front={rows} />;
};

/* ---------------------------------------------------------- /code-reveal */
// a code window types the effect, a timer runs, then the window folds into the rendered result
const CODE = [
  ["const ", "orbit", " = useOrbit({"],
  ["  cards: ", "reels", ","],
  ["  ring: { rx: ", "455", ", ry: ", "120", " },"],
  ["  near: ", "'front'", ", far: ", "'behind'", ","],
  ["});"],
  [""],
  ["render(", "<Orbit {...orbit} />", ");"],
];
export const CodeReveal: React.FC<{ clip: ClipProps }> = ({ clip }) => {
  const f = useCurrentFrame();
  const typedChars = Math.max(0, (f - 8) * 3.2);
  const fold = prog(f, 66, 82, EASE.inOutHard);
  let used = 0;
  const win = (
    <div style={{ position: "absolute", left: 70, right: 70, top: 260, height: 820, borderRadius: 30, background: "#0F1115", border: "1.5px solid rgba(255,255,255,0.1)", boxShadow: "0 30px 70px rgba(0,0,0,0.55)", transformOrigin: "50% 0%", transform: `perspective(1600px) rotateX(${fold * 70}deg) translateY(${fold * -120}px)`, opacity: 1 - fold }}>
      <div style={{ height: 70, display: "flex", alignItems: "center", gap: 12, padding: "0 26px", borderBottom: "1px solid rgba(255,255,255,0.07)" }}>
        {["#FF5F57", "#FEBC2E", "#28C840"].map((c) => <div key={c} style={{ width: 18, height: 18, borderRadius: 9, background: c }} />)}
        <div style={{ marginLeft: 18, fontFamily: MONO, fontSize: 22, color: "rgba(255,255,255,0.5)" }}>orbit.tsx</div>
        <div style={{ marginLeft: "auto", padding: "6px 14px", borderRadius: 14, background: "#1C1F26", fontFamily: MONO, fontSize: 22, color: "#fff" }}>00:{String(Math.min(59, Math.floor(f / 3))).padStart(2, "0")}</div>
      </div>
      <div style={{ padding: "34px 34px", fontFamily: MONO, fontSize: 32, lineHeight: 1.7 }}>
        {CODE.map((line, li) => (
          <div key={li} style={{ whiteSpace: "pre", minHeight: 54 }}>
            <span style={{ color: "rgba(255,255,255,0.25)", marginRight: 22 }}>{String(li + 1).padStart(2, " ")}</span>
            {line.map((tok, ti) => {
              const start = used;
              used += tok.length;
              const n = Math.max(0, Math.min(tok.length, typedChars - start));
              const col = ti % 2 === 1 ? (tok.startsWith("'") ? "#A5E075" : /^[0-9]/.test(tok) ? "#F7B955" : Y) : "#D7DAE0";
              return <span key={ti} style={{ color: col }}>{tok.slice(0, n)}</span>;
            })}
          </div>
        ))}
      </div>
    </div>
  );
  const grow = prog(f, 72, 90, EASE.inOutHard);
  const result = f >= 72 ? (
    <div style={{ position: "absolute", left: lerp(330, 0, grow), top: lerp(420, 0, grow), width: lerp(420, 1080, grow), height: lerp(746, 1920, grow), borderRadius: lerp(30, 0, grow), overflow: "hidden", boxShadow: "0 30px 70px rgba(0,0,0,0.5)", opacity: prog(f, 72, 78) }}>
      <div style={{ width: 1080, height: 1920, transform: `scale(${lerp(420, 1080, grow) / 1080})`, transformOrigin: "0 0" }}>
        <OffthreadVideo src={staticFile("fx/orbit.mp4")} muted startFrom={30} style={{ width: 1080, height: 1920 }} />
      </div>
    </div>
  ) : null;
  return <Scene clip={clip} dur={G8_DUR} push={[1, 1.04]} origin={[540, 700]} focus={(1 - fold) * prog(f, 2, 12) * 0.7} kicks={[80]} front={win} hud={result} />;
};

/* ---------------------------------------------------------- /hand-cards */
// two cards appear held between the hands, they flip to show the combination
export const HandCards: React.FC<{ clip: ClipProps }> = ({ clip }) => {
  const f = useCurrentFrame();
  const card = (i: number, x: number, rot: number, front: string, back: string) => {
    const k = prog(f, 6 + i * 4, 22 + i * 4, EASE.out);
    const flip = prog(f, 40 + i * 6, 56 + i * 6, EASE.inOutHard);
    const showBack = flip > 0.5;
    const float = Math.sin((f + i * 20) / 16) * 6;
    return (
      <div key={i} style={{ position: "absolute", left: x, top: 1400 + float, width: 260, height: 160, transform: `perspective(900px) translateY(${(1 - k) * 80}px) rotate(${rot}deg) rotateY(${flip * 180}deg)`, opacity: k }}>
        <div style={{ position: "absolute", inset: 0, borderRadius: 18, background: showBack ? Y : paper, boxShadow: "0 16px 34px rgba(0,0,0,0.45)", display: "flex", alignItems: "center", justifyContent: "center", padding: 18, transform: showBack ? "rotateY(180deg)" : undefined }}>
          <div style={{ fontFamily: showBack ? SANS : SERIF, fontStyle: showBack ? "normal" : "italic", fontWeight: showBack ? 900 : 400, fontSize: showBack ? 40 : 44, letterSpacing: showBack ? -1.5 : -0.5, color: ink, textAlign: "center", lineHeight: 1 }}>{showBack ? back : front}</div>
        </div>
      </div>
    );
  };
  const label = (
    <div style={{ position: "absolute", left: 0, right: 0, top: 1320, textAlign: "center", fontFamily: SANS, fontWeight: 700, fontSize: 40, color: "#fff", opacity: prog(f, 30, 40), textShadow: "0 2px 12px rgba(0,0,0,0.6)" }}>the combinations</div>
  );
  return <Scene clip={clip} dur={G8_DUR} push={[1, 1.05]} origin={[540, 1400]} kicks={[48, 54]} front={<>{label}{card(0, 250, -5, "a hook", "ORBIT")}{card(1, 570, 5, "an effect", "+ GLASS")}</>} />;
};

/* ---------------------------------------------------------- /split-notes */
// top half becomes a clean board: two note cards land, a prompt box fills in under them
export const SplitNotes: React.FC<{ clip: ClipProps }> = ({ clip }) => {
  const f = useCurrentFrame();
  const split = prog(f, 2, 18, EASE.inOutHard);
  const q = "Turn these two into a hook";
  const n = Math.max(0, Math.min(q.length, Math.floor((f - 44) / 1.1)));
  const note = (i: number, x: number, rot: number, dark: boolean, t: string) => {
    const k = prog(f, 14 + i * 7, 28 + i * 7, EASE.back);
    return (
      <div style={{ position: "absolute", left: x, top: 210, width: 330, height: 200, borderRadius: 18, background: dark ? ink : "#EDEBE4", color: dark ? "#fff" : ink, padding: 26, transform: `rotate(${rot}deg) translateY(${(1 - k) * -160}px) scale(${lerp(0.9, 1, k)})`, opacity: Math.min(1, k * 2), boxShadow: "0 18px 40px rgba(0,0,0,0.18)", fontFamily: SANS, fontWeight: 900, fontSize: 40, lineHeight: 0.98, letterSpacing: -1.4 }}>{t}</div>
    );
  };
  return (
    <AbsoluteFill style={{ background: "#000", overflow: "hidden" }}>
      <AbsoluteFill style={{ transform: `translateY(${split * 480}px)` }}>
        <Scene clip={clip} dur={G8_DUR} push={[1, 1.03]} origin={[540, 700]} />
      </AbsoluteFill>
      <div style={{ position: "absolute", left: 0, right: 0, top: 0, height: 960 * split, background: paper, overflow: "hidden", boxShadow: "0 10px 40px rgba(0,0,0,0.3)" }}>
        {note(0, 150, -4, true, "HOOKS THAT HOLD")}
        {note(1, 560, 3, false, "3 SECOND RULE")}
        <div style={{ position: "absolute", left: 120, right: 120, top: 560, height: 120, borderRadius: 30, background: "#fff", border: "1.5px solid #E2DFD6", display: "flex", alignItems: "center", padding: "0 30px", fontFamily: SANS, fontSize: 32, color: n ? ink : "#A4A19A", opacity: prog(f, 34, 44), boxShadow: "0 10px 24px rgba(0,0,0,0.06)" }}>
          {n ? q.slice(0, n) : "Describe the edit…"}
          <div style={{ marginLeft: "auto", width: 64, height: 64, borderRadius: 20, background: "#C6613F", display: "grid", placeItems: "center", color: "#fff", fontSize: 30 }}>↑</div>
        </div>
      </div>
    </AbsoluteFill>
  );
};

/* ---------------------------------------------------------- /app-tutorial */
// Claude's desktop app over the shot: "Step 1" timer, a cursor clicks New, the reply arrives
export const AppTutorial: React.FC<{ clip: ClipProps }> = ({ clip }) => {
  const f = useCurrentFrame();
  const win = prog(f, 2, 20, EASE.out);
  const reply = prog(f, 56, 70, EASE.out);
  const step = f < 44 ? 1 : 2;
  const ui = (
    <div style={{ position: "absolute", left: 50, right: 50, top: 70, height: 820, borderRadius: 30, background: paper, boxShadow: "0 30px 80px rgba(0,0,0,0.5)", transform: `translateY(${(1 - win) * 120}px) scale(${lerp(0.94, 1, win)})`, opacity: win, overflow: "hidden" }}>
      <div style={{ position: "absolute", left: 26, top: 24, display: "flex", gap: 10 }}>{["#FF5F57", "#FEBC2E", "#28C840"].map((c) => <div key={c} style={{ width: 16, height: 16, borderRadius: 8, background: c }} />)}</div>
      <div style={{ position: "absolute", left: 110, top: 16, display: "flex", gap: 12, alignItems: "center" }}>
        <div style={{ padding: "6px 14px", borderRadius: 12, background: ink, color: "#fff", fontFamily: MONO, fontSize: 20 }}>00:{String(12 + Math.floor(f / 3)).padStart(2, "0")}</div>
        <div style={{ fontFamily: SANS, fontWeight: 700, fontSize: 26, color: "#C6613F" }}>Step {step}</div>
      </div>
      <div style={{ position: "absolute", left: 0, top: 70, bottom: 0, width: 230, borderRight: "1px solid #E6E2D8", padding: "26px 22px", fontFamily: SANS, fontSize: 24, color: "#555" }}>
        {["New chat", "Projects", "Artifacts", "Customize"].map((t, i) => (
          <div key={t} style={{ padding: "12px 14px", borderRadius: 12, background: i === 0 && f >= 34 ? "#ECE7DA" : undefined, color: i === 0 ? ink : "#666" }}>{t}</div>
        ))}
      </div>
      <div style={{ position: "absolute", left: 230, right: 0, top: 70, bottom: 0 }}>
        <div style={{ position: "absolute", left: 0, right: 0, top: 230, textAlign: "center", opacity: 1 - reply }}>
          <Asterisk size={46} rot={f * 2} />
          <div style={{ fontFamily: SERIF, fontSize: 40, color: ink, marginTop: 12 }}>How can I help you today?</div>
        </div>
        <div style={{ position: "absolute", left: 40, right: 40, top: 120, opacity: reply, transform: `translateY(${(1 - reply) * 20}px)` }}>
          <div style={{ marginLeft: "auto", width: "fit-content", background: "#EFEADD", padding: "12px 18px", borderRadius: 16, fontFamily: MONO, fontSize: 24, color: ink }}>/orbit</div>
          <div style={{ marginTop: 30, fontFamily: SANS, fontSize: 30, lineHeight: 1.35, color: ink }}>Done. Your reels now orbit around you, the near ones in front and the far ones behind.</div>
        </div>
        <div style={{ position: "absolute", left: 40, right: 40, bottom: 34, height: 90, borderRadius: 24, border: "1.5px solid #E2DFD6", background: "#fff" }} />
      </div>
    </div>
  );
  return (
    <AbsoluteFill style={{ background: "#000", overflow: "hidden" }}>
      <AbsoluteFill style={{ transform: `translateY(${win * 470}px)` }}>
        <Scene clip={clip} dur={G8_DUR} push={[1, 1.03]} origin={[540, 700]} />
      </AbsoluteFill>
      <div style={{ position: "absolute", left: 0, right: 0, top: 0, height: 960 * win, background: "#E9E6DE", overflow: "hidden" }}>
        {ui}
        <Cursor path={[[10, 900, 900], [32, 160, 225], [60, 520, 760]]} clicks={[34, 50]} />
      </div>
    </AbsoluteFill>
  );
};

/* ---------------------------------------------------------- /caption-pill */
// the spoken word types into a chat pill with your avatar, the send dot pulses on each word
const PW = ["PRESS", "ONE", "BUTTON"];
export const CaptionPill: React.FC<{ clip: ClipProps }> = ({ clip }) => {
  const f = useCurrentFrame();
  const enter = prog(f, 2, 16, EASE.out);
  const wi = Math.min(PW.length - 1, Math.floor(Math.max(0, f - 12) / 22));
  const since = Math.max(0, f - 12 - wi * 22);
  const w = PW[wi];
  const n = Math.min(w.length, Math.floor(since / 1.6) + 1);
  const pulse = Math.max(0, 1 - since / 8);
  const pill = (
    <div style={{ position: "absolute", left: 120, right: 120, top: 1420, height: 110, borderRadius: 55, background: "rgba(250,249,246,0.97)", display: "flex", alignItems: "center", gap: 20, padding: "0 16px 0 14px", boxShadow: "0 20px 50px rgba(0,0,0,0.4)", transform: `translateY(${(1 - enter) * 80}px) scale(${lerp(0.9, 1, enter)})`, opacity: enter }}>
      <div style={{ width: 82, height: 82, borderRadius: 41, overflow: "hidden", border: `3px solid ${Y}` }}><Tile src="talk1-thumb" w={82} h={82} /></div>
      <div style={{ flex: 1, fontFamily: SANS, fontWeight: 900, fontSize: 52, letterSpacing: -1.5, color: ink }}>{w.slice(0, n)}<span style={{ color: "#C6613F" }}>{f % 16 < 8 ? "|" : " "}</span></div>
      <div style={{ width: 78, height: 78, borderRadius: 39, background: "#FF3B30", display: "grid", placeItems: "center", transform: `scale(${1 + 0.12 * pulse})`, boxShadow: `0 0 0 ${14 * pulse}px rgba(255,59,48,${0.25 * pulse})` }}>
        <div style={{ width: 22, height: 22, borderRadius: 11, background: "#fff" }} />
      </div>
    </div>
  );
  return <Scene clip={clip} dur={G8_DUR} push={[1, 1.04]} origin={[540, 1300]} front={pill} />;
};
