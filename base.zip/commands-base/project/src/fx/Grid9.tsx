/**
 * Grid effects, part 9: the "CUT" reel (instagram.com/p/Deu_IDwIBkk).
 * /glass-explainer, /explainer-panel, /cinematic-type, /image-cluster, /cutout-grid,
 * /cutout-backdrop, /depth-ui, /split-reel, /split-document, /song-card
 * Accent stays Marcel's yellow; the reference's orange becomes a warm amber glow.
 */
import React from "react";
import { AbsoluteFill, Img, staticFile, useCurrentFrame } from "remotion";
import { EASE, prog, track, lerp, velocityOf } from "../kit/motion";
import { MotionBlur } from "../kit/fx";
import { Phrase, Roll } from "../kit/text";
import { Clip, ClipProps, Cutout, Scene, FilmGrain, SANS, SERIF, MONO, Y } from "./common";

export const G9_DUR = 100;
const AMBER = "rgba(255,170,40,";
const art = (n: number) => staticFile(`art/a${n}.jpg`);

/** your shot inside a rounded window (used by the explainer layouts) */
const Window: React.FC<{ clip: ClipProps; x: number; y: number; w: number; h: number; r?: number; focusY?: number }> = ({ clip, x, y, w, h, r = 28, focusY = 0.32 }) => {
  const s = Math.max(w / 1080, h / 1920) * 1.15;
  return (
    <div style={{ position: "absolute", left: x, top: y, width: w, height: h, borderRadius: r, overflow: "hidden", boxShadow: "0 24px 60px rgba(0,0,0,0.5)" }}>
      <div style={{ position: "absolute", left: (w - 1080 * s) / 2, top: h / 2 - 1920 * s * focusY, width: 1080, height: 1920, transform: `scale(${s})`, transformOrigin: "0 0" }}><Clip {...clip} /></div>
    </div>
  );
};

/** dark glass tile with a value */
const GlassTile: React.FC<{ w: number; h: number; children: React.ReactNode; hot?: number }> = ({ w, h, children, hot = 0 }) => (
  <div style={{ width: w, height: h, borderRadius: 18, background: "linear-gradient(180deg, rgba(255,255,255,0.10), rgba(255,255,255,0.03))", border: `1.5px solid rgba(255,255,255,${0.16 + 0.3 * hot})`, boxShadow: `inset 0 1px 0 rgba(255,255,255,0.25), 0 20px 40px rgba(0,0,0,0.5)${hot ? `, 0 0 ${40 * hot}px ${AMBER}${0.35 * hot})` : ""}`, display: "flex", alignItems: "center", justifyContent: "center" }}>{children}</div>
);

/* ---------------------------------------------------------- /glass-explainer */
// black stage, a chapter tab, two glass tiles: $1 vs a number that rolls up to $1,000,000, warm glow, you in a window below
export const GlassExplainer: React.FC<{ clip: ClipProps }> = ({ clip }) => {
  const f = useCurrentFrame();
  const tab = prog(f, 4, 16, EASE.out);
  const t1 = prog(f, 12, 24, EASE.out);
  const t2 = prog(f, 18, 30, EASE.out);
  const v = Math.round(track(f, [[24, 1], [70, 1000000, EASE.out]]));
  const hot = prog(f, 66, 74, EASE.out);
  const win = prog(f, 8, 26, EASE.out);
  return (
    <AbsoluteFill style={{ background: "#050505", overflow: "hidden" }}>
      <AbsoluteFill style={{ background: `radial-gradient(ellipse 45% 22% at 50% 30%, ${AMBER}${0.22 + 0.2 * hot}), transparent 70%)` }} />
      <AbsoluteFill style={{ backgroundImage: "radial-gradient(rgba(255,255,255,0.05) 1px, transparent 1.4px)", backgroundSize: "26px 26px" }} />
      <div style={{ position: "absolute", left: 150, top: 150, width: 680, height: 96, display: "flex", alignItems: "center", background: "linear-gradient(90deg, rgba(255,255,255,0.16), rgba(255,255,255,0.06))", border: "1.5px solid rgba(255,255,255,0.2)", borderLeft: `8px solid ${Y}`, transform: `translateX(${(1 - tab) * -60}px)`, opacity: tab }}>
        <div style={{ fontFamily: SANS, fontWeight: 700, fontSize: 40, color: "#fff", marginLeft: 36 }}>01</div>
        <div style={{ fontFamily: SANS, fontWeight: 700, fontSize: 42, color: "#fff", marginLeft: 120 }}>Contrast</div>
      </div>
      <div style={{ position: "absolute", left: 80, top: 360, display: "flex", gap: 48 }}>
        <div style={{ transform: `translateY(${(1 - t1) * 50}px) scale(${lerp(0.92, 1, t1)})`, opacity: t1 }}>
          <GlassTile w={250} h={190}><div style={{ fontFamily: SANS, fontWeight: 900, fontSize: 90, color: "#fff", letterSpacing: -3 }}>$1</div></GlassTile>
        </div>
        <div style={{ transform: `translateY(${(1 - t2) * 50}px) scale(${lerp(0.92, 1, t2)})`, opacity: t2 }}>
          <GlassTile w={620} h={190} hot={hot}><div style={{ fontFamily: SANS, fontWeight: 900, fontSize: 86, color: hot > 0.5 ? Y : "#fff", letterSpacing: -3, fontVariantNumeric: "tabular-nums" }}>${v.toLocaleString("en-US")}</div></GlassTile>
        </div>
      </div>
      <div style={{ position: "absolute", left: 0, right: 0, top: 1000 }}>
        <Phrase words={[{ text: "a", at: 30 }, { text: "million", at: 34 }, { text: "dollars", at: 38 }]} fontFamily={SANS} fontSize={64} fontWeight={700} letterSpacing={-2} />
      </div>
      <div style={{ transform: `translateY(${(1 - win) * 120}px)`, opacity: win }}>
        <Window clip={clip} x={60} y={1140} w={960} h={700} r={34} focusY={0.47} />
      </div>
      <FilmGrain />
    </AbsoluteFill>
  );
};

/* ---------------------------------------------------------- /explainer-panel */
// a close-up of you on top, a bottom panel that cycles explainer cards with your point
export const ExplainerPanel: React.FC<{ clip: ClipProps }> = ({ clip }) => {
  const f = useCurrentFrame();
  const split = prog(f, 2, 18, EASE.inOutHard);
  const cards = [{ k: "01", t: "Hook", s: "first 2 seconds decide it" }, { k: "02", t: "Contrast", s: "two opposites, one gap" }, { k: "03", t: "Payoff", s: "deliver what you promised" }];
  const idx = Math.min(2, Math.floor(Math.max(0, f - 20) / 24));
  const k = prog(f, 20 + idx * 24, 32 + idx * 24, EASE.out);
  return (
    <AbsoluteFill style={{ background: "#0B0B0C", overflow: "hidden" }}>
      <AbsoluteFill style={{ transform: `scale(${lerp(1, 1.35, split)}) translateY(${split * -120}px)`, transformOrigin: "540px 600px" }}><Clip {...clip} /></AbsoluteFill>
      <div style={{ position: "absolute", left: 0, right: 0, bottom: 0, height: 760 * split, background: "#0B0B0C", borderTop: `2px solid rgba(255,229,0,${0.6 * split})` }}>
        <div style={{ position: "absolute", left: 70, right: 70, top: 90, opacity: k, transform: `translateY(${(1 - k) * 40}px)` }}>
          <div style={{ fontFamily: MONO, fontSize: 26, letterSpacing: 6, color: Y }}>{cards[idx].k} / 03</div>
          <div style={{ fontFamily: SERIF, fontStyle: "italic", fontSize: 150, lineHeight: 1, color: "#fff", marginTop: 16, letterSpacing: -3 }}>{cards[idx].t}</div>
          <div style={{ fontFamily: SANS, fontWeight: 500, fontSize: 44, color: "rgba(255,255,255,0.7)", marginTop: 18 }}>{cards[idx].s}</div>
        </div>
        <div style={{ position: "absolute", left: 70, right: 70, bottom: 90, display: "flex", gap: 14 }}>
          {cards.map((_, i) => <div key={i} style={{ flex: 1, height: 6, borderRadius: 3, background: i <= idx ? Y : "rgba(255,255,255,0.15)" }} />)}
        </div>
      </div>
      <FilmGrain />
    </AbsoluteFill>
  );
};

/* ---------------------------------------------------------- /cinematic-type */
// Full colour cards with editorial type. The headline arrives letter by letter out of a blur
// while its tracking tightens; the line beneath comes in word by word, the last words lighter.
// Each new card pushes the previous one up (exponential, with motion blur). Slow push in and
// a soft centre light the whole time, grain on top.
const CT = [
  { bg: "#E07A1F", big: "more reps", small: ["than", "you've"], hl: ["already", "done."] },
  { bg: "#0E0E10", big: "one prompt", small: ["and", "the", "edit"], hl: ["is", "done."] },
  { bg: Y, big: "no timeline", small: ["no", "template,"], hl: ["no", "excuses."] },
];
const CT_AT = [0, 32, 64];
const CT_PUSH = 9;
const CtCard: React.FC<{ i: number; t: number; layer: "bg" | "type" }> = ({ i, t, layer }) => {
  const c = CT[i];
  const ink = c.bg === Y ? "#0A0A0A" : "#FFFFFF";
  const push = lerp(1.0, 1.05, prog(t, 0, 60, EASE.inOut));
  const track = lerp(-1, -6, prog(t, 2, 24, EASE.out));
  const words = [...c.small.map((w) => ({ w, hl: false })), ...c.hl.map((w) => ({ w, hl: true }))];
  if (layer === "bg")
    return (
      <AbsoluteFill style={{ background: c.bg }}>
        <AbsoluteFill style={{ background: c.bg === "#0E0E10" ? "radial-gradient(ellipse 70% 45% at 50% 48%, rgba(255,255,255,0.07), transparent 70%)" : "radial-gradient(ellipse 70% 45% at 50% 48%, rgba(255,255,255,0.22), transparent 70%)" }} />
      </AbsoluteFill>
    );
  return (
    <AbsoluteFill>
      <AbsoluteFill style={{ transform: `scale(${push})`, transformOrigin: "540px 900px" }}>
        <div style={{ position: "absolute", left: 0, right: 0, top: 800, display: "flex", justifyContent: "center", fontFamily: SERIF, fontStyle: "italic", fontWeight: 400, fontSize: 196, lineHeight: 1, color: ink, letterSpacing: track, whiteSpace: "pre" }}>
          {Array.from(c.big).map((ch, k) => {
            const q = prog(t, 2 + k * 1.3, 16 + k * 1.3, EASE.out);
            return (
              <span key={k} style={{ display: "inline-block", transform: `translateY(${(1 - q) * 0.35}em)`, opacity: Math.min(1, q * 1.6) }}>
                <span style={{ display: "inline-block", filter: q < 0.999 ? `blur(${(1 - q) * 16}px)` : undefined }}>{ch}</span>
              </span>
            );
          })}
        </div>
        <div style={{ position: "absolute", left: 0, right: 0, top: 1024, display: "flex", justifyContent: "center", gap: 14, fontFamily: SANS, fontWeight: 700, fontSize: 54, letterSpacing: -1.2, color: ink }}>
          {words.map(({ w, hl }, k) => {
            const q = prog(t, 12 + k * 3, 24 + k * 3, EASE.out);
            return (
              <span key={k} style={{ display: "inline-block", transform: `translateY(${(1 - q) * 14}px)`, opacity: q * (hl ? 0.55 : 1) }}>
                <span style={{ display: "inline-block", filter: q < 0.999 ? `blur(${(1 - q) * 8}px)` : undefined }}>{w}</span>
              </span>
            );
          })}
        </div>
      </AbsoluteFill>
    </AbsoluteFill>
  );
};
export const CinematicType: React.FC = () => {
  const f = useCurrentFrame();
  let idx = 0;
  CT_AT.forEach((at, k) => { if (f >= at) idx = k; });
  // the push from card idx-1 to idx: 0 = old card in place, 1 = new card in place
  const pushAt = (fr: number) => (idx === 0 ? 1 : prog(fr - CT_AT[idx], 0, CT_PUSH, EASE.inOutHard));
  const q = pushAt(f);
  const vel = (pushAt(f + 0.5) - pushAt(f - 0.5)) * 1920;
  const moving = idx > 0 && q < 1;
  return (
    <AbsoluteFill style={{ background: "#000", overflow: "hidden" }}>
      {/* colour fields push without the blur filter (it drops solid fills), the type gets the motion blur */}
      {moving && <AbsoluteFill style={{ transform: `translateY(${-q * 1920}px)` }}><CtCard i={idx - 1} t={f - CT_AT[idx - 1]} layer="bg" /></AbsoluteFill>}
      <AbsoluteFill style={{ transform: `translateY(${(1 - q) * 1920}px)` }}><CtCard i={idx} t={f - CT_AT[idx]} layer="bg" /></AbsoluteFill>
      <MotionBlur id="ct" vy={moving ? -vel : 0} shutter={0.5} max={90}>
        <AbsoluteFill>
          {moving && (
            <AbsoluteFill style={{ transform: `translateY(${-q * 1920}px)` }}><CtCard i={idx - 1} t={f - CT_AT[idx - 1]} layer="type" /></AbsoluteFill>
          )}
          <AbsoluteFill style={{ transform: `translateY(${(1 - q) * 1920}px)` }}><CtCard i={idx} t={f - CT_AT[idx]} layer="type" /></AbsoluteFill>
        </AbsoluteFill>
      </MotionBlur>
      <FilmGrain opacity={0.08} />
    </AbsoluteFill>
  );
};

/* ---------------------------------------------------------- /image-cluster */
// metaphor images drop in above your head and overlap; a small caption sits at your side
export const ImageCluster: React.FC<{ clip: ClipProps; cut: ClipProps }> = ({ clip, cut }) => {
  const f = useCurrentFrame();
  const IM = [
    { n: 1, x: 70, y: 210, w: 420, h: 300, r: -2, at: 6 },
    { n: 3, x: 660, y: 170, w: 330, h: 380, r: 3, at: 14 },
    { n: 5, x: 330, y: 470, w: 420, h: 300, r: 1, at: 24 },
  ];
  const cap = prog(f, 30, 42, EASE.out);
  const pics = IM.map((m, i) => {
    const k = prog(f, m.at, m.at + 12, EASE.out);
    const vy = velocityOf((t) => (1 - prog(t, m.at, m.at + 12, EASE.out)) * -120, f);
    return (
      <div key={i} style={{ position: "absolute", left: m.x, top: m.y, width: m.w, height: m.h, transform: `translateY(${(1 - k) * -120}px) rotate(${m.r}deg) scale(${lerp(1.08, 1, k)})`, opacity: Math.min(1, k * 2) }}>
        <MotionBlur id={`ic${i}`} vy={vy}>
          <div style={{ width: m.w, height: m.h, overflow: "hidden", boxShadow: "0 20px 44px rgba(0,0,0,0.45)" }}><Img src={art(m.n)} style={{ width: "100%", height: "100%", objectFit: "cover" }} /></div>
        </MotionBlur>
      </div>
    );
  });
  const caption = (
    <div style={{ position: "absolute", left: 40, top: 1180, width: 300, fontFamily: SANS, fontWeight: 500, fontSize: 30, lineHeight: 1.2, color: "#fff", opacity: cap, transform: `translateX(${(1 - cap) * -30}px)`, textShadow: "0 2px 10px rgba(0,0,0,0.6)" }}>pair two opposites and let the gap do the work</div>
  );
  // the images sit behind you (your head overlaps the lowest one), the caption stays in front
  return <Scene clip={clip} cut={cut} dur={G9_DUR} push={[1, 1.04]} origin={[540, 700]} kicks={[8, 16, 26]} back={pics} front={caption} />;
};

/* ---------------------------------------------------------- /cutout-grid */
// a 2x2 grid of images fills the frame behind your cutout, the images swap together on each idea
export const CutoutGrid: React.FC<{ clip: ClipProps; cut: ClipProps }> = ({ clip, cut }) => {
  const f = useCurrentFrame();
  const sets = [[1, 2, 3, 4], [5, 6, 7, 8]];
  const idx = f < 50 ? 0 : 1;
  const swap = prog(f, 50, 58, EASE.out);
  const inT = prog(f, 4, 22, EASE.out);
  const cell = (i: number) => {
    const k = prog(f, 4 + i * 3, 18 + i * 3, EASE.out);
    const n = sets[idx][i];
    return (
      <div key={i} style={{ position: "absolute", left: (i % 2) * 540, top: Math.floor(i / 2) * 960, width: 540, height: 960, overflow: "hidden", opacity: k }}>
        <Img src={art(n)} style={{ width: "100%", height: "100%", objectFit: "cover", transform: `scale(${lerp(1.15, 1, k) * (idx ? lerp(1.1, 1, swap) : 1)})` }} />
      </div>
    );
  };
  const words = idx === 0 ? "For example, one dollar" : "versus a million dollars";
  return (
    <AbsoluteFill style={{ background: "#000", overflow: "hidden" }}>
      <AbsoluteFill style={{ opacity: 1 - inT }}><Clip {...clip} /></AbsoluteFill>
      {[0, 1, 2, 3].map(cell)}
      <AbsoluteFill style={{ background: "rgba(0,0,0,0.12)" }} />
      <AbsoluteFill style={{ transform: "scale(1.05)", transformOrigin: "540px 1500px" }}><Cutout {...cut} /></AbsoluteFill>
      <div style={{ position: "absolute", left: 0, right: 0, top: 1180, textAlign: "center", fontFamily: SANS, fontWeight: 700, fontSize: 44, color: "#fff", textShadow: "0 2px 14px rgba(0,0,0,0.7)" }}>{words}</div>
      <FilmGrain />
    </AbsoluteFill>
  );
};

/* ---------------------------------------------------------- /cutout-backdrop */
// you cut out over one full-screen image per idea, each image pushes in as it arrives
export const CutoutBackdrop: React.FC<{ clip: ClipProps; cut: ClipProps }> = ({ clip, cut }) => {
  const f = useCurrentFrame();
  const AT = [6, 38, 70];
  const IMG = [7, 2, 8];
  let idx = -1;
  AT.forEach((a, i) => { if (f >= a) idx = i; });
  return (
    <AbsoluteFill style={{ background: "#000", overflow: "hidden" }}>
      <Clip {...clip} />
      {idx >= 0 && (() => {
        const since = f - AT[idx];
        const wipe = prog(since, 0, 8, EASE.out);
        return (
          <AbsoluteFill style={{ clipPath: `inset(0 0 ${(1 - wipe) * 100}% 0)` }}>
            <Img src={art(IMG[idx])} style={{ width: 1080, height: 1920, objectFit: "cover", transform: `scale(${lerp(1.18, 1.05, prog(since, 0, 32, EASE.out))})`, filter: "brightness(0.8)" }} />
          </AbsoluteFill>
        );
      })()}
      <Cutout {...cut} />
      <div style={{ position: "absolute", left: 0, right: 0, top: 1240, textAlign: "center", fontFamily: SERIF, fontStyle: "italic", fontSize: 92, color: "#fff", textShadow: "0 4px 20px rgba(0,0,0,0.6)" }}>{["one idea", "one image", "one cut"][Math.max(0, idx)]}</div>
      <FilmGrain />
    </AbsoluteFill>
  );
};

/* ---------------------------------------------------------- /depth-ui */
// an interface card sits behind your head (light / dark switch), a numbered marker pops, a serif word on your chest
export const DepthUi: React.FC<{ clip: ClipProps; cut: ClipProps }> = ({ clip, cut }) => {
  const f = useCurrentFrame();
  const card = prog(f, 4, 20, EASE.out);
  const flip = prog(f, 40, 52, EASE.inOutHard);
  const num = prog(f, 18, 26, EASE.back);
  const word = prog(f, 26, 40, EASE.out);
  const ui = (
    <div style={{ position: "absolute", left: 120, top: 330, width: 840, height: 560, borderRadius: 26, overflow: "hidden", transform: `translateY(${(1 - card) * -80}px) scale(${lerp(0.94, 1, card)})`, opacity: card, boxShadow: "0 30px 70px rgba(0,0,0,0.45)" }}>
      <div style={{ position: "absolute", inset: 0, background: "#F2EFE8" }} />
      <div style={{ position: "absolute", top: 0, bottom: 0, right: 0, width: `${50 + 50 * flip}%`, background: "#0C0C0E" }} />
      <svg width={70} height={70} viewBox="0 0 24 24" style={{ position: "absolute", left: 40, top: 36 }} fill="none" stroke="#111" strokeWidth={1.8} strokeLinecap="round"><circle cx="12" cy="12" r="4" />{[0, 45, 90, 135, 180, 225, 270, 315].map((a) => <path key={a} d="M12 2.5v2.5" transform={`rotate(${a} 12 12)`} />)}</svg>
      <svg width={66} height={66} viewBox="0 0 24 24" style={{ position: "absolute", right: 40, top: 38 }}><path d="M20 14.5A8 8 0 0 1 9.5 4a8 8 0 1 0 10.5 10.5z" fill="#fff" /></svg>
      <div style={{ position: "absolute", left: 130, top: 44, width: 54, height: 54, borderRadius: 27, background: Y, display: "grid", placeItems: "center", fontFamily: SANS, fontWeight: 900, fontSize: 28, color: "#111", transform: `scale(${num})` }}>1</div>
      {/* the two halves say the idea: the quiet one disappears when the dark side takes over */}
      <div style={{ position: "absolute", left: 40, top: 150, fontFamily: SERIF, fontStyle: "italic", fontSize: 104, letterSpacing: -2, lineHeight: 1, color: "#111", opacity: card }}>quiet</div>
      <div style={{ position: "absolute", right: 40, top: 150, fontFamily: SANS, fontWeight: 900, fontSize: 96, letterSpacing: -4, lineHeight: 1.05, color: "#fff", opacity: card }}>LOUD</div>
      <div style={{ position: "absolute", left: 40, top: 270, fontFamily: MONO, fontSize: 18, letterSpacing: 2, color: "rgba(17,17,17,0.55)", opacity: card * (1 - flip) }}>BEFORE</div>
      <div style={{ position: "absolute", right: 40, top: 270, fontFamily: MONO, fontSize: 18, letterSpacing: 2, color: "rgba(255,255,255,0.55)", opacity: card }}>AFTER</div>
    </div>
  );
  const chest = (
    <div style={{ position: "absolute", left: 0, right: 0, top: 1310, textAlign: "center", opacity: word, transform: `translateY(${(1 - word) * 24}px)` }}>
      <span style={{ fontFamily: SERIF, fontStyle: "italic", fontSize: 140, color: Y, letterSpacing: -3, textShadow: "0 4px 24px rgba(0,0,0,0.5)" }}>contrast</span>
    </div>
  );
  return <Scene clip={clip} cut={cut} dur={G9_DUR} push={[1, 1.06]} origin={[540, 800]} kicks={[46]} back={ui} front={chest} />;
};

/* ---------------------------------------------------------- /split-reel */
// face on top, a dark panel below with a serif kicker, a big title and $1 vs a rolling number, thumbnails slide in
export const SplitReel: React.FC<{ clip: ClipProps; thumbs: string[] }> = ({ clip, thumbs }) => {
  const f = useCurrentFrame();
  const split = prog(f, 2, 18, EASE.inOutHard);
  const tt = prog(f, 14, 28, EASE.out);
  const a = prog(f, 26, 36, EASE.out);
  const b = prog(f, 32, 42, EASE.out);
  const v = Math.round(track(f, [[40, 1], [74, 16785, EASE.out]]));
  const th = prog(f, 70, 86, EASE.out);
  return (
    <AbsoluteFill style={{ background: "#0B0A09", overflow: "hidden" }}>
      <AbsoluteFill style={{ transform: `translateY(${split * -560}px) scale(${lerp(1, 1.12, split)})`, transformOrigin: "540px 700px" }}><Clip {...clip} /></AbsoluteFill>
      <div style={{ position: "absolute", left: 0, right: 0, bottom: 0, height: 1000 * split, background: `radial-gradient(ellipse 60% 40% at 50% 60%, ${AMBER}0.16), transparent 70%), #0B0A09` }}>
        <div style={{ position: "absolute", left: 0, right: 0, top: 70, textAlign: "center", opacity: tt, transform: `translateY(${(1 - tt) * 30}px)` }}>
          <div style={{ fontFamily: SERIF, fontStyle: "italic", fontSize: 50, color: Y }}>number one</div>
          <div style={{ fontFamily: SANS, fontWeight: 900, fontSize: 130, letterSpacing: -5, color: Y, lineHeight: 1 }}>CONTRAST</div>
          <div style={{ fontFamily: SERIF, fontStyle: "italic", fontSize: 38, color: "rgba(255,255,255,0.7)", marginTop: 6 }}>for example</div>
        </div>
        <div style={{ position: "absolute", left: 60, right: 60, top: 420, display: "flex", alignItems: "center", gap: 26 }}>
          <div style={{ opacity: a, transform: `translateY(${(1 - a) * 40}px)` }}><GlassTile w={330} h={190}><div style={{ textAlign: "center" }}><div style={{ fontFamily: SANS, fontWeight: 900, fontSize: 90, color: "#fff" }}>$1</div><div style={{ fontFamily: MONO, fontSize: 18, letterSpacing: 4, color: "rgba(255,255,255,0.5)" }}>ONE DOLLAR</div></div></GlassTile></div>
          <div style={{ width: 70, height: 70, borderRadius: 35, background: "#1B1916", border: "1.5px solid rgba(255,255,255,0.2)", display: "grid", placeItems: "center", fontFamily: SANS, fontWeight: 700, fontSize: 24, color: "#fff", opacity: a }}>VS</div>
          <div style={{ opacity: b, transform: `translateY(${(1 - b) * 40}px)` }}><GlassTile w={430} h={190} hot={prog(f, 72, 80)}><div style={{ textAlign: "center" }}><div style={{ fontFamily: SANS, fontWeight: 900, fontSize: 82, color: "#fff", fontVariantNumeric: "tabular-nums" }}>${v.toLocaleString("en-US")}</div><div style={{ fontFamily: MONO, fontSize: 18, letterSpacing: 4, color: "rgba(255,255,255,0.5)" }}>A MILLION DOLLARS</div></div></GlassTile></div>
        </div>
        <div style={{ position: "absolute", left: 30, top: 680, display: "flex", gap: 14, transform: `translateX(${(1 - th) * 300}px)`, opacity: th }}>
          {thumbs.map((t, i) => <div key={i} style={{ width: 240, height: 136, borderRadius: 12, overflow: "hidden", boxShadow: "0 10px 24px rgba(0,0,0,0.5)" }}><Img src={staticFile(t)} style={{ width: "100%", height: "100%", objectFit: "cover" }} /></div>)}
        </div>
      </div>
      <FilmGrain />
    </AbsoluteFill>
  );
};

/* ---------------------------------------------------------- /split-document */
// a document on the left fills in with highlights and a margin note, you on the right
export const SplitDocument: React.FC<{ clip: ClipProps }> = ({ clip }) => {
  const f = useCurrentFrame();
  const split = prog(f, 2, 18, EASE.inOutHard);
  const LINES = ["The hook is the first two seconds.", "Open on the result, never on a face.", "Pair two opposites and let the gap", "do the work. Then pay it off fast.", "Cut every pause longer than 0.4 s.", "End on the frame you started with."];
  const HL = [1, 2];
  return (
    <AbsoluteFill style={{ background: "#F1EEE6", overflow: "hidden" }}>
      <div style={{ position: "absolute", top: 0, bottom: 0, right: 0, width: lerp(1080, 500, split), overflow: "hidden" }}>
        <div style={{ position: "absolute", top: 0, left: -(1080 - lerp(1080, 500, split)) / 2 - 290 * split, width: 1080, height: 1920 }}><Clip {...clip} /></div>
      </div>
      <div style={{ position: "absolute", left: 50, top: 220, width: 500, opacity: split }}>
        <div style={{ fontFamily: MONO, fontSize: 20, letterSpacing: 5, color: "#8A857A" }}>EDIT NOTES · v3</div>
        <div style={{ fontFamily: SERIF, fontSize: 70, color: "#151412", lineHeight: 1, marginTop: 14, letterSpacing: -1 }}>The <i>contrast</i> rule</div>
        <div style={{ marginTop: 40 }}>
          {LINES.map((l, i) => {
            const n = Math.max(0, Math.min(l.length, Math.floor((f - 14 - i * 9) * 2.2)));
            const hl = HL.includes(i) ? prog(f, 70 + HL.indexOf(i) * 6, 80 + HL.indexOf(i) * 6, EASE.out) : 0;
            return (
              <div key={i} style={{ position: "relative", fontFamily: SANS, fontWeight: 500, fontSize: 30, lineHeight: 1.7, color: "#24221E" }}>
                <span style={{ position: "relative", zIndex: 1 }}>{l.slice(0, n)}</span>
                {hl > 0 && <div style={{ position: "absolute", left: -4, top: 12, height: 34, width: `${hl * 100}%`, background: "rgba(255,229,0,0.75)" }} />}
              </div>
            );
          })}
        </div>
        <div style={{ marginTop: 40, padding: "16px 20px", borderLeft: `5px solid ${Y}`, background: "#fff", fontFamily: SERIF, fontStyle: "italic", fontSize: 34, color: "#151412", opacity: prog(f, 84, 94), transform: `translateX(${(1 - prog(f, 84, 94, EASE.out)) * -30}px)` }}>this is the whole trick.</div>
      </div>
      <FilmGrain opacity={0.05} />
    </AbsoluteFill>
  );
};

/* ---------------------------------------------------------- /song-card */
// a now-playing card on a clean light stage, progress moves, then the lyric word punches in
export const SongCard: React.FC<{ clip: ClipProps }> = ({ clip }) => {
  const f = useCurrentFrame();
  const c = prog(f, 4, 20, EASE.out);
  const out = prog(f, 62, 74, EASE.inOutHard);
  const word = prog(f, 70, 80, EASE.out);
  return (
    <AbsoluteFill style={{ background: "#EDECE8", overflow: "hidden" }}>
      <AbsoluteFill style={{ clipPath: `inset(${(1 - out) * 100}% 0 0 0)` }}><Clip {...clip} /></AbsoluteFill>
      <div style={{ position: "absolute", left: 140, top: 480, width: 800, padding: 40, borderRadius: 34, background: "#FBFBF9", boxShadow: "0 30px 70px rgba(0,0,0,0.18)", transform: `translateY(${(1 - c) * 60 - out * 1400}px) scale(${lerp(0.95, 1, c)})`, opacity: c }}>
        <div style={{ width: 720, height: 440, borderRadius: 22, overflow: "hidden", boxShadow: "0 14px 30px rgba(0,0,0,0.25)" }}><Img src={art(1)} style={{ width: "100%", height: "100%", objectFit: "cover" }} /></div>
        <div style={{ fontFamily: SANS, fontWeight: 700, fontSize: 52, color: "#111", marginTop: 30 }}>Night Edit</div>
        <div style={{ fontFamily: SANS, fontSize: 30, color: "#888", marginTop: 4 }}>marcelgrau · Commands</div>
        <div style={{ height: 8, borderRadius: 4, background: "#E2E1DC", marginTop: 34 }}><div style={{ height: "100%", width: `${12 + f * 0.6}%`, borderRadius: 4, background: "#111" }} /></div>
        <div style={{ display: "flex", justifyContent: "space-between", fontFamily: MONO, fontSize: 20, color: "#999", marginTop: 10 }}><span>0:{String(Math.floor(f / 3)).padStart(2, "0")}</span><span>-1:12</span></div>
      </div>
      <div style={{ position: "absolute", left: 0, right: 0, top: 1240, textAlign: "center", opacity: word, transform: `scale(${lerp(1.3, 1, word)})` }}>
        <span style={{ fontFamily: SANS, fontWeight: 900, fontSize: 150, color: "#fff", letterSpacing: -6, textShadow: "0 6px 30px rgba(0,0,0,0.5)" }}>In.</span>
      </div>
      <FilmGrain opacity={0.05} />
    </AbsoluteFill>
  );
};

void Roll;
