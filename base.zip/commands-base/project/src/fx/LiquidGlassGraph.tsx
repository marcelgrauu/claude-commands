/**
 * /liquid-glass-graph — a thick liquid glass slab floats up in front of the
 * chest and a retention graph climbs inside it.
 *   0-22   slab flips up out of the desk (rotateX 70 -> 8), focus pulls off the clip
 *   14-26  label tracks in, big number rises
 *   18-70  this reel's line draws (white -> yellow), last reel's dashed line sits low,
 *          data points pop as the head passes them, the number counts with the line
 *   70     the hit: line reaches the top, tip halo + ring, +212% chip snaps in, camera kick
 *   72-96  specular sweep, slab floats, last frame holds
 */
import React from "react";
import { interpolate, useCurrentFrame } from "remotion";
import { EXPO_OUT, QUINT_INOUT, BACK_OUT, SOFT, p, TrackIn } from "../kit";
import { ClipProps, GlassPane, Scene, Sweep, MONO, TIGHT, SANS, Y } from "./common";

export const LIQUID_GRAPH_DUR = 100;

const NOW: [number, number][] = [[0, 34], [9, 32], [18, 33.5], [27, 29], [36, 30], [45, 24], [54, 25.5], [63, 18], [72, 16], [81, 10], [90, 7], [100, 3]];
const LAST: [number, number][] = [[0, 33], [20, 34], [40, 33], [60, 35], [80, 34.5], [100, 36]];

const smooth = (pts: [number, number][]) => {
  let d = `M ${pts[0][0]} ${pts[0][1]}`;
  for (let i = 1; i < pts.length; i++) {
    const [x0, y0] = pts[i - 1];
    const [x1, y1] = pts[i];
    const cx = (x0 + x1) / 2;
    d += ` C ${cx} ${y0}, ${cx} ${y1}, ${x1} ${y1}`;
  }
  return d;
};
const yAt = (pts: [number, number][], x: number) => {
  for (let i = 1; i < pts.length; i++) {
    if (x <= pts[i][0]) {
      const [x0, y0] = pts[i - 1];
      const [x1, y1] = pts[i];
      const u = (x - x0) / (x1 - x0);
      const e = u * u * (3 - 2 * u);
      return y0 + (y1 - y0) * e;
    }
  }
  return pts[pts.length - 1][1];
};

export const LiquidGlassGraph: React.FC<{ clip: ClipProps; cy?: number }> = ({ clip, cy = 1330 }) => {
  const f = useCurrentFrame();
  const W = 820;
  const H = 540;
  const x = (1080 - W) / 2;
  const y = cy - H / 2;
  const enter = p(f, 2, 24, EXPO_OUT);
  const draw = p(f, 18, 70, QUINT_INOUT);
  const hit = 70;
  const value = Math.round(interpolate(draw, [0, 1], [19, 68]));
  const chip = p(f, hit, hit + 10, BACK_OUT);
  const halo = p(f, hit, hit + 22, EXPO_OUT);
  const float = Math.sin(f / 19) * 7;
  const yaw = Math.sin(f / 31) * 3.5;
  const gx = 56;
  const gy = 250;
  const gw = W - 112;
  const gh = 210;
  const tipX = draw * 100;
  const tipY = yAt(NOW, tipX);
  const px = (vx: number) => gx + (vx / 100) * gw;
  const py = (vy: number) => gy + (vy / 40) * gh;

  const slab = (
    <div style={{ position: "absolute", inset: 0, perspective: 1600 }}>
      {/* soft shadow the slab throws on his shirt */}
      <div style={{ position: "absolute", left: x + 80, top: y + H - 20, width: W - 160, height: 90, borderRadius: "50%", background: "rgba(0,0,0,0.45)", filter: "blur(34px)", opacity: enter }} />
      <div style={{ position: "absolute", inset: 0, transformOrigin: `540px ${cy}px`, transform: `translateY(${(1 - enter) * 280 + float}px) rotateX(${(1 - enter) * 62 + 7}deg) rotateY(${yaw}deg) scale(${0.84 + 0.16 * enter})`, opacity: Math.min(1, enter * 1.8) }}>
        <GlassPane x={x} y={y} w={W} h={H} r={58} clip={clip} blur={24} lift={1.08} mag={1.12} tint="rgba(255,255,255,0.05)">
          {/* header */}
          <div style={{ position: "absolute", left: gx, top: 46 }}>
            <TrackIn text="RETENTION" at={12} style={{ fontFamily: MONO, fontSize: 24, color: "rgba(255,255,255,0.72)" }} fromTrack={0.9} toTrack={0.34} />
          </div>
          <div style={{ position: "absolute", left: gx - 4, top: 86, display: "flex", alignItems: "flex-end", gap: 10, opacity: p(f, 14, 24), transform: `translateY(${(1 - p(f, 14, 26, EXPO_OUT)) * 30}px)` }}>
            <div style={{ fontFamily: TIGHT, fontWeight: 800, fontSize: 132, lineHeight: 0.9, letterSpacing: -6, color: "#fff", fontVariantNumeric: "tabular-nums", textShadow: f > hit ? `0 0 ${30 * halo}px rgba(255,229,0,${0.35 * (1 - halo * 0.5)})` : undefined }}>{value}</div>
            <div style={{ fontFamily: TIGHT, fontWeight: 300, fontSize: 64, color: "rgba(255,255,255,0.8)", marginBottom: 10 }}>%</div>
          </div>
          <div style={{ position: "absolute", right: 52, top: 104, display: "flex", alignItems: "center", gap: 10, padding: "10px 18px", borderRadius: 40, background: "rgba(48,209,88,0.18)", border: "1.5px solid rgba(48,209,88,0.55)", transform: `scale(${chip})`, opacity: chip, transformOrigin: "100% 50%" }}>
            <svg width={26} height={26} viewBox="0 0 24 24" fill="none" stroke="#5BE37D" strokeWidth={3} strokeLinecap="round" strokeLinejoin="round"><path d="M4 16l6-6 4 4 6-7" /><path d="M14 7h6v6" /></svg>
            <div style={{ fontFamily: SANS, fontWeight: 700, fontSize: 28, color: "#7CF09A" }}>+212%</div>
          </div>
          <div style={{ position: "absolute", right: 56, top: 52, display: "flex", gap: 22, fontFamily: SANS, fontSize: 26, color: "rgba(255,255,255,0.7)", opacity: p(f, 16, 28) }}>
            <span><span style={{ display: "inline-block", width: 22, height: 4, borderRadius: 2, background: Y, verticalAlign: "middle", marginRight: 8 }} />this reel</span>
            <span><span style={{ display: "inline-block", width: 22, height: 0, borderTop: "3px dashed rgba(255,255,255,0.5)", verticalAlign: "middle", marginRight: 8 }} />last reel</span>
          </div>
          {/* grid */}
          {[0, 1, 2, 3].map((g) => (
            <div key={g} style={{ position: "absolute", left: gx, width: gw * p(f, 10 + g * 2, 30 + g * 2, EXPO_OUT), top: gy + (g * gh) / 3, height: 1, background: "rgba(255,255,255,0.12)" }} />
          ))}
          <svg viewBox="0 0 100 40" preserveAspectRatio="none" style={{ position: "absolute", left: gx, top: gy, width: gw, height: gh, overflow: "visible" }}>
            <defs>
              <linearGradient id="lgStroke" x1="0" y1="0" x2="1" y2="0">
                <stop offset="0" stopColor="#FFFFFF" />
                <stop offset="0.65" stopColor={Y} />
                <stop offset="1" stopColor={Y} />
              </linearGradient>
              <linearGradient id="lgArea" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0" stopColor={Y} stopOpacity="0.34" />
                <stop offset="1" stopColor={Y} stopOpacity="0" />
              </linearGradient>
              <clipPath id="lgReveal"><rect x={0} y={-10} width={tipX} height={60} /></clipPath>
            </defs>
            <path d={smooth(LAST)} fill="none" stroke="rgba(255,255,255,0.42)" strokeWidth={2} strokeDasharray="6 7" vectorEffect="non-scaling-stroke" opacity={p(f, 14, 26)} />
            <g clipPath="url(#lgReveal)">
              <path d={`${smooth(NOW)} L 100 40 L 0 40 Z`} fill="url(#lgArea)" />
              <path d={smooth(NOW)} fill="none" stroke="url(#lgStroke)" strokeWidth={4.2} vectorEffect="non-scaling-stroke" strokeLinecap="round" style={{ filter: "drop-shadow(0 0 8px rgba(255,229,0,0.8))" }} />
            </g>
          </svg>
          {/* data points pop as the head passes them */}
          {NOW.slice(1, -1).filter((_, i) => i % 2 === 1).map(([vx, vy]) => {
            const k = p(f, 18 + (vx / 100) * 52, 26 + (vx / 100) * 52, BACK_OUT);
            return <div key={vx} style={{ position: "absolute", left: px(vx) - 7, top: py(vy) - 7, width: 14, height: 14, borderRadius: 7, background: "#111", border: `3px solid ${Y}`, transform: `scale(${k})` }} />;
          })}
          {/* tip */}
          {draw > 0.01 && (
            <>
              <div style={{ position: "absolute", left: px(tipX) - 16, top: py(tipY) - 16, width: 32, height: 32, borderRadius: 16, background: "#fff", boxShadow: `0 0 0 9px rgba(255,229,0,0.32), 0 0 34px 12px rgba(255,229,0,0.55)` }} />
              {f >= hit && <div style={{ position: "absolute", left: px(tipX) - 70, top: py(tipY) - 70, width: 140, height: 140, borderRadius: 70, border: `2.5px solid ${Y}`, transform: `scale(${0.3 + halo * 1.3})`, opacity: 1 - halo }} />}
              <div style={{ position: "absolute", left: Math.min(px(tipX) - 70, gx + gw - 170), top: py(tipY) - 74, padding: "8px 14px", borderRadius: 12, background: "rgba(10,10,10,0.72)", border: "1px solid rgba(255,255,255,0.18)", fontFamily: MONO, fontSize: 24, color: "#fff", whiteSpace: "nowrap", opacity: p(f, 24, 32) }}>
                0:{String(Math.round(draw * 30)).padStart(2, "0")} · {value}%
              </div>
            </>
          )}
          <div style={{ position: "absolute", left: gx, right: gx, bottom: 26, display: "flex", justifyContent: "space-between", fontFamily: MONO, fontSize: 23, color: "rgba(255,255,255,0.55)", letterSpacing: 2 }}>
            <span>0s</span><span>10s</span><span>20s</span><span>30s</span>
          </div>
          <Sweep t={p(f, 72, 96, QUINT_INOUT)} r={58} opacity={0.42} />
        </GlassPane>
      </div>
    </div>
  );

  return <Scene clip={clip} dur={LIQUID_GRAPH_DUR} push={[1, 1.07]} origin={[540, 1150]} kicks={[hit]} focus={p(f, 4, 26, SOFT) * 0.4} front={slab} />;
};
