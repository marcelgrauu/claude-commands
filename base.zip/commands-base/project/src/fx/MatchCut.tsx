/**
 * /match-cut — modelled frame by frame on @corbinsylk's match cut.
 * The same paragraph, typeset again and again in a different publication
 * (typewriter, book serif, clean sans, dark mode, halftone print...). The pages
 * are flat, shot like a macro lens: the line with the word is sharp, every
 * other line falls out of focus with distance, the left and right edges blur
 * too, and the centre of the page is lit brighter than the edges.
 * "Claude" sits in a brick red box with cream type IN THE PAGE'S OWN FONT and
 * never moves; only what surrounds it changes. Cuts accelerate (5, 5, then 3
 * frames each), the camera pushes in slowly the whole time, the last page holds about half a second.
 */
import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { EASE } from "../kit/motion";
import { SANS, SERIF, MONO } from "./common";

export const MATCHCUT_DUR = 72;

type Page = { bg: string; ink: string; font: string; weight: number; size: number; track?: number; halftone?: boolean; shift: number; cw: number };

const LINES_ABOVE = [
  "Something changed in the edit suite this month.",
  "Video teams that used to need a week for one",
  "editors once spent whole weekends on one reel",
  "and are now handing over raw footage",
  "to get a finished cut back before lunch.",
  "Editors are rethinking what the job even is,",
  "and agencies are quietly rebuilding",
];
const LINE_LEFT = ["the week everyone switched to", "a tool called", "all made by", "it was built by", "everything runs on", "the new editor is", "they handed it to", "all thanks to"];
const LINE_RIGHT = ["for every cut.", "and it shows.", "in one prompt.", "while they slept.", "from scratch.", "and nobody noticed.", "this quarter.", "and that's the edit."];
const LINES_BELOW = [
  "around it. Early users describe the shift",
  "as unsettling, then impossible to give up.",
  "The tools behind it read every word",
  "of the transcript, cut the dead air and",
  "match the pace to the speaker. Nobody",
  "on the team has opened a timeline since.",
  "It started as an experiment in one studio.",
];

const BOOK = "Georgia, 'Times New Roman', serif";
const PAGES: Page[] = [
  { bg: "#E9E4D6", ink: "#3A3328", font: MONO, weight: 400, size: 92, track: 1, shift: 0, halftone: true, cw: 0.62 },
  { bg: "#F1EEE6", ink: "#252220", font: BOOK, weight: 400, size: 104, shift: 1, cw: 0.55 },
  { bg: "#FAFAF8", ink: "#141414", font: SANS, weight: 500, size: 100, track: -1.6, shift: 2, cw: 0.56 },
  { bg: "#E8EAEE", ink: "#2A2C30", font: MONO, weight: 500, size: 88, track: 0.5, shift: 3, cw: 0.62 },
  { bg: "#131315", ink: "#E9E7E2", font: SANS, weight: 500, size: 100, track: -1.5, shift: 4, cw: 0.56 },
  { bg: "#F3EDE1", ink: "#2C261E", font: SERIF, weight: 400, size: 116, shift: 5, cw: 0.5 },
  { bg: "#FFFFFF", ink: "#0E0E0E", font: SANS, weight: 900, size: 94, track: -3, shift: 6, cw: 0.62 },
  { bg: "#EFEBE3", ink: "#26221C", font: BOOK, weight: 700, size: 100, shift: 7, cw: 0.58 },
];
const CUTS = [0, 5, 10, 13, 16, 19, 22, 25, 28, 31, 34, 37, 40, 43, 46, 49, 52, 56];
const CY = 960;
// width of the red box: 6 glyphs of the page font at 1.12x, plus padding
const boxW = (pg: Page) => pg.size * 1.18 * pg.cw * 6 + pg.size * 0.44;

const PageView: React.FC<{ pg: Page; idx: number }> = ({ pg, idx }) => {
  const lh = pg.size * 1.32;
  const t: React.CSSProperties = { fontFamily: pg.font, fontWeight: pg.weight, fontSize: pg.size, letterSpacing: pg.track ?? 0, color: pg.ink, whiteSpace: "nowrap", lineHeight: `${lh}px` };
  const x0 = -120 - ((idx * 137) % 260);
  const line = (txt: string, d: number) => (
    <div key={d} style={{ ...t, position: "absolute", left: x0, top: CY - lh / 2 + d * lh, filter: `blur(${Math.min(10, Math.max(0, Math.abs(d) - 1) * 1.9 + 0.6).toFixed(1)}px)` }}>{txt}</div>
  );
  return (
    <AbsoluteFill style={{ background: pg.bg }}>
      {LINES_ABOVE.map((s, i) => line(s, i - LINES_ABOVE.length))}
      {LINES_BELOW.map((s, i) => line(s, i + 1))}
      {/* the word line: left text ends right at the box, right text starts right after it */}
      <div style={{ ...t, position: "absolute", right: 540 + boxW(pg) / 2 + pg.size * 0.18, top: CY - lh / 2 }}>{LINE_LEFT[pg.shift % LINE_LEFT.length]}</div>
      <div style={{ ...t, position: "absolute", left: 540 + boxW(pg) / 2 + pg.size * 0.18, top: CY - lh / 2 }}>{LINE_RIGHT[(pg.shift + idx) % LINE_RIGHT.length]}</div>
      {pg.halftone && <AbsoluteFill style={{ backgroundImage: "radial-gradient(rgba(60,40,20,0.32) 1.6px, transparent 2px)", backgroundSize: "7px 7px", mixBlendMode: "multiply" }} />}
    </AbsoluteFill>
  );
};

export const MatchCut: React.FC = () => {
  const f = useCurrentFrame();
  let idx = 0;
  for (let i = 0; i < CUTS.length; i++) if (f >= CUTS[i]) idx = i;
  const pg = PAGES[idx % PAGES.length];
  const push = interpolate(f, [0, MATCHCUT_DUR], [1, 1.16], { easing: EASE.inOut });
  const drift = Math.sin(f / 23) * 3;
  const lh = pg.size * 1.32;
  const dark = pg.bg === "#131315";
  return (
    <AbsoluteFill style={{ background: pg.bg, overflow: "hidden" }}>
      <AbsoluteFill style={{ transform: `translate(${drift}px, 0) scale(${push})`, transformOrigin: "540px 960px" }}>
        {/* out of focus copy for the edges, sharp copy in an oval around the word */}
        <AbsoluteFill style={{ filter: "blur(8px)" }}><PageView pg={pg} idx={idx} /></AbsoluteFill>
        <AbsoluteFill style={{ WebkitMaskImage: "radial-gradient(ellipse 70% 34% at 50% 50%, #000 45%, transparent 100%)", maskImage: "radial-gradient(ellipse 70% 34% at 50% 50%, #000 45%, transparent 100%)" }}>
          <PageView pg={pg} idx={idx} />
        </AbsoluteFill>
        {/* the locked word, in the page's own typeface */}
        <div style={{ position: "absolute", left: 0, right: 0, top: CY - lh / 2, height: lh, display: "flex", alignItems: "center", justifyContent: "center" }}>
          <div style={{ padding: `${pg.size * 0.05}px ${pg.size * 0.22}px ${pg.size * 0.09}px`, borderRadius: 8, background: "linear-gradient(180deg, #C9472D 0%, #B63A22 100%)", boxShadow: "0 6px 18px rgba(120,30,10,0.35), 0 0 34px rgba(255,120,80,0.35)" }}>
            <div style={{ fontFamily: pg.font, fontWeight: Math.max(700, pg.weight), fontSize: pg.size * 1.18, letterSpacing: pg.track ?? 0, color: "#FBF3E6", lineHeight: 1.08, textShadow: "0 0 12px rgba(255,240,225,0.55)", whiteSpace: "nowrap" }}>Claude</div>
          </div>
        </div>
      </AbsoluteFill>
      {/* macro light: bright centre, falloff to the edges */}
      <AbsoluteFill style={{ background: dark ? "radial-gradient(ellipse 70% 55% at 50% 50%, rgba(255,255,255,0.05), rgba(0,0,0,0.55) 100%)" : "radial-gradient(ellipse 70% 55% at 50% 50%, rgba(255,255,255,0.3) 0%, transparent 55%, rgba(30,25,15,0.36) 100%)" }} />
    </AbsoluteFill>
  );
};
