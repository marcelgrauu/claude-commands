/**
 * /orbit — modelled frame by frame on @tenfoldmarc's 01/17.
 *   Small reel cards (thumbnails with a caption label burned in, white rim) orbit
 *   around the BODY at chest height, facing camera: the near half passes in front
 *   of you (bigger, sharp), the far half behind your cutout (smaller, softer).
 *   Above the head, the line lands in two voices: "and you can get the" in small
 *   Helvetica, word by word, then "main character" in a big Apple Garamond italic,
 *   pale gold, with two sparkles that twinkle.
 * Camera: slow push, the ring keeps a steady spin after a fast spin-in.
 */
import React from "react";
import { useCurrentFrame } from "remotion";
import { EASE, prog, velocityOf, lerp } from "../kit/motion";
import { MotionBlur } from "../kit/fx";
import { Phrase } from "../kit/text";
import { ClipProps, Scene, Tile, SANS, SERIF } from "./common";

export const ORBIT_DUR = 110;

const CX = 540;
const CY = 1290; // chest
const RX = 455;
const RY = 120;
const W = 168;
const H = 296;

const CAPS = [
  "CLAUDE EDITED THIS IN 1 PROMPT",
  "THE EDIT THAT GOT 2M VIEWS",
  "NO TIMELINE. NO TEMPLATE.",
  "I TYPED ONE LINE",
  "THIS IS NOT AFTER EFFECTS",
  "MOTION GRAPHICS IN 30 SEC",
  "YOUR NEXT REEL, DONE",
  "COMMENT COMMANDS",
];

const ringAngle = (f: number) => prog(f, 0, 40, EASE.out) * 2.6 + f * 0.022;

const pose = (i: number, n: number, f: number) => {
  const arrive = prog(f, 1 + i * 1.5, 22 + i * 1.5, EASE.out);
  const a = (i / n) * Math.PI * 2 + ringAngle(f);
  const s = Math.sin(a);
  const x = CX + RX * Math.cos(a) * lerp(0.35, 1, arrive);
  const y = CY + RY * s * lerp(0.35, 1, arrive);
  return { x, y, s, arrive, depth: (s + 1) / 2 };
};

const Card: React.FC<{ i: number; n: number; src: string }> = ({ i, n, src }) => {
  const f = useCurrentFrame();
  const { x, y, arrive, depth } = pose(i, n, f);
  const vx = velocityOf((t) => pose(i, n, t).x, f);
  const scale = (0.62 + 0.42 * depth) * lerp(0.92, 1, arrive);
  const far = 1 - depth;
  return (
    <div style={{ position: "absolute", left: x - W / 2, top: y - H / 2, width: W, height: H, transform: `scale(${scale})`, opacity: Math.min(1, arrive * 2.2) }}>
      <MotionBlur id={`orb${i}`} vx={vx} shutter={0.5}>
        <div style={{ filter: far > 0.55 ? `blur(${((far - 0.55) * 4).toFixed(2)}px) brightness(${1 - (far - 0.55) * 0.5})` : undefined }}>
          <div style={{ position: "relative", width: W, height: H, borderRadius: 16, overflow: "hidden", background: "#111", boxShadow: "0 0 0 3px rgba(250,248,240,0.95), 0 14px 30px rgba(0,0,0,0.42)" }}>
            <Tile src={src} w={W} h={H} offset={i * 9} />
            <div style={{ position: "absolute", left: 10, right: 10, top: 64, textAlign: "center" }}>
              <span style={{ background: "#0B0B0B", color: "#fff", fontFamily: SANS, fontWeight: 900, fontSize: 15, lineHeight: 1.25, padding: "3px 6px", boxDecorationBreak: "clone", WebkitBoxDecorationBreak: "clone", letterSpacing: -0.2 }}>{CAPS[i % CAPS.length]}</span>
            </div>
          </div>
        </div>
      </MotionBlur>
    </div>
  );
};

const Sparkle: React.FC<{ x: number; y: number; size: number; at: number }> = ({ x, y, size, at }) => {
  const f = useCurrentFrame();
  const on = prog(f, at, at + 8, EASE.out);
  const tw = 0.75 + 0.25 * Math.sin((f - at) / 4.5);
  const k = on * tw;
  if (k <= 0.01) return null;
  return (
    <svg width={size * 2} height={size * 2} viewBox="-1 -1 2 2" style={{ position: "absolute", left: x - size, top: y - size, overflow: "visible", transform: `rotate(${(f - at) * 1.5}deg) scale(${k})` }}>
      <path d="M0 -1 Q0.08 -0.08 1 0 Q0.08 0.08 0 1 Q-0.08 0.08 -1 0 Q-0.08 -0.08 0 -1Z" fill="#F4E7A1" style={{ filter: "drop-shadow(0 0 0.15px rgba(255,236,160,0.8))" }} />
    </svg>
  );
};

const Title: React.FC = () => {
  const f = useCurrentFrame();
  const big = prog(f, 22, 40, EASE.out);
  const glow = prog(f, 34, 50, EASE.out);
  return (
    <div style={{ position: "absolute", left: 0, right: 0, top: 330 }}>
      <Phrase
        words={[{ text: "and", at: 6 }, { text: "you", at: 9 }, { text: "can", at: 12 }, { text: "get", at: 15 }, { text: "the", at: 18 }]}
        fontFamily={SANS}
        fontSize={52}
        fontWeight={500}
        letterSpacing={-1}
        color="#FFFFFF"
        dur={14}
        blur={10}
        style={{ textShadow: "0 2px 12px rgba(0,0,0,0.45)" }}
      />
      <div style={{ position: "relative", height: 190, marginTop: 4 }}>
        <div style={{ position: "absolute", left: 0, right: 0, top: 0, textAlign: "center", transform: `translateY(${(1 - big) * 34}px) scale(${lerp(0.94, 1, big)})`, opacity: big }}>
          <div style={{ filter: big < 0.999 ? `blur(${(1 - big) * 16}px)` : undefined }}>
            <span style={{ fontFamily: SERIF, fontStyle: "italic", fontWeight: 400, fontSize: 168, letterSpacing: -3, lineHeight: 1, color: "#F2E6A2", textShadow: glow > 0 ? `0 0 ${24 * glow}px rgba(255,232,150,${0.45 * glow}), 0 4px 18px rgba(0,0,0,0.35)` : undefined }}>main character</span>
          </div>
        </div>
        <Sparkle x={52} y={84} size={18} at={38} />
        <Sparkle x={1010} y={150} size={14} at={44} />
      </div>
    </div>
  );
};

export const Orbit: React.FC<{ clip: ClipProps; cut: ClipProps; reels: string[] }> = ({ clip, cut, reels }) => {
  const f = useCurrentFrame();
  const n = reels.length;
  const ids = reels.map((_, i) => i);
  const far = ids.filter((i) => pose(i, n, f).s <= 0).sort((a, b) => pose(a, n, f).s - pose(b, n, f).s);
  const near = ids.filter((i) => pose(i, n, f).s > 0).sort((a, b) => pose(a, n, f).s - pose(b, n, f).s);
  return (
    <Scene
      clip={clip}
      cut={cut}
      dur={ORBIT_DUR}
      push={[1, 1.05]}
      origin={[CX, 1000]}
      back={<>{far.map((i) => <Card key={i} i={i} n={n} src={reels[i]} />)}</>}
      front={<>{near.map((i) => <Card key={i} i={i} n={n} src={reels[i]} />)}</>}
      hud={<Title />}
    />
  );
};
