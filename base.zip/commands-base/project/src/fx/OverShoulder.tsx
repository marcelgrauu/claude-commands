/**
 * /over-the-shoulder-zoom — proof cards land beside your head, before then after.
 * Reads in one second: a small grey BEFORE card ($3,200 / month) lands and gets
 * struck out, a marker arrow draws to the right, the big AFTER card slams in and
 * its number counts up to $32,000 with a 10x chip. The camera drifts over the
 * shoulder towards the cards the whole time; one hard beat on the slam.
 */
import React from "react";
import { interpolate, useCurrentFrame } from "remotion";
import { EXPO_OUT, BACK_OUT, QUINT_INOUT, SOFT, p } from "../kit";
import { ClipProps, Scene, MONO, TIGHT, SANS, Y } from "./common";

export const OVERSHOULDER_DUR = 100;

const Card: React.FC<{ label: string; tone: "dim" | "hero"; children: React.ReactNode; w: number }> = ({ label, tone, children, w }) => (
  <div style={{ width: w, borderRadius: 30, background: tone === "hero" ? "#FFFFFF" : "#EDEBE5", padding: "28px 34px 30px", boxShadow: "0 34px 80px rgba(0,0,0,0.55), 0 6px 16px rgba(0,0,0,0.25), inset 0 1px 0 #fff", position: "relative" }}>
    <div style={{ display: "inline-block", fontFamily: MONO, fontSize: 22, letterSpacing: 6, padding: "6px 12px", borderRadius: 8, background: tone === "hero" ? "#0A0A0A" : "rgba(0,0,0,0.08)", color: tone === "hero" ? Y : "rgba(0,0,0,0.55)" }}>{label}</div>
    <div style={{ marginTop: 14 }}>{children}</div>
  </div>
);

const money = (v: number) => "$" + Math.round(v).toLocaleString("en-US");

export const OverShoulder: React.FC<{ clip: ClipProps }> = ({ clip }) => {
  const f = useCurrentFrame();
  const a = p(f, 6, 22, BACK_OUT);
  const strike = p(f, 26, 36, QUINT_INOUT);
  const arrow = p(f, 34, 46, QUINT_INOUT);
  const SLAM = 48;
  const b = p(f, SLAM - 4, SLAM + 6, EXPO_OUT);
  const count = interpolate(p(f, SLAM, SLAM + 26, QUINT_INOUT), [0, 1], [3200, 32000]);
  const chip = p(f, SLAM + 24, SLAM + 34, BACK_OUT);
  const ring = p(f, SLAM, SLAM + 20, EXPO_OUT);

  const cards = (
    <>
      {/* BEFORE: small, grey, struck out */}
      <div style={{ position: "absolute", left: 640, top: 340, transform: `translateY(${(1 - a) * -100}px) rotate(${-7 + (1 - a) * -10}deg) scale(${0.7 + 0.3 * a})`, opacity: Math.min(1, a * 2) * (1 - 0.35 * b), transformOrigin: "50% 0%" }}>
        <Card label="BEFORE" tone="dim" w={300}>
          <div style={{ position: "relative", display: "inline-block" }}>
            <div style={{ fontFamily: TIGHT, fontWeight: 800, fontSize: 62, letterSpacing: -3, color: "#6B6860", lineHeight: 1 }}>$3,200</div>
            <div style={{ position: "absolute", left: -8, right: -8, top: "52%", height: 9, borderRadius: 5, background: "#E5322D", transform: `scaleX(${strike}) rotate(-4deg)`, transformOrigin: "0 50%" }} />
          </div>
          <div style={{ fontFamily: SANS, fontSize: 26, color: "rgba(0,0,0,0.45)", marginTop: 8 }}>per month</div>
        </Card>
      </div>
      {/* marker arrow from before to after */}
      <svg width={1080} height={1920} style={{ position: "absolute", left: 0, top: 0, overflow: "visible" }}>
        <path d="M 760 600 C 700 650, 690 700, 720 745" fill="none" stroke={Y} strokeWidth={9} strokeLinecap="round" pathLength={1} strokeDasharray={`${arrow} 1`} style={{ filter: "drop-shadow(0 4px 8px rgba(0,0,0,0.4))" }} />
        {arrow > 0.95 && <path d="M 696 736 L 722 748 L 723 718" fill="none" stroke={Y} strokeWidth={9} strokeLinecap="round" strokeLinejoin="round" />}
      </svg>
      {/* AFTER: big, white, counts up */}
      {f >= SLAM - 4 && (
        <div style={{ position: "absolute", left: 560, top: 760, transform: `translateY(${(1 - b) * 140}px) rotate(${3 - (1 - b) * 9}deg) scale(${1.4 - 0.4 * b})`, opacity: Math.min(1, b * 3), transformOrigin: "50% 50%" }}>
          <Card label="AFTER" tone="hero" w={380}>
            <div style={{ fontFamily: TIGHT, fontWeight: 800, fontSize: 80, letterSpacing: -3.5, color: "#0A0A0A", lineHeight: 1, fontVariantNumeric: "tabular-nums" }}>{money(count)}</div>
            <div style={{ display: "flex", alignItems: "center", gap: 14, marginTop: 10 }}>
              <div style={{ fontFamily: SANS, fontSize: 28, color: "rgba(0,0,0,0.5)" }}>per month</div>
              <div style={{ display: "flex", alignItems: "center", gap: 6, padding: "6px 14px", borderRadius: 30, background: "#E7F8EC", color: "#1E9E4A", fontFamily: SANS, fontWeight: 700, fontSize: 26, transform: `scale(${chip})`, opacity: chip }}>
                <svg width={22} height={22} viewBox="0 0 24 24" fill="none" stroke="#1E9E4A" strokeWidth={3} strokeLinecap="round" strokeLinejoin="round"><path d="M12 19V5M6 11l6-6 6 6" /></svg>10x
              </div>
            </div>
          </Card>
        </div>
      )}
      {f >= SLAM && ring < 1 && <div style={{ position: "absolute", left: 750 - 240, top: 860 - 240, width: 480, height: 480, borderRadius: 240, border: "2px solid rgba(255,255,255,0.75)", transform: `scale(${0.4 + ring * 1.1})`, opacity: (1 - ring) * 0.6 }} />}
    </>
  );

  const drift = interpolate(f, [0, OVERSHOULDER_DUR], [0, 1], { easing: SOFT });
  return <Scene clip={clip} dur={OVERSHOULDER_DUR} push={[1, 1.06]} origin={[760 + 30 * drift, 700]} kicks={[SLAM]} front={cards} />;
};
