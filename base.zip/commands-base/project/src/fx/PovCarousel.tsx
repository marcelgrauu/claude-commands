/**
 * /pov-carousel-spin — a clean gallery ring of your reels around your head
 * (the "selected works" ring look): flat circle first, then it tilts into 3D so
 * the near half passes in front of you and the far half behind your cutout,
 * then it spins. Minimal pill tabs on top switch Flat -> Tilt -> Ring with the motion.
 */
import React from "react";
import { Img, staticFile, useCurrentFrame } from "remotion";
import { EXPO_OUT, QUINT_INOUT, p } from "../kit";
import { ClipProps, Scene, SANS } from "./common";

export const CAROUSEL_DUR = 100;

const N = 10;
const CX = 545;
const CY = 860;
const R = 440;
const TW = 176;
const TH = 236;

export const PovCarouselSpin: React.FC<{ clip: ClipProps; cut: ClipProps; covers: { img: string }[] }> = ({ clip, cut, covers }) => {
  const f = useCurrentFrame();
  const tilt = p(f, 34, 58, QUINT_INOUT) * 26; // degrees, a gentle tilt keeps the face clear
  const spin = f * 0.006 + p(f, 60, 92, QUINT_INOUT) * Math.PI * 0.9;
  const mode = f < 34 ? 0 : f < 60 ? 1 : 2;
  const tk = (tilt * Math.PI) / 180;

  const tiles = Array.from({ length: N }).map((_, i) => {
    const a = (i / N) * Math.PI * 2 + spin - Math.PI / 2;
    const appear = p(f, 2 + i * 1.6, 16 + i * 1.6, EXPO_OUT);
    const x = CX + R * Math.cos(a) * appear;
    const y = CY + R * Math.sin(a) * Math.cos(tk) * appear;
    const depth = Math.sin(a) * Math.sin(tk); // >0 near
    const s = (1 + depth * 0.35) * (0.6 + 0.4 * appear);
    return { i, x, y, depth, s, appear };
  });

  const tile = (t: (typeof tiles)[0]) => (
    <div key={t.i} style={{ position: "absolute", left: t.x - TW / 2, top: t.y - TH / 2, width: TW, height: TH, transform: `scale(${t.s})`, opacity: t.appear }}>
      <div style={{ position: "absolute", inset: 0, filter: t.depth < -0.05 ? `blur(${-t.depth * 3}px) brightness(${1 + t.depth * 0.3})` : undefined }}>
        <div style={{ position: "absolute", inset: 0, borderRadius: 10, overflow: "hidden", background: "#fff", boxShadow: "0 14px 30px rgba(0,0,0,0.35)", border: "3px solid #fff" }}>
          <Img src={staticFile(covers[t.i % covers.length].img)} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
        </div>
      </div>
    </div>
  );

  const far = tiles.filter((t) => t.depth <= 0).sort((a, b) => a.depth - b.depth);
  const near = tiles.filter((t) => t.depth > 0).sort((a, b) => a.depth - b.depth);

  const tabs = ["Flat", "Tilt", "Ring", "Gallery"];
  const ui = (
    <>
      <div style={{ position: "absolute", left: 0, right: 0, top: 110, display: "flex", justifyContent: "center", gap: 14, opacity: p(f, 4, 16) }}>
        {tabs.map((t, i) => (
          <div key={t} style={{ padding: "12px 30px", borderRadius: 40, border: "2px solid rgba(255,255,255,0.85)", background: mode === i ? "#fff" : "rgba(0,0,0,0.18)", color: mode === i ? "#111" : "#fff", fontFamily: SANS, fontWeight: 700, fontSize: 32 }}>{t}</div>
        ))}
      </div>
    </>
  );

  return <Scene clip={clip} cut={cut} dur={CAROUSEL_DUR} push={[1, 1.05]} origin={[CX, CY]} focus={p(f, 2, 24) * 0.6} back={<>{far.map(tile)}</>} front={<>{near.map(tile)}</>} hud={ui} />;
};
