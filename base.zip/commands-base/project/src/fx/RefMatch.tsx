/**
 * Effects rebuilt to match their reference frame by frame.
 *  /phone-mockup  (tenfold 06/17): a real iPhone slides out from behind your head, slightly turned,
 *                 an assistant app shows one recommendation, a finger tap hits Approve.
 *  /reel-feed     (justyn.ai 15/18): a real Instagram Reels feed scrolled by thumb, always
 *                 upwards, through other reels, landing on you again.
 *  /checklist     (tenfold 07/17): dark glass card at the top, ALL YOU NEED TO DO 0 of 3,
 *                 each line types in and its circle fills with a yellow check.
 */
import React from "react";
import { AbsoluteFill, Img, OffthreadVideo, staticFile, useCurrentFrame } from "remotion";
import { EASE, prog, track, lerp, velocityOf, Key } from "../kit/motion";
import { MotionBlur } from "../kit/fx";
import { Clip, ClipProps, Scene, Tile, SANS, MONO, Y } from "./common";

export const REF_DUR = 100;

/* ---------------------------------------------------------- /phone-mockup */
const PW = 330;
const PH = 680;
export const PhoneMockup: React.FC<{ clip: ClipProps; cut: ClipProps }> = ({ clip, cut }) => {
  const f = useCurrentFrame();
  const enter = prog(f, 4, 26, EASE.out);
  const bob = Math.sin(f / 18) * 6;
  const card = prog(f, 22, 36, EASE.out);
  const TAP = 58;
  const tapT = prog(f, TAP - 14, TAP, EASE.inOut);
  const press = Math.max(0, 1 - Math.abs(f - TAP) / 4);
  const done = prog(f, TAP + 2, TAP + 12, EASE.out);
  const fingerOut = prog(f, TAP + 6, TAP + 18, EASE.in);
  const screen = (
    <div style={{ position: "absolute", inset: 10, borderRadius: 50, background: "#0E0F12", overflow: "hidden" }}>
      <div style={{ position: "absolute", left: "50%", top: 14, width: 104, height: 32, marginLeft: -52, borderRadius: 16, background: "#000" }} />
      <div style={{ position: "absolute", left: 26, right: 26, top: 20, display: "flex", justifyContent: "space-between", fontFamily: SANS, fontWeight: 700, fontSize: 17, color: "#fff" }}><span>9:41</span><span>●●●</span></div>
      <div style={{ position: "absolute", left: 24, top: 82, display: "flex", alignItems: "center", gap: 10 }}>
        <div style={{ width: 34, height: 34, borderRadius: 17, background: Y, display: "grid", placeItems: "center", fontFamily: SANS, fontWeight: 900, fontSize: 18, color: "#111" }}>✦</div>
        <div><div style={{ fontFamily: SANS, fontWeight: 700, fontSize: 18, color: "#fff" }}>Edit Assistant</div><div style={{ fontFamily: SANS, fontSize: 13, color: "#8B8E96" }}>● online</div></div>
      </div>
      <div style={{ position: "absolute", left: 24, right: 24, top: 140, fontFamily: SANS, fontSize: 18, color: "#C9CBD1" }}>Found one fix for you.</div>
      <div style={{ position: "absolute", left: 18, right: 18, top: 176, borderRadius: 22, background: "#1A1C21", border: "1px solid #2A2D34", padding: "18px 18px 20px", transform: `translateY(${(1 - card) * 30}px)`, opacity: card }}>
        <div style={{ fontFamily: MONO, fontSize: 12, letterSpacing: 2, color: "#8B8E96" }}>● RECOMMENDATION</div>
        <div style={{ fontFamily: SANS, fontWeight: 700, fontSize: 22, lineHeight: 1.25, color: "#fff", marginTop: 10 }}>Cut the first 2 seconds, move the hook to 0:00</div>
        <div style={{ display: "flex", gap: 8, marginTop: 16 }}>
          {["Hook", "Cut", "Captions"].map((t, i) => (
            <div key={t} style={{ flex: 1, height: 64, borderRadius: 10, background: "#24272E", display: "flex", flexDirection: "column", justifyContent: "flex-end", padding: 7 }}>
              <div style={{ height: 6 + i * 6, borderRadius: 3, background: i === 0 ? Y : "#3A3E47" }} />
              <div style={{ fontFamily: SANS, fontSize: 10, color: "#8B8E96", marginTop: 5 }}>{t}</div>
            </div>
          ))}
        </div>
        <div style={{ display: "flex", gap: 10, marginTop: 18, alignItems: "center" }}>
          <div style={{ flex: 1, height: 52, borderRadius: 26, background: done > 0.5 ? "#34C759" : "#FFFFFF", display: "grid", placeItems: "center", fontFamily: SANS, fontWeight: 700, fontSize: 19, color: done > 0.5 ? "#fff" : "#111", transform: `scale(${1 - 0.06 * press})` }}>{done > 0.5 ? "✓ Applied" : "Approve"}</div>
          <div style={{ fontFamily: SANS, fontSize: 16, color: "#8B8E96", padding: "0 6px" }}>Not now</div>
        </div>
      </div>
      <div style={{ position: "absolute", left: 18, right: 18, bottom: 22, height: 50, borderRadius: 25, background: "#1A1C21", display: "flex", alignItems: "center", padding: "0 18px", fontFamily: SANS, fontSize: 15, color: "#6B6E76" }}>Message…</div>
      <div style={{ position: "absolute", inset: 0, background: "linear-gradient(118deg, rgba(255,255,255,0.10) 0%, transparent 32%)" }} />
    </div>
  );
  // fingertip (a soft grey disc like a real touch) travels to Approve
  const fx = lerp(PW + 60, 110, tapT);
  const fy = lerp(PH + 40, 452, tapT);
  const phone = (
    <div style={{ position: "absolute", inset: 0, perspective: 1500 }}>
      <div style={{ position: "absolute", left: 610, top: 400, width: PW, height: PH, transform: `translate(${(1 - enter) * -235}px, ${(1 - enter) * 520 + bob}px) rotateY(${-18 + (1 - enter) * 24}deg) rotateZ(${3 - enter * 4}deg) scale(${lerp(0.72, 1, enter)})` }}>
        <div style={{ position: "absolute", inset: 0, borderRadius: 60, background: "linear-gradient(135deg,#8E8D88 0%,#3B3A37 22%,#1C1C1B 50%,#4A4945 80%,#9A9893 100%)", boxShadow: "0 50px 90px rgba(0,0,0,0.55), inset 0 0 0 2px rgba(255,255,255,0.18)" }} />
        {screen}
        {f >= TAP - 14 && f < TAP + 18 && (
          <div style={{ position: "absolute", left: fx - 32, top: fy - 32, width: 64, height: 64, borderRadius: 32, background: "radial-gradient(circle, rgba(220,220,225,0.85) 0%, rgba(200,200,205,0.55) 55%, rgba(200,200,205,0) 72%)", transform: `scale(${1 - 0.15 * press})`, opacity: 1 - fingerOut }} />
        )}
      </div>
    </div>
  );
  return <Scene clip={clip} cut={cut} dur={REF_DUR} push={[1, 1.05]} origin={[700, 760]} kicks={[TAP]} back={phone} />;
};

/* ---------------------------------------------------------- /reel-feed */
// An Instagram Reels feed, scrolled like a thumb does it: every swipe goes the same way (up).
// Each swipe comes sooner and faster than the last (exponential). Each swipe: the finger drags the page a quarter of the way while speeding up, lets go,
// and the page carries on at that speed and eases onto the next reel (velocity continuous
// at release, no overshoot), like iOS paging. Header, status bar and tab bar
// stay fixed; the reel's own UI (rail, caption, audio) travels with the reel.
const NAV = 150;
const PAGE = 1920 - NAV;
export const FEED_DUR = 92;
const DRAG = 4;
const GRAB = 0.3;
// after release the page keeps the finger's speed and eases out (cubic) onto the next reel
const SETTLE = (3 * (1 - GRAB)) / ((2 * GRAB) / DRAG);
// every swipe comes sooner and moves faster than the last, by the same ratio (exponential)
const RATIO = 0.68;
const SWIPES = Array.from({ length: 7 }, (_, i) => ({
  at: 4 + Array.from({ length: i }, (_, j) => 22 * RATIO ** j).reduce((a, b) => a + b, 0),
  speed: Math.max(0.8 * RATIO ** i, 3 / (DRAG + SETTLE)),
}));
const swipe = (t: number, speed: number) => {
  const d = DRAG * speed;
  if (t <= 0) return 0;
  if (t < d) return GRAB * (t / d) ** 2;
  const u = Math.min(1, (t - d) / (SETTLE * speed));
  return 1 - (1 - GRAB) * (1 - u) ** 3;
};
const feedPos = (f: number) => SWIPES.reduce((a, s) => a + swipe(f - s.at, s.speed), 0);

type Post = { fx?: string; user: string; pfp: string; cap: string; audio: string; likes: string; comments: string; reposts: string; shares: string; follow: boolean };
const POSTS: Post[] = [
  { user: "marcelgrauu", pfp: "pfp_me.jpg", cap: "One line in Claude and the reel edits itself", audio: "marcelgrauu · Original audio", likes: "48.2K", comments: "1,204", reposts: "3,118", shares: "9,870", follow: false },
  { fx: "liquid-glass-graph", user: "edit.lab", pfp: "art/a1.jpg", cap: "retention went from 19 to 68 with this", audio: "edit.lab · Original audio", likes: "12.4K", comments: "318", reposts: "902", shares: "2,410", follow: true },
  { fx: "glass-type", user: "motion.daily", pfp: "art/a2.jpg", cap: "3D type from one prompt, no After Effects", audio: "motion.daily · Original audio", likes: "88.1K", comments: "2,077", reposts: "5,630", shares: "14K", follow: true },
  { fx: "ui-world", user: "reel.school", pfp: "art/a3.jpg", cap: "stop editing by hand, seriously", audio: "reel.school · Original audio", likes: "6,932", comments: "141", reposts: "377", shares: "1,019", follow: true },
  { fx: "apple-ui-toggles", user: "cuts.by.ana", pfp: "art/a4.jpg", cap: "the 4 switches I flip before posting", audio: "cuts.by.ana · Original audio", likes: "23.7K", comments: "604", reposts: "1,480", shares: "3,302", follow: true },
  { fx: "orbit", user: "studio.ai", pfp: "art/a5.jpg", cap: "main character edit, one command", audio: "studio.ai · Original audio", likes: "31.9K", comments: "877", reposts: "2,214", shares: "6,045", follow: true },
  { fx: "match-cut", user: "ai.creator", pfp: "art/a6.jpg", cap: "this match cut took 0 minutes", audio: "ai.creator · Original audio", likes: "17.3K", comments: "452", reposts: "1,096", shares: "2,887", follow: true },
];
const FEED_ORDER = [0, 1, 2, 3, 4, 5, 6, 0];

const Ico: React.FC<{ d: string; size?: number; sw?: number }> = ({ d, size = 64, sw = 1.9 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth={sw} strokeLinejoin="round" strokeLinecap="round"><path d={d} /></svg>
);
const I = {
  heart: "M12 20.3s-7.4-4.5-9.2-9C1.6 8.2 3.5 5 6.8 5c2 0 3.6 1.1 5.2 3 1.6-1.9 3.2-3 5.2-3 3.3 0 5.2 3.2 4 6.3-1.8 4.5-9.2 9-9.2 9z",
  comment: "M20.66 17A9.99 9.99 0 1 0 17.07 20.62L22 22z",
  repost: "M4 12.5V9.5a3 3 0 0 1 3-3h12.5M16.5 3.5l3 3-3 3M20 11.5v3a3 3 0 0 1-3 3H4.5M7.5 20.5l-3-3 3-3",
  share: "M22 3L9.22 10.08M11.7 20.33L22 3H2l7.22 7.08z",
  camera: "M3 8.5A2.5 2.5 0 0 1 5.5 6h2l1.6-2h5.8l1.6 2h2A2.5 2.5 0 0 1 21 8.5v9a2.5 2.5 0 0 1-2.5 2.5h-13A2.5 2.5 0 0 1 3 17.5zM12 16.5a3.6 3.6 0 1 0 0-7.2 3.6 3.6 0 0 0 0 7.2z",
  home: "M3.5 10.2L12 3.5l8.5 6.7V20.5h-5.6v-6h-5.8v6H3.5z",
  search: "M10.5 18a7.5 7.5 0 1 0 0-15 7.5 7.5 0 0 0 0 15zM16 16l5 5",
  reels: "M3 7.5A4.5 4.5 0 0 1 7.5 3h9A4.5 4.5 0 0 1 21 7.5v9a4.5 4.5 0 0 1-4.5 4.5h-9A4.5 4.5 0 0 1 3 16.5zM3.5 8h17M9.5 3.2l2.6 4.8M15 3.2l2.6 4.8M10 11.3v6l5-3z",
  dm: "M12 2.8C6.8 2.8 2.8 6.6 2.8 11.6c0 2.6 1.1 4.9 2.9 6.5v3.1l2.8-1.6c1.1.3 2.3.5 3.5.5 5.2 0 9.2-3.8 9.2-8.5S17.2 2.8 12 2.8zM7 14l3.4-3.7 2.4 2 3.3-3.7",
};
const Rail: React.FC<{ p: Post }> = ({ p }) => (
  <div style={{ position: "absolute", right: 22, bottom: 40, width: 96, display: "flex", flexDirection: "column", alignItems: "center", gap: 30, fontFamily: SANS, fontWeight: 500, fontSize: 25, color: "#fff" }}>
    {([["heart", p.likes], ["comment", p.comments], ["repost", p.reposts], ["share", p.shares]] as const).map(([k, n]) => (
      <div key={k} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 6 }}><Ico d={I[k]} />{n}</div>
    ))}
    <svg width={48} height={20} viewBox="0 0 48 20"><circle cx="10" cy="10" r="4" fill="#fff" /><circle cx="24" cy="10" r="4" fill="#fff" /><circle cx="38" cy="10" r="4" fill="#fff" /></svg>
    <Img src={staticFile(p.pfp)} style={{ width: 62, height: 62, borderRadius: 12, border: "3px solid #fff", objectFit: "cover" }} />
  </div>
);
const PostPage: React.FC<{ p: Post; k: number; clip: ClipProps }> = ({ p, k, clip }) => {
  const f = useCurrentFrame();
  return (
    <div style={{ position: "absolute", left: 0, top: 0, width: 1080, height: PAGE, overflow: "hidden", background: "#000" }}>
      {p.fx ? <OffthreadVideo src={staticFile(`fx/${p.fx}.mp4`)} muted startFrom={20 + k * 7} style={{ position: "absolute", left: 0, top: -NAV / 2, width: 1080, height: 1920 }} /> : <div style={{ position: "absolute", left: 0, top: -NAV / 2, width: 1080, height: 1920 }}><Clip {...clip} /></div>}
      <div style={{ position: "absolute", left: 0, right: 0, bottom: 0, height: 620, background: "linear-gradient(180deg, transparent, rgba(0,0,0,0.62))" }} />
      <div style={{ position: "absolute", left: 0, right: 0, top: 0, height: 300, background: "linear-gradient(180deg, rgba(0,0,0,0.45), transparent)" }} />
      <Rail p={p} />
      <div style={{ position: "absolute", left: 34, right: 150, bottom: 52, fontFamily: SANS, color: "#fff" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 18, fontWeight: 700, fontSize: 31 }}>
          <Img src={staticFile(p.pfp)} style={{ width: 70, height: 70, borderRadius: 35, objectFit: "cover" }} />
          {p.user}
          {p.follow && <span style={{ border: "2px solid rgba(255,255,255,0.85)", borderRadius: 14, padding: "6px 20px", fontSize: 27, fontWeight: 600 }}>Follow</span>}
        </div>
        <div style={{ marginTop: 20, fontSize: 30, lineHeight: 1.3 }}>{p.cap} <span style={{ color: "rgba(255,255,255,0.7)" }}>… more</span></div>
        <div style={{ marginTop: 16, display: "flex", alignItems: "center", gap: 10, fontSize: 25, color: "rgba(255,255,255,0.92)" }}>
          <svg width={26} height={26} viewBox="0 0 24 24" fill="#fff"><path d="M9 18.5a3 3 0 1 1-2-2.8V5l12-2v12.5a3 3 0 1 1-2-2.8V7.2L9 8.6z" /></svg>{p.audio}
        </div>
      </div>
      {/* the thin playback line along the bottom of the reel */}
      <div style={{ position: "absolute", left: 0, bottom: 0, height: 4, width: 1080, background: "rgba(255,255,255,0.25)" }}>
        <div style={{ height: 4, width: (f * 6 + k * 170) % 1080, background: "#fff" }} />
      </div>
    </div>
  );
};
export const ReelFeed: React.FC<{ clip: ClipProps }> = ({ clip }) => {
  const f = useCurrentFrame();
  const pos = feedPos(f);
  const vel = (feedPos(f + 0.5) - feedPos(f - 0.5)) * PAGE;
  return (
    <AbsoluteFill style={{ background: "#000", overflow: "hidden" }}>
      <div style={{ position: "absolute", left: 0, top: 0, width: 1080, height: PAGE, overflow: "hidden" }}>
        <MotionBlur id="feed" vy={-vel} shutter={0.25} max={110}>
          <AbsoluteFill>
            {FEED_ORDER.map((pi, k) => {
              const y = (k - pos) * PAGE;
              if (y <= -PAGE || y >= PAGE) return null;
              return <div key={k} style={{ position: "absolute", left: 0, top: 0, width: 1080, height: PAGE, transform: `translateY(${y}px)` }}><PostPage p={POSTS[pi]} k={k} clip={clip} /></div>;
            })}
          </AbsoluteFill>
        </MotionBlur>
        {/* fixed chrome: status bar and the Reels header */}
        <div style={{ position: "absolute", left: 60, right: 52, top: 30, display: "flex", justifyContent: "space-between", alignItems: "center", fontFamily: SANS, fontWeight: 700, fontSize: 33, color: "#fff" }}>
          <span>9:41</span>
          <svg width={150} height={30} viewBox="0 0 150 30"><g fill="#fff"><rect x="0" y="18" width="6" height="10" rx="2" /><rect x="10" y="13" width="6" height="15" rx="2" /><rect x="20" y="8" width="6" height="20" rx="2" /><rect x="30" y="3" width="6" height="25" rx="2" /></g><path d="M54 12a17 17 0 0 1 24 0M58 17a11 11 0 0 1 16 0M62 22a5 5 0 0 1 8 0" stroke="#fff" strokeWidth="3.4" fill="none" strokeLinecap="round" /><rect x="94" y="4" width="46" height="22" rx="7" stroke="#fff" strokeOpacity="0.5" strokeWidth="2.4" fill="none" /><rect x="98" y="8" width="34" height="14" rx="4" fill="#fff" /><rect x="142" y="11" width="4" height="8" rx="2" fill="#fff" fillOpacity="0.5" /></svg>
        </div>
        <div style={{ position: "absolute", left: 40, right: 36, top: 104, display: "flex", justifyContent: "space-between", alignItems: "center", fontFamily: SANS, fontWeight: 700, fontSize: 46, color: "#fff" }}>
          <span style={{ display: "flex", alignItems: "center", gap: 10 }}>Reels<svg width={30} height={30} viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth={2.6} strokeLinecap="round" strokeLinejoin="round"><path d="M6 9l6 6 6-6" /></svg></span>
          <Ico d={I.camera} size={58} />
        </div>
      </div>
      {/* fixed tab bar */}
      <div style={{ position: "absolute", left: 0, right: 0, bottom: 0, height: NAV, background: "#000", display: "flex", justifyContent: "space-around", alignItems: "flex-start", paddingTop: 22 }}>
        <Ico d={I.home} size={60} />
        <Ico d={I.search} size={60} />
        <Ico d={I.reels} size={60} sw={2.4} />
        <Ico d={I.dm} size={60} />
        <Img src={staticFile("pfp_me.jpg")} style={{ width: 60, height: 60, borderRadius: 30, objectFit: "cover" }} />
        <div style={{ position: "absolute", left: 360, right: 360, bottom: 14, height: 10, borderRadius: 5, background: "#fff" }} />
      </div>
    </AbsoluteFill>
  );
};

/* ---------------------------------------------------------- /checklist */
const STEPS = ["Drop your clips", "Trigger the skill", "Post the reel"];
const AT = [20, 40, 60];
export const Checklist: React.FC<{ clip: ClipProps }> = ({ clip }) => {
  const f = useCurrentFrame();
  const enter = prog(f, 4, 20, EASE.out);
  const doneN = AT.filter((t) => f >= t + 12).length;
  const card = (
    <div style={{ position: "absolute", left: 70, right: 70, top: 200, borderRadius: 34, background: "rgba(22,22,24,0.86)", border: "1.5px solid rgba(255,255,255,0.12)", boxShadow: "0 30px 70px rgba(0,0,0,0.5)", padding: "26px 34px 18px", transform: `translateY(${(1 - enter) * -60}px) scale(${lerp(0.95, 1, enter)})`, opacity: enter }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div style={{ fontFamily: MONO, fontSize: 22, letterSpacing: 4, color: "rgba(255,255,255,0.7)" }}><span style={{ color: Y }}>●</span> ALL YOU NEED TO DO</div>
        <div style={{ padding: "6px 14px", borderRadius: 14, background: "rgba(255,255,255,0.1)", fontFamily: SANS, fontWeight: 700, fontSize: 24, color: "#fff", fontVariantNumeric: "tabular-nums" }}>{doneN} of 3</div>
      </div>
      <div style={{ height: 4, borderRadius: 2, background: "rgba(255,255,255,0.1)", margin: "18px 0 8px" }}><div style={{ height: "100%", width: `${(doneN / 3) * 100}%`, borderRadius: 2, background: Y, transition: "none" }} /></div>
      {STEPS.map((s, i) => {
        const t0 = AT[i];
        const n = Math.max(0, Math.min(s.length, Math.floor((f - t0) / 0.8)));
        const chk = prog(f, t0 + 10, t0 + 18, EASE.back);
        const glow = Math.max(0, 1 - Math.abs(f - t0 - 12) / 10);
        return (
          <div key={s} style={{ display: "flex", alignItems: "center", gap: 22, padding: "20px 0", borderTop: i ? "1px solid rgba(255,255,255,0.07)" : undefined }}>
            <div style={{ position: "relative", width: 50, height: 50, borderRadius: 25, border: `3px solid ${chk > 0.1 ? Y : "rgba(255,255,255,0.35)"}`, background: chk > 0.1 ? Y : "transparent", transform: `scale(${lerp(0.9, 1, chk)})`, boxShadow: glow > 0 ? `0 0 ${30 * glow}px rgba(255,229,0,${0.6 * glow})` : undefined, display: "grid", placeItems: "center" }}>
              {chk > 0.1 && <svg width={30} height={30} viewBox="0 0 24 24" fill="none" stroke="#111" strokeWidth={3.4} strokeLinecap="round" strokeLinejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5" pathLength={1} strokeDasharray={`${chk} 1`} /></svg>}
            </div>
            {f >= t0 ? (
              <div style={{ fontFamily: SANS, fontWeight: 700, fontSize: 42, letterSpacing: -0.8, color: chk > 0.5 ? Y : "#fff" }}>{s.slice(0, n)}</div>
            ) : (
              <div style={{ height: 14, width: 300 - i * 50, borderRadius: 7, background: "rgba(255,255,255,0.12)" }} />
            )}
          </div>
        );
      })}
    </div>
  );
  return <Scene clip={clip} dur={REF_DUR} push={[1, 1.05]} origin={[540, 500]} kicks={AT.map((t) => t + 12)} front={card} />;
};
