/**
 * /screen-push-digital — words on a macro LED wall. Each word lights up on the
 * matrix (RGB sub-pixels, bloom), then the camera flies through it and the
 * next word comes out of the depth. Canvas, drawn per frame, deterministic.
 */
import React, { useEffect, useLayoutEffect, useRef, useState } from "react";
import { AbsoluteFill, continueRender, delayRender, useCurrentFrame } from "remotion";
import { EXPO_OUT, EXPO_IN, p, hash } from "../kit";

export const SCREEN_PUSH_DIGITAL_DUR = 96;
const WORDS = ["20", "effects", "one", "command."];
const SEG = [0, 20, 42, 58]; // start frame of each word
const W = 1080;
const H = 1920;
const PITCH = 12; // led pitch in px: fine enough that a long word still reads

// sample a word into a lit-cell mask on the led grid
const masks = new Map<string, Float32Array>();
const maskOf = (word: string, cols: number, rows: number) => {
  const key = word + cols + "x" + rows;
  if (masks.has(key)) return masks.get(key)!;
  const c = document.createElement("canvas");
  c.width = cols;
  c.height = rows;
  const g = c.getContext("2d")!;
  g.fillStyle = "#000";
  g.fillRect(0, 0, cols, rows);
  g.fillStyle = "#fff";
  g.textAlign = "center";
  g.textBaseline = "middle";
  let fs = rows * 0.84;
  g.font = `900 ${fs}px HN, sans-serif`;
  const w = g.measureText(word).width;
  if (w > cols * 0.96) {
    fs *= (cols * 0.96) / w;
    g.font = `900 ${fs}px HN, sans-serif`;
  }
  g.fillText(word, cols / 2, rows / 2 + fs * 0.04);
  const d = g.getImageData(0, 0, cols, rows).data;
  const m = new Float32Array(cols * rows);
  for (let i = 0; i < m.length; i++) m[i] = d[i * 4] / 255;
  masks.set(key, m);
  return m;
};

export const ScreenPushDigital: React.FC = () => {
  const f = useCurrentFrame();
  const ref = useRef<HTMLCanvasElement>(null);
  const bloomRef = useRef<HTMLCanvasElement>(null);
  const dofRef = useRef<HTMLCanvasElement>(null);
  const [handle] = useState(() => delayRender("led font"));
  const [ready, setReady] = useState(false);
  useEffect(() => {
    (document as any).fonts.load('900 100px "HN"').then(() => {
      setReady(true);
      continueRender(handle);
    });
  }, [handle]);

  useLayoutEffect(() => {
    if (!ready) return;
    const cv = ref.current!;
    const ctx = cv.getContext("2d")!;
    ctx.fillStyle = "#050505";
    ctx.fillRect(0, 0, W, H);

    // which word, and the fly-through
    let wi = 0;
    for (let i = 0; i < SEG.length; i++) if (f >= SEG[i]) wi = i;
    const start = SEG[wi];
    const end = wi < SEG.length - 1 ? SEG[wi + 1] : 9999;
    const inT = p(f, start, start + 9, EXPO_OUT); // word comes out of depth
    const outT = wi < SEG.length - 1 ? p(f, end - 7, end + 1, EXPO_IN) : 0; // camera pushes through
    const scale = (0.55 + 0.45 * inT) * (1 + outT * 4.5) * (1 + 0.04 * p(f, start, end, (x) => x));
    const bright = inT * (1 - outT * 0.9);

    const cols = Math.ceil(W / PITCH);
    const rows = Math.ceil(H / PITCH);
    const wcols = 84;
    const wrows = 28;
    const m = maskOf(WORDS[wi], wcols, wrows);
    // ticker bands (dim amber) above and below: the wall is a real sign, not one floating word
    const TK = "CLAUDE COMMANDS  ·  64 EFFECTS  ·  ONE LINE EACH  ·  ";
    const tcols = 520;
    const trows = 9;
    const tm = maskOf(TK + TK, tcols, trows);
    const tick = (f * 0.7) % (tcols / 2);

    // flicker and scan line
    const scanY = ((f * 41) % (rows + 40)) - 20;
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const x = c * PITCH;
        const y = r * PITCH;
        // map screen cell to word space (centred, scaled)
        const u = ((x - W / 2) / scale) / PITCH + wcols / 2;
        const v = ((y - H / 2) / scale) / PITCH + wrows / 2;
        let lit = 0;
        if (u >= 0 && v >= 0 && u < wcols && v < wrows) lit = m[(v | 0) * wcols + (u | 0)];
        let amber = 0;
        const band = r >= 30 && r < 30 + trows ? r - 30 : r >= rows - 40 && r < rows - 40 + trows ? r - (rows - 40) : -1;
        if (band >= 0) {
          const tu = Math.floor(c + tick + (r > rows / 2 ? 130 : 0)) % tcols;
          amber = tm[band * tcols + tu] * 0.5 * p(f, 4, 16);
        }
        const n = hash(c * 7 + r * 131, 5);
        const flick = 0.86 + 0.14 * Math.sin(f * 0.9 + n * 40);
        const scan = Math.abs(r - scanY) < 2 ? 0.25 : 0;
        const a = Math.min(1, lit * bright * flick + scan * lit);
        // unlit sub-pixels are faintly visible
        const base = 0.07 + 0.03 * n;
        const R = base + a * 1.0;
        const G = base + a * 0.92;
        const B = base + a * 0.78;
        const sw = PITCH / 3 - 1.2;
        const sh = PITCH - 3;
        ctx.fillStyle = `rgba(255,60,50,${Math.min(1, R)})`;
        ctx.fillRect(x + 1, y + 2, sw, sh);
        ctx.fillStyle = `rgba(70,255,90,${Math.min(1, G)})`;
        ctx.fillRect(x + 1 + PITCH / 3, y + 2, sw, sh);
        ctx.fillStyle = `rgba(70,120,255,${Math.min(1, B)})`;
        ctx.fillRect(x + 1 + (2 * PITCH) / 3, y + 2, sw, sh);
        if (a > 0.02) {
          ctx.fillStyle = `rgba(255,250,235,${a * 0.42})`;
          ctx.fillRect(x + 1, y + 2, PITCH - 2, sh);
        }
        if (amber > 0.02) {
          ctx.fillStyle = `rgba(255,176,40,${amber})`;
          ctx.fillRect(x + 1, y + 2, PITCH - 2, sh);
        }
      }
    }
    // bloom
    const b = bloomRef.current!;
    const bg = b.getContext("2d")!;
    bg.clearRect(0, 0, W / 4, H / 4);
    bg.filter = "blur(6px)";
    bg.drawImage(cv, 0, 0, W / 4, H / 4);
    bg.filter = "blur(18px)";
    bg.globalAlpha = 0.8;
    bg.drawImage(cv, 0, 0, W / 4, H / 4);
    bg.globalAlpha = 1;
    bg.filter = "none";
    const dof = dofRef.current!.getContext("2d")!;
    dof.clearRect(0, 0, W / 2, H / 2);
    dof.filter = "blur(5px)";
    dof.drawImage(cv, 0, 0, W / 2, H / 2);
    dof.filter = "none";
  }, [f, ready]);

  // camera drift
  const drift = Math.sin(f / 26) * 6;
  return (
    <AbsoluteFill style={{ background: "#050505", overflow: "hidden" }}>
      <div style={{ position: "absolute", inset: 0, perspective: 1400 }}>
        <div style={{ position: "absolute", inset: -40, transform: `translate(${drift}px, ${drift * 0.5}px) rotateX(9deg) rotateY(-11deg) rotateZ(${-1.2 + Math.sin(f / 40) * 0.4}deg) scale(1.12)` }}>
          <canvas ref={ref} width={W} height={H} style={{ position: "absolute", left: 40, top: 40, width: W, height: H }} />
          <canvas ref={dofRef} width={W / 2} height={H / 2} style={{ position: "absolute", left: 40, top: 40, width: W, height: H, WebkitMaskImage: "linear-gradient(to bottom, #000 0%, transparent 32%, transparent 62%, #000 100%)", maskImage: "linear-gradient(to bottom, #000 0%, transparent 32%, transparent 62%, #000 100%)" }} />
          <canvas ref={bloomRef} width={W / 4} height={H / 4} style={{ position: "absolute", left: 40, top: 40, width: W, height: H, mixBlendMode: "screen", opacity: 1 }} />
        </div>
      </div>
      {/* lens: vignette + slight top/bottom defocus band */}
      <AbsoluteFill style={{ background: "radial-gradient(ellipse 80% 60% at 50% 50%, transparent 50%, rgba(0,0,0,0.65) 100%)" }} />
    </AbsoluteFill>
  );
};
