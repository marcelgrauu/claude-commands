/**
 * /ui-world — Claude's interface becomes the room. A huge window unfolds in 3D
 * above and behind your head (your cap overlaps its bottom edge), it spills warm
 * light down on you, your raw clips fly up from the desk in arcs and drop into the
 * composer, the prompt types itself, send pulses, and the edit starts rendering.
 *   0-22   window unfolds (rotateX from 70 to 9), light spill grows, camera tilts up
 *   20-48  four clips fly in, one by one, each lands with a small bounce
 *   50-66  "Turn these into a reel" types, tag pops
 *   68     send: button pulse + camera kick
 *   70-100 "Editing…" shimmer and a render bar fills under a preview frame
 */
import React from "react";
import { AbsoluteFill, Img, interpolate, staticFile, useCurrentFrame } from "remotion";
import { EXPO_OUT, BACK_OUT, QUINT_INOUT, SOFT, p, arc } from "../kit";
import { ClipProps, Scene, SANS, TIGHT, MONO, Y } from "./common";
import { Asterisk } from "../ui/ClaudePhone";

export const UIWORLD_DUR = 104;

const WX = 60;
const WY = 170;
const WW = 960;
const WH = 600;
const SLOT_Y = WY + 220;
const SLOT_X = (i: number) => WX + 70 + i * 150;
const TW = 128;
const TH = 172;
const LAND = [24, 31, 38, 45];
const SEND = 68;

export const UiWorld: React.FC<{ clip: ClipProps; cut: ClipProps; thumbs: string[] }> = ({ clip, cut, thumbs }) => {
  const f = useCurrentFrame();
  const unfold = p(f, 2, 24, EXPO_OUT);
  const ask = "Turn these into a reel";
  const typed = Math.max(0, Math.min(ask.length, Math.floor((f - 50) / 0.7)));
  const tag = p(f, 48, 58, BACK_OUT);
  const send = p(f, SEND, SEND + 8, (x) => x);
  const editing = p(f, SEND + 2, SEND + 12, EXPO_OUT);
  const bar = p(f, SEND + 6, 100, QUINT_INOUT);
  const light = unfold * 0.9;

  const win = (
    <div style={{ position: "absolute", inset: 0, perspective: 1400, perspectiveOrigin: "540px 1100px" }}>
      <div style={{ position: "absolute", left: WX, top: WY, width: WW, height: WH, transformOrigin: `50% 100%`, transform: `rotateX(${(1 - unfold) * 70 + 9}deg) scale(${0.9 + 0.1 * unfold})`, opacity: Math.min(1, unfold * 1.6) }}>
        {/* glow behind the panel */}
        <div style={{ position: "absolute", inset: -60, borderRadius: 90, background: "radial-gradient(ellipse at 50% 60%, rgba(255,236,200,0.55), transparent 70%)", filter: "blur(30px)" }} />
        <div style={{ position: "absolute", inset: 0, borderRadius: 54, background: "linear-gradient(180deg,#FBFAF6,#F1EEE6)", boxShadow: "0 40px 90px rgba(0,0,0,0.5), inset 0 2px 0 #fff, inset 0 -2px 0 rgba(0,0,0,0.05)", overflow: "hidden" }}>
          {/* title bar */}
          <div style={{ position: "absolute", left: 30, top: 28, display: "flex", gap: 12 }}>
            {["#FF5F57", "#FEBC2E", "#28C840"].map((c) => <div key={c} style={{ width: 20, height: 20, borderRadius: 10, background: c }} />)}
          </div>
          <div style={{ position: "absolute", left: 0, right: 0, top: 60, display: "flex", justifyContent: "center", alignItems: "center", gap: 16 }}>
            <Asterisk size={56} rot={f * 2.5} />
            <div style={{ fontFamily: "AG, serif", fontSize: 60, color: "#1F1E1B", letterSpacing: -1 }}>Claude</div>
          </div>
          {/* composer */}
          <div style={{ position: "absolute", left: 40, right: 40, top: 160, height: 400, borderRadius: 40, background: "#fff", border: "1.5px solid #E4DFD2", boxShadow: "0 12px 30px rgba(0,0,0,0.07)" }}>
            {thumbs.map((t, i) => {
              const landed = f >= LAND[i];
              const b = p(f, LAND[i], LAND[i] + 8, BACK_OUT);
              return landed ? (
                <div key={i} style={{ position: "absolute", left: 30 + i * 150, top: 60, width: TW, height: TH, borderRadius: 20, overflow: "hidden", transform: `translateY(${(1 - b) * -26}px) scale(${0.92 + 0.08 * b})`, boxShadow: "0 10px 22px rgba(0,0,0,0.18)" }}>
                  <Img src={staticFile(t)} style={{ width: TW, height: TH, objectFit: "cover" }} />
                </div>
              ) : null;
            })}
            <div style={{ position: "absolute", left: 640, top: 150, opacity: tag, transform: `translateY(${(1 - tag) * 10}px)`, fontFamily: SANS, fontWeight: 500, fontSize: 28, color: "#8A867C", whiteSpace: "nowrap" }}>4 clips · 0:48</div>
            <div style={{ position: "absolute", left: 34, top: 262, fontFamily: SANS, fontSize: 38, color: typed ? "#1F1E1B" : "#A29E93", whiteSpace: "nowrap", display: "flex", alignItems: "center" }}>
              {typed ? ask.slice(0, typed) : "What should we edit today?"}
              {f > 48 && f < SEND && Math.floor(f / 6) % 2 === 0 && <span style={{ width: 3, height: 44, background: "#D97757", marginLeft: 3, display: "inline-block" }} />}
            </div>
            {/* editing state */}
            <div style={{ position: "absolute", left: 34, right: 130, top: 330, display: "flex", alignItems: "center", gap: 14, opacity: editing }}>
              <Asterisk size={30} rot={f * 9} />
              <div style={{ fontFamily: SANS, fontWeight: 600, fontSize: 26, color: "#6E6A60" }}>Editing your reel…</div>
              <div style={{ flex: 1, height: 10, borderRadius: 5, background: "#EEEAE0", overflow: "hidden" }}><div style={{ width: `${bar * 100}%`, height: "100%", background: `linear-gradient(90deg, #D97757, ${Y})` }} /></div>
              <div style={{ fontFamily: MONO, fontSize: 22, color: "#6E6A60", width: 64, textAlign: "right" }}>{Math.round(bar * 100)}%</div>
            </div>
            <div style={{ position: "absolute", right: 28, bottom: 26, width: 84, height: 84, borderRadius: 24, background: "#C6613F", display: "grid", placeItems: "center", transform: `scale(${1 - 0.14 * Math.sin(send * Math.PI)})`, boxShadow: `0 0 0 ${send > 0 && send < 1 ? 16 * send : 0}px rgba(198,97,63,${0.35 * (1 - send)})` }}>
              <svg width={40} height={40} viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth={2.4} strokeLinecap="round" strokeLinejoin="round"><path d="M12 19V5M6 11l6-6 6 6" /></svg>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  // clips flying up from the desk, in front of you, until they land
  const flying = thumbs.map((t, i) => {
    const start = LAND[i] - 12;
    if (f < start || f >= LAND[i]) return null;
    const u = p(f, start, LAND[i], QUINT_INOUT);
    const [x, y] = arc(u, [300 + i * 160, 1480], [SLOT_X(i) + 24, SLOT_Y + 86], i % 2 ? 0.35 : -0.35);
    const s = 1.5 - 0.55 * u;
    return (
      <div key={i} style={{ position: "absolute", left: x - (TW * s) / 2, top: y - (TH * s) / 2, width: TW * s, height: TH * s, borderRadius: 20, overflow: "hidden", transform: `rotate(${(1 - u) * (i % 2 ? 24 : -24)}deg)`, boxShadow: "0 24px 50px rgba(0,0,0,0.5)", border: "3px solid #fff" }}>
        <Img src={staticFile(t)} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
      </div>
    );
  });

  // warm light the window spills on the scene
  const spill = (
    <AbsoluteFill style={{ background: "linear-gradient(180deg, rgba(255,232,190,0.55) 0%, rgba(255,232,190,0.18) 40%, transparent 62%)", mixBlendMode: "soft-light", opacity: light }} />
  );

  const tilt = interpolate(f, [0, 24, 90, UIWORLD_DUR], [0, 1, 1, 0.8], { easing: SOFT, extrapolateRight: "clamp" });
  return (
    <Scene
      clip={clip}
      cut={cut}
      dur={UIWORLD_DUR}
      push={[1.02, 1.07]}
      origin={[540, 900 - 260 * tilt]}
      kicks={[SEND]}
      back={win}
      front={<>{spill}{flying}</>}
    />
  );
};
