/**
 * Shared pieces for the effects.
 *  - Clip: the avatar clip, cover 1080x1920, muted.
 *  - Cutout: the same clip with alpha (ProRes 4444 from alpha-cutout), for "behind the person" layers.
 *  - GlassPane: real liquid glass. Inside the pane we draw the same clip again,
 *    magnified around the pane centre, blurred and lifted, so the glass refracts
 *    what is actually behind it (backdrop-filter is unreliable with 3D in the renderer).
 */
import React from "react";
import { AbsoluteFill, Easing, OffthreadVideo, Img, interpolate, staticFile, useCurrentFrame } from "remotion";

export type ClipProps = { src: string; startFrom?: number; rate?: number };

// The talking clips live as 30 fps image sequences (plate jpg + alpha webp), not videos:
// frame exact, safe inside CameraMotionBlur, no 24 fps seek errors. `clips/talkN.mp4` maps to them.
const SEQ: Record<string, number> = { talk1: 240, talk2: 180, talk3: 180 };
const seqOf = (src: string) => {
  const m = src.match(/clips\/(talk\d)(-alpha)?\.(mp4|mov)$/);
  return m && SEQ[m[1]] ? m[1] : null;
};
/** frame of the sequence: plays forward, and if it would run out it rocks back (never freezes). */
const seqFrame = (f: number, start: number, len: number) => {
  const t = Math.round(start + f);
  const period = 2 * (len - 1);
  const k = ((t % period) + period) % period;
  return (k < len ? k : period - k) + 1;
};
const pad = (n: number) => String(n).padStart(3, "0");

export const Clip: React.FC<ClipProps & { style?: React.CSSProperties }> = ({ src, startFrom = 0, rate = 1, style }) => {
  const f = useCurrentFrame();
  const seq = seqOf(src);
  const isImg = /\.(jpe?g|png)$/i.test(src);
  return (
    <AbsoluteFill style={style}>
      {seq ? (
        <Img src={staticFile(`seq/${seq}/plate/${pad(seqFrame(f * rate, startFrom, SEQ[seq]))}.jpg`)} style={{ width: 1080, height: 1920, objectFit: "cover" }} />
      ) : isImg ? (
        <Img src={staticFile(src)} style={{ width: 1080, height: 1920, objectFit: "cover" }} />
      ) : (
        <OffthreadVideo src={staticFile(src)} muted startFrom={startFrom} playbackRate={rate} style={{ width: 1080, height: 1920, objectFit: "cover" }} />
      )}
    </AbsoluteFill>
  );
};

export const Cutout: React.FC<ClipProps> = ({ src, startFrom = 0, rate = 1 }) => {
  const f = useCurrentFrame();
  const seq = seqOf(src);
  const isImg = /\.(png|webp)$/i.test(src);
  return (
    <AbsoluteFill>
      {seq ? (
        <Img src={staticFile(`seq/${seq}/cut/${pad(seqFrame(f * rate, startFrom, SEQ[seq]))}.webp`)} style={{ width: 1080, height: 1920, objectFit: "cover" }} />
      ) : isImg ? (
        <Img src={staticFile(src)} style={{ width: 1080, height: 1920, objectFit: "cover" }} />
      ) : (
        <OffthreadVideo src={staticFile(src)} muted transparent startFrom={startFrom} playbackRate={rate} style={{ width: 1080, height: 1920, objectFit: "cover" }} />
      )}
    </AbsoluteFill>
  );
};

export const GlassPane: React.FC<{
  x: number; y: number; w: number; h: number; r?: number;
  clip: ClipProps;
  blur?: number; mag?: number; lift?: number; tint?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}> = ({ x, y, w, h, r = 48, clip, blur = 16, mag = 1.07, lift = 1.12, tint = "rgba(255,255,255,0.10)", style, children }) => (
  <div style={{ position: "absolute", left: x, top: y, width: w, height: h, ...style }}>
    {/* refraction */}
    <div style={{ position: "absolute", inset: 0, borderRadius: r, overflow: "hidden" }}>
      <div style={{ position: "absolute", left: -x, top: -y, width: 1080, height: 1920, transform: `scale(${mag})`, transformOrigin: `${x + w / 2}px ${y + h / 2}px` }}>
        <div style={{ position: "absolute", inset: 0, filter: `blur(${blur}px) brightness(${lift}) saturate(1.25)` }}>
          <Clip {...clip} />
        </div>
      </div>
      {/* thick edge: the rim bends the scene harder than the centre, like a real slab */}
      {[
        "linear-gradient(to right, #000 0%, transparent 7%, transparent 93%, #000 100%)",
        "linear-gradient(to bottom, #000 0%, transparent 9%, transparent 91%, #000 100%)",
      ].map((m, k) => (
        <div key={k} style={{ position: "absolute", inset: 0, WebkitMaskImage: m, maskImage: m }}>
          <div style={{ position: "absolute", left: -x, top: -y, width: 1080, height: 1920, transform: `scale(${mag + 0.16})`, transformOrigin: `${x + w / 2}px ${y + h / 2}px` }}>
            <div style={{ position: "absolute", inset: 0, filter: `blur(${Math.max(2, blur * 0.35)}px) brightness(${lift * 1.12}) saturate(1.4)` }}>
              <Clip {...clip} />
            </div>
          </div>
        </div>
      ))}
      <div style={{ position: "absolute", inset: 0, background: `linear-gradient(160deg, rgba(255,255,255,0.20) 0%, ${tint} 38%, rgba(255,255,255,0.03) 70%, rgba(255,255,255,0.10) 100%)` }} />
      {/* inner edge light: thicker at the top-left, like a real slab */}
      <div style={{ position: "absolute", inset: 0, borderRadius: r, boxShadow: "inset 0 2px 0 rgba(255,255,255,0.55), inset 2px 0 0 rgba(255,255,255,0.18), inset 0 -2px 0 rgba(255,255,255,0.10), inset 0 0 40px rgba(255,255,255,0.08)" }} />
      <div style={{ position: "absolute", left: 0, right: 0, top: 0, height: 2, background: "linear-gradient(90deg, transparent 5%, rgba(255,255,255,0.95) 45%, transparent 90%)" }} />
    </div>
    <div style={{ position: "absolute", inset: 0, borderRadius: r, border: "1.5px solid rgba(255,255,255,0.28)", boxShadow: "0 30px 80px rgba(0,0,0,0.45), 0 6px 18px rgba(0,0,0,0.25)" }} />
    <div style={{ position: "absolute", inset: 0 }}>{children}</div>
  </div>
);

/** light sweep across a pane, 0..1 progress */
export const Sweep: React.FC<{ t: number; r?: number; opacity?: number }> = ({ t, r = 48, opacity = 0.35 }) => (
  <div style={{ position: "absolute", inset: 0, borderRadius: r, overflow: "hidden", pointerEvents: "none" }}>
    <div style={{ position: "absolute", top: -40, bottom: -40, width: "40%", left: `${-50 + t * 170}%`, transform: "skewX(-18deg)", background: `linear-gradient(90deg, transparent, rgba(255,255,255,${opacity}), transparent)` }} />
  </div>
);

export const Y = "#FFE500";
// Marcel's type: Helvetica Neue for everything, Apple Garamond for the one editorial accent.
export { SANS, SERIF, MONO } from "../kit/fonts";
import { SANS as HN } from "../kit/fonts";
export const TIGHT = HN;

/**
 * Scene: the shared shot every effect sits in.
 *  - camera: slow push between `push`, micro drift, plus a short kick at every frame in `kicks`
 *  - focus: 0..1, pulls focus off the clip (slight blur + dim) while the graphic is the subject
 *  - back: layers between the clip and the cutout (they go BEHIND the person)
 *  - front: layers over everything that still move with the camera
 *  - hud: layers that do not move with the camera
 *  - grain + soft vignette on top so every effect shares one film look
 */
export const Scene: React.FC<{
  clip: ClipProps;
  cut?: ClipProps;
  dur: number;
  push?: [number, number];
  origin?: [number, number];
  kicks?: number[];
  focus?: number;
  back?: React.ReactNode;
  front?: React.ReactNode;
  hud?: React.ReactNode;
}> = ({ clip, cut, dur, push = [1, 1.06], origin = [540, 860], kicks = [], focus = 0, back, front, hud }) => {
  const f = useCurrentFrame();
  const s = interpolate(f, [0, dur], push, { extrapolateRight: "clamp", easing: Easing.bezier(0.45, 0, 0.55, 1) });
  const k = kicks.reduce((a, at) => a + 0.035 * Math.max(0, 1 - Math.abs(f - at - 1) / 6) * (f >= at ? 1 : 0.3), 0);
  const dx = Math.sin(f / 47) * 5;
  const dy = Math.cos(f / 53) * 4;
  const dr = Math.sin(f / 61) * 0.18;
  return (
    <AbsoluteFill style={{ background: "#000", overflow: "hidden" }}>
      <AbsoluteFill style={{ transformOrigin: `${origin[0]}px ${origin[1]}px`, transform: `translate(${dx}px, ${dy}px) rotate(${dr}deg) scale(${s * (1 + k)})` }}>
        <AbsoluteFill style={{ filter: focus > 0.01 ? `blur(${focus * 2.6}px) brightness(${1 - focus * 0.2})` : undefined }}>
          <Clip {...clip} />
        </AbsoluteFill>
        {back}
        {cut && (
          <AbsoluteFill style={{ filter: focus > 0.01 ? `brightness(${1 - focus * 0.12})` : undefined }}>
            <Cutout {...cut} />
          </AbsoluteFill>
        )}
        {front}
      </AbsoluteFill>
      {hud}
      <AbsoluteFill style={{ background: "radial-gradient(ellipse 85% 65% at 50% 45%, transparent 55%, rgba(0,0,0,0.38) 100%)", pointerEvents: "none" }} />
      <FilmGrain />
    </AbsoluteFill>
  );
};

export const FilmGrain: React.FC<{ opacity?: number }> = ({ opacity = 0.06 }) => {
  const f = useCurrentFrame();
  const seed = Math.floor(f / 2) % 24;
  return (
    <AbsoluteFill style={{ pointerEvents: "none", mixBlendMode: "overlay", opacity }}>
      <svg width="100%" height="100%">
        <filter id={`fg${seed}`}>
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves={2} seed={seed} stitchTiles="stitch" />
          <feColorMatrix type="saturate" values="0" />
        </filter>
        <rect width="100%" height="100%" filter={`url(#fg${seed})`} />
      </svg>
    </AbsoluteFill>
  );
};

/**
 * An effect shown as a small playing tile: stills (tiles/<id>/01..18.jpg, 7.5 fps)
 * that change every 4 frames. Accepts "fxs/<id>.mp4", "fx/<id>.mp4" or a bare id.
 */
export const Tile: React.FC<{ src: string; w: number; h: number; offset?: number; style?: React.CSSProperties }> = ({ src, w, h, offset = 0, style }) => {
  const f = useCurrentFrame();
  const id = src.replace(/^.*\//, "").replace(/\.mp4$/, "");
  const n = ((((Math.floor((f + offset) / 4)) % 18) + 18) % 18) + 1;
  return <Img src={staticFile(`tiles/${id}/${String(n).padStart(2, "0")}.jpg`)} style={{ width: w, height: h, objectFit: "cover", display: "block", ...style }} />;
};
