/**
 * Pro motion kit for the Fish Audio inserts.
 *
 * Rules every primitive here follows:
 *  - Frame-driven and deterministic. No Math.random, no state.
 *  - A transform and a filter never live on the same element: the wrapper
 *    moves, the inner node blurs/glows. Together they export as a broken
 *    white box in headless Chrome.
 *  - Nothing fades the whole frame out at the end. The last frame holds.
 */
import React from "react";
import { AbsoluteFill, Easing, Sequence, interpolate, useCurrentFrame } from "remotion";
import { CameraMotionBlur } from "@remotion/motion-blur";

/* ------------------------------------------------------------------ easing */

export const EXPO_OUT = Easing.bezier(0.16, 1, 0.3, 1);
export const EXPO_IN = Easing.bezier(0.7, 0, 0.84, 0);
export const QUINT_INOUT = Easing.bezier(0.83, 0, 0.17, 1);
export const BACK_OUT = Easing.bezier(0.34, 1.56, 0.64, 1);
export const SOFT = Easing.bezier(0.45, 0, 0.55, 1);

/** 0..1 progress between two frames, clamped, eased. */
export const p = (
  frame: number,
  from: number,
  to: number,
  ease: (t: number) => number = EXPO_OUT
) =>
  interpolate(frame, [from, to], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
    easing: ease,
  });

export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

/** Deterministic hash in [0,1). */
export const hash = (i: number, s = 1) => {
  const x = Math.sin(i * 12.9898 + s * 78.233) * 43758.5453;
  return x - Math.floor(x);
};

/* ------------------------------------------------------------------ fonts */

export const SANS = "Inter, Helvetica, Arial, sans-serif";
export const MONO = "'JetBrains Mono', 'SF Mono', Consolas, monospace";
export const INK = "#0A0A14";

/* ------------------------------------------------------------- stage / bg */

/**
 * White stage with a slow drifting light field in the accent, a soft top
 * light and a paper grain. Never flat white.
 */
export const Stage: React.FC<{
  accent: string;
  rgba: (a: number) => string;
  intensity?: number;
  children?: React.ReactNode;
}> = ({ rgba, intensity = 1, children }) => {
  const f = useCurrentFrame();
  const blob = (ph: number, x: number, y: number, s: number, a: number) => {
    const t = (f + ph) / 70;
    return {
      position: "absolute" as const,
      left: x + Math.sin(t) * 90,
      top: y + Math.cos(t * 0.8) * 70,
      width: s,
      height: s,
      borderRadius: "50%",
      background: `radial-gradient(circle, ${rgba(a * intensity)} 0%, ${rgba(0)} 68%)`,
      filter: "blur(30px)",
    };
  };
  return (
    <AbsoluteFill style={{ backgroundColor: "#FFFFFF", overflow: "hidden" }}>
      <div style={blob(0, -260, 40, 1000, 0.2)} />
      <div style={blob(160, 420, 1100, 900, 0.16)} />
      <div style={blob(80, 160, 560, 760, 0.09)} />
      <AbsoluteFill
        style={{
          background:
            "radial-gradient(120% 60% at 50% -10%, rgba(255,255,255,0.9) 0%, rgba(255,255,255,0) 60%)",
        }}
      />
      {children}
      <Grain />
    </AbsoluteFill>
  );
};

/** Paper grain. Seed steps every 2 frames so it shimmers like film, not TV snow. */
export const Grain: React.FC<{ opacity?: number }> = ({ opacity = 0.07 }) => {
  const f = useCurrentFrame();
  const seed = Math.floor(f / 2) % 50;
  return (
    <AbsoluteFill style={{ pointerEvents: "none", mixBlendMode: "multiply", opacity }}>
      <svg width="100%" height="100%">
        <filter id={`g${seed}`}>
          <feTurbulence type="fractalNoise" baseFrequency="0.85" numOctaves={2} seed={seed} stitchTiles="stitch" />
          <feColorMatrix type="saturate" values="0" />
        </filter>
        <rect width="100%" height="100%" filter={`url(#g${seed})`} />
      </svg>
    </AbsoluteFill>
  );
};

/* ----------------------------------------------------------- motion blur */

/**
 * Real accumulated motion blur, but only inside a window of frames.
 * CameraMotionBlur averages N renders at 1/N opacity each, and in 8-bit that
 * quantizes soft gradients into visible bands. So it is reserved for the fast
 * moves; everything else renders plain. Nested negative Sequences keep the
 * children on absolute time in every branch.
 */
export const BlurWindow: React.FC<{
  from: number;
  to: number;
  samples?: number;
  children: React.ReactNode;
}> = ({ from, to, samples = 6, children }) => (
  <>
    {from > 0 ? <Sequence from={0} durationInFrames={from}>{children}</Sequence> : null}
    <Sequence from={from} durationInFrames={to - from}>
      <Sequence from={-from}>
        <CameraMotionBlur samples={samples} shutterAngle={180}>
          {children}
        </CameraMotionBlur>
      </Sequence>
    </Sequence>
    <Sequence from={to}>
      <Sequence from={-to}>{children}</Sequence>
    </Sequence>
  </>
);

/** Same as BlurWindow, for several fast moves in one piece. Windows sorted, not overlapping. */
export const BlurWindows: React.FC<{
  windows: [number, number][];
  total: number;
  samples?: number;
  children: React.ReactNode;
}> = ({ windows, total, samples = 6, children }) => {
  const segs: { from: number; to: number; blur: boolean }[] = [];
  let cur = 0;
  windows.forEach(([a, b]) => {
    if (a > cur) segs.push({ from: cur, to: a, blur: false });
    segs.push({ from: a, to: b, blur: true });
    cur = b;
  });
  if (cur < total) segs.push({ from: cur, to: total, blur: false });
  return (
    <>
      {segs.map((s, i) => (
        <Sequence key={i} from={s.from} durationInFrames={s.to - s.from}>
          <Sequence from={-s.from}>
            {s.blur ? (
              <CameraMotionBlur samples={samples} shutterAngle={180}>
                {children}
              </CameraMotionBlur>
            ) : (
              children
            )}
          </Sequence>
        </Sequence>
      ))}
    </>
  );
};

/* ------------------------------------------------------------------ camera */

/**
 * Virtual camera over the whole scene: push, pan, roll, plus a micro drift
 * so the frame is never dead still. Origin is the focal point in px.
 */
export const Camera: React.FC<{
  scale?: number;
  x?: number;
  y?: number;
  rotate?: number;
  originX?: number;
  originY?: number;
  drift?: number;
  children: React.ReactNode;
}> = ({ scale = 1, x = 0, y = 0, rotate = 0, originX = 540, originY = 960, drift = 1, children }) => {
  const f = useCurrentFrame();
  const dx = Math.sin(f / 47) * 6 * drift;
  const dy = Math.cos(f / 53) * 5 * drift;
  const dr = Math.sin(f / 61) * 0.25 * drift;
  return (
    <AbsoluteFill
      style={{
        transformOrigin: `${originX}px ${originY}px`,
        transform: `translate(${x + dx}px, ${y + dy}px) rotate(${rotate + dr}deg) scale(${scale})`,
      }}
    >
      {children}
    </AbsoluteFill>
  );
};

/** Accent glow as a function of strength, so it can fade in after a mask lifts. */
export const glowOf = (rgba: (a: number) => string) => (a: number) =>
  a <= 0.001 ? "none" : `0 0 26px ${rgba(0.42 * a)}, 0 0 62px ${rgba(0.2 * a)}`;

/* ------------------------------------------------------- kinetic typography */

type Unit = "char" | "word";

/**
 * Text that rises out of a mask, unit by unit, with a resolving blur and a
 * small tilt. Each unit: outer mask (overflow hidden) > mover (transform) >
 * glyph (filter). Never transform and filter on one node.
 */
export const Rise: React.FC<{
  text: string;
  at: number;
  unit?: Unit;
  stagger?: number;
  dur?: number;
  style?: React.CSSProperties;
  glyphStyle?: React.CSSProperties;
  blur?: number;
  from?: number;
  tilt?: number;
  mask?: boolean;
  glow?: (a: number) => string;
}> = ({
  text,
  at,
  unit = "char",
  stagger = 2,
  dur = 22,
  style,
  glyphStyle,
  blur = 14,
  from = 110,
  tilt = 6,
  mask = true,
  glow,
}) => {
  const f = useCurrentFrame();
  const parts = unit === "char" ? Array.from(text) : text.split(/(\s+)/);
  let k = 0;
  return (
    <div style={{ display: "flex", flexWrap: "wrap", whiteSpace: "pre", ...style }}>
      {parts.map((ch, i) => {
        const isSpace = /^\s+$/.test(ch);
        const idx = isSpace ? k : k++;
        const st = at + idx * stagger;
        const q = p(f, st, st + dur);
        const ty = lerp(from, 0, q);
        const b = lerp(blur, 0, q);
        const settled = f >= st + dur;
        const g = glow ? glow(p(f, st + dur, st + dur + 12)) : undefined;
        return (
          <span
            key={i}
            style={{
              display: "inline-block",
              overflow: mask && !settled ? "hidden" : "visible",
              padding: mask ? "0.22em 0.16em 0.12em" : 0,
              margin: mask ? "-0.22em -0.16em -0.12em" : 0,
              verticalAlign: "top",
            }}
          >
            <span
              style={{
                display: "inline-block",
                transform: `translateY(${ty}%) rotate(${lerp(tilt, 0, q)}deg)`,
                transformOrigin: "0% 100%",
                opacity: Math.min(1, q * 1.6),
              }}
            >
              <span style={{ display: "inline-block", filter: b > 0.05 ? `blur(${b}px)` : undefined }}>
                <span style={{ ...glyphStyle, textShadow: g ?? glyphStyle?.textShadow }}>{ch}</span>
              </span>
            </span>
          </span>
        );
      })}
    </div>
  );
};

/**
 * Tracking that closes as the line arrives: letter-spacing goes from wide to
 * set while it fades in. The label move every title sequence uses.
 */
export const TrackIn: React.FC<{
  text: string;
  at: number;
  dur?: number;
  fromTrack?: number;
  toTrack?: number;
  style?: React.CSSProperties;
}> = ({ text, at, dur = 26, fromTrack = 0.6, toTrack = 0.26, style }) => {
  const f = useCurrentFrame();
  const q = p(f, at, at + dur);
  return (
    <div
      style={{
        letterSpacing: `${lerp(fromTrack, toTrack, q)}em`,
        opacity: q,
        whiteSpace: "nowrap",
        ...style,
      }}
    >
      {text}
    </div>
  );
};

const GLYPHS = "ABCDEFGHJKLMNPQRSTUVWXYZ0123456789#$%&*+=/<>";

/**
 * Decode: every character flickers through random glyphs until its own
 * resolve frame, left to right. Deterministic: the glyph is a hash of the
 * frame bucket and the index.
 */
export const Scramble: React.FC<{
  text: string;
  at: number;
  per?: number;
  flicker?: number;
  style?: React.CSSProperties;
  resolvedStyle?: React.CSSProperties;
}> = ({ text, at, per = 3, flicker = 10, style, resolvedStyle }) => {
  const f = useCurrentFrame();
  return (
    <span style={{ whiteSpace: "pre", ...style }}>
      {Array.from(text).map((ch, i) => {
        const resolveAt = at + flicker + i * per;
        if (ch === " ") return <span key={i}> </span>;
        if (f < at + i * per * 0.4) return <span key={i} style={{ opacity: 0 }}>{ch}</span>;
        if (f >= resolveAt) return <span key={i} style={resolvedStyle}>{ch}</span>;
        const g = GLYPHS[Math.floor(hash(i, Math.floor(f / 2) + 3) * GLYPHS.length)];
        return (
          <span key={i} style={{ opacity: 0.55 }}>
            {g}
          </span>
        );
      })}
    </span>
  );
};

/**
 * The hero title move: each character rises out of its mask with a blur that
 * resolves, and flickers through noise glyphs until its own resolve frame.
 */
export const DecodeRise: React.FC<{
  text: string;
  at: number;
  stagger?: number;
  dur?: number;
  hold?: number;
  style?: React.CSSProperties;
  glyphStyle?: React.CSSProperties;
  blur?: number;
  glow?: (a: number) => string;
}> = ({ text, at, stagger = 3, dur = 24, hold = 9, style, glyphStyle, blur = 16, glow }) => {
  const f = useCurrentFrame();
  let k = 0;
  return (
    <div style={{ display: "flex", whiteSpace: "pre", ...style }}>
      {Array.from(text).map((ch, i) => {
        if (ch === " ") return <span key={i}>{" "}</span>;
        const idx = k++;
        const start = at + idx * stagger;
        const q = p(f, start, start + dur);
        const resolved = f >= start + hold;
        const g = resolved ? ch : GLYPHS[Math.floor(hash(idx, Math.floor(f / 2) + 5) * GLYPHS.length)];
        const b = lerp(blur, 0, q);
        const settled = f >= start + dur;
        const gl = glow ? glow(p(f, start + dur, start + dur + 12)) : undefined;
        return (
          <span
            key={i}
            style={{ display: "inline-block", overflow: settled ? "visible" : "hidden", padding: "0.22em 0.16em 0.14em", margin: "-0.22em -0.16em -0.14em", verticalAlign: "top" }}
          >
            <span style={{ display: "inline-block", transform: `translateY(${lerp(105, 0, q)}%)`, opacity: Math.min(1, q * 1.8) }}>
              {/* the real glyph always holds the width, so the line never jitters while it decodes */}
              <span style={{ position: "relative", display: "inline-block", filter: b > 0.05 ? `blur(${b}px)` : undefined }}>
                <span style={{ opacity: resolved ? 1 : 0, ...glyphStyle, textShadow: gl ?? glyphStyle?.textShadow }}>{ch}</span>
                {resolved ? null : (
                  <span style={{ position: "absolute", left: 0, right: 0, top: 0, textAlign: "center", opacity: 0.55, ...glyphStyle }}>{g}</span>
                )}
              </span>
            </span>
          </span>
        );
      })}
    </div>
  );
};

/* ------------------------------------------------------------------ effects */

/** One expanding ring from a point. */
export const Shockwave: React.FC<{
  at: number;
  x: number;
  y: number;
  color: string;
  size?: number;
  dur?: number;
  width?: number;
}> = ({ at, x, y, color, size = 520, dur = 26, width = 6 }) => {
  const f = useCurrentFrame();
  if (f < at || f > at + dur) return null;
  const q = p(f, at, at + dur);
  return (
    <div
      style={{
        position: "absolute",
        left: x - size / 2,
        top: y - size / 2,
        width: size,
        height: size,
        borderRadius: "50%",
        border: `${lerp(width, 1, q)}px solid ${color}`,
        transform: `scale(${lerp(0.12, 1, q)})`,
        opacity: 1 - q,
      }}
    />
  );
};

/** Ballistic particle burst. Fixed pool, index seeded, pure function of time. */
export const Burst: React.FC<{
  at: number;
  x: number;
  y: number;
  color: string;
  n?: number;
  spread?: number;
  dur?: number;
}> = ({ at, x, y, color, n = 22, spread = 340, dur = 34 }) => {
  const f = useCurrentFrame();
  if (f < at || f > at + dur) return null;
  const t = (f - at) / dur;
  return (
    <>
      {new Array(n).fill(0).map((_, i) => {
        const ang = (i / n) * Math.PI * 2 + hash(i, 7) * 0.5;
        const v = spread * (0.55 + hash(i, 9) * 0.45);
        const ease = 1 - Math.pow(1 - t, 3);
        const px = x + Math.cos(ang) * v * ease;
        const py = y + Math.sin(ang) * v * ease + 140 * t * t;
        const s = (6 + hash(i, 11) * 10) * (1 - t);
        const long = hash(i, 13) > 0.5;
        return (
          <div
            key={i}
            style={{
              position: "absolute",
              left: px - s / 2,
              top: py - s / 2,
              width: long ? s * 2.4 : s,
              height: s,
              borderRadius: s,
              background: color,
              transform: `rotate(${(ang * 180) / Math.PI}deg)`,
              opacity: 1 - t * t,
            }}
          />
        );
      })}
    </>
  );
};

/** A diagonal light band that crosses its parent once. Parent needs overflow hidden. */
export const Sheen: React.FC<{ at: number; dur?: number; opacity?: number }> = ({
  at,
  dur = 30,
  opacity = 0.7,
}) => {
  const f = useCurrentFrame();
  if (f < at || f > at + dur) return null;
  const q = p(f, at, at + dur, SOFT);
  return (
    <div
      style={{
        position: "absolute",
        top: "-20%",
        bottom: "-20%",
        width: "34%",
        left: `${lerp(-50, 130, q)}%`,
        transform: "skewX(-18deg)",
        background:
          "linear-gradient(90deg, rgba(255,255,255,0) 0%, rgba(255,255,255,0.85) 50%, rgba(255,255,255,0) 100%)",
        opacity,
        mixBlendMode: "screen",
        pointerEvents: "none",
      }}
    />
  );
};

/** Full-frame flash, a couple of frames, for hard snaps. */
export const Flash: React.FC<{ at: number; dur?: number; color?: string; peak?: number }> = ({
  at,
  dur = 6,
  color = "#FFFFFF",
  peak = 0.85,
}) => {
  const f = useCurrentFrame();
  if (f < at || f > at + dur) return null;
  const q = (f - at) / dur;
  return <AbsoluteFill style={{ background: color, opacity: peak * (1 - q) * (1 - q) }} />;
};

/** Click ripple at a point. */
export const Ripple: React.FC<{ at: number; x: number; y: number; color: string; size?: number }> = ({
  at,
  x,
  y,
  color,
  size = 160,
}) => {
  const f = useCurrentFrame();
  if (f < at || f > at + 20) return null;
  const q = p(f, at, at + 20);
  return (
    <div
      style={{
        position: "absolute",
        left: x - size / 2,
        top: y - size / 2,
        width: size,
        height: size,
        borderRadius: "50%",
        background: color,
        transform: `scale(${lerp(0.15, 1, q)})`,
        opacity: 0.45 * (1 - q),
      }}
    />
  );
};

/** SVG stroke that draws itself. `len` is the path length in user units. */
export const Draw: React.FC<{
  d: string;
  at: number;
  dur?: number;
  len: number;
  color: string;
  width?: number;
  size: number;
  viewBox?: string;
}> = ({ d, at, dur = 14, len, color, width = 3, size, viewBox = "0 0 24 24" }) => {
  const f = useCurrentFrame();
  const q = p(f, at, at + dur);
  return (
    <svg width={size} height={size} viewBox={viewBox} fill="none" style={{ display: "block" }}>
      <path
        d={d}
        stroke={color}
        strokeWidth={width}
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeDasharray={len}
        strokeDashoffset={len * (1 - q)}
      />
    </svg>
  );
};

/* ------------------------------------------------------ rolling odometer */

/**
 * One digit column that rolls from `from` to `to` (through extra turns),
 * with vertical blur proportional to its speed. Lands on an integer.
 */
export const RollDigit: React.FC<{
  from: number;
  to: number;
  turns?: number;
  at: number;
  dur: number;
  size: number;
  color: string;
  weight?: number;
  glyphStyle?: React.CSSProperties;
  ease?: (t: number) => number;
}> = ({ from, to, turns = 1, at, dur, size, color, weight = 800, glyphStyle, ease = QUINT_INOUT }) => {
  const f = useCurrentFrame();
  const h = size * 1.04;
  const w = size * 0.64;
  const total = to + 10 * turns - from;
  const pos = (fr: number) => from + total * p(fr, at, at + dur, ease);
  const cur = pos(f);
  const vel = Math.abs(cur - pos(f - 1));
  const shown = ((cur % 10) + 10) % 10;
  const glyph: React.CSSProperties = {
    height: h,
    lineHeight: `${h}px`,
    fontFamily: SANS,
    fontWeight: weight,
    fontSize: size,
    letterSpacing: "-0.04em",
    color,
    textAlign: "center",
    fontVariantNumeric: "tabular-nums",
    whiteSpace: "nowrap",
  };
  // Settled: plain digit, nothing clips it, so the glow and the glyph edges are never cut into a box.
  if (f >= at + dur) {
    return (
      <div style={{ height: h, width: w, position: "relative" }}>
        <div style={{ position: "absolute", left: "50%", top: 0, transform: "translateX(-50%)", ...glyph, ...glyphStyle }}>{to}</div>
      </div>
    );
  }
  // Rolling: no hard clip. A soft gradient mask, taller and wider than the digit box, fades the
  // digits in and out at top and bottom, so nothing is ever cut by a straight edge.
  const padY = h * 0.3;
  const fade = "linear-gradient(to bottom, transparent 0%, #000 30%, #000 70%, transparent 100%)";
  return (
    <div style={{ height: h, width: w, position: "relative" }}>
      <div
        style={{
          position: "absolute",
          left: -w * 0.5,
          top: -padY,
          width: w * 2,
          height: h + padY * 2,
          overflow: "hidden",
          WebkitMaskImage: fade,
          maskImage: fade,
        }}
      >
        <div style={{ transform: `translateY(${padY - shown * h}px)` }}>
          {[9, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 1].map((d, i) => (
            <div key={i} style={{ ...glyph, marginTop: i === 0 ? -h : 0, filter: vel > 0.02 ? `blur(${Math.min(10, vel * 9)}px)` : undefined, ...glyphStyle, textShadow: undefined }}>
              {d}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

/* ------------------------------------------------------------- pointer */

export const Pointer: React.FC<{ x: number; y: number; pressed?: boolean; opacity?: number; size?: number }> = ({
  x,
  y,
  pressed = false,
  opacity = 1,
  size = 64,
}) => (
  <div
    style={{
      position: "absolute",
      left: x,
      top: y,
      transform: `scale(${pressed ? 0.84 : 1})`,
      transformOrigin: "6px 3px",
      opacity,
      pointerEvents: "none",
    }}
  >
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" style={{ filter: "drop-shadow(0 6px 10px rgba(0,0,40,0.22))" }}>
      <path
        d="M5.5 2.2 L5.5 19.1 L9.6 15.2 L12.2 21.4 L15.1 20.2 L12.5 14.2 L18.2 14.2 Z"
        fill="#ffffff"
        stroke="#111"
        strokeWidth="1.1"
        strokeLinejoin="round"
      />
    </svg>
  </div>
);

/** Point along a quadratic curve: cursors travel in arcs, never straight lines. */
export const arc = (
  t: number,
  a: [number, number],
  b: [number, number],
  bend = 0.25
): [number, number] => {
  const mx = (a[0] + b[0]) / 2 - (b[1] - a[1]) * bend;
  const my = (a[1] + b[1]) / 2 + (b[0] - a[0]) * bend;
  const u = 1 - t;
  return [u * u * a[0] + 2 * u * t * mx + t * t * b[0], u * u * a[1] + 2 * u * t * my + t * t * b[1]];
};
