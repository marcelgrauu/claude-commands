/**
 * Real accumulated motion blur (CameraMotionBlur), but only inside the
 * frame windows where the camera or the whole scene moves fast: whips,
 * crash zooms, push-throughs. It renders the subtree `samples` times, so
 * outside the windows the children render plain. Use MotionBlur (fx.tsx)
 * for single elements; use this when the move is a zoom or a rotation
 * that a directional blur cannot fake.
 * Windows sorted and not overlapping. Nested negative Sequences keep the
 * children on absolute time.
 */
import React from "react";
import { Sequence } from "remotion";
import { CameraMotionBlur } from "@remotion/motion-blur";

export const BlurWindow: React.FC<{
  windows: [number, number][];
  total: number;
  samples?: number;
  shutter?: number;
  children: React.ReactNode;
}> = ({ windows, total, samples = 6, shutter = 180, children }) => {
  const segs: { from: number; to: number; blur: boolean }[] = [];
  let cur = 0;
  windows.forEach(([a, b]) => {
    if (a > cur) segs.push({ from: cur, to: a, blur: false });
    segs.push({ from: a, to: b, blur: true });
    cur = b;
  });
  if (cur < total) segs.push({ from: cur, to: total, blur: false });
  return (
    <>
      {segs.map((s, i) => (
        <Sequence key={i} from={s.from} durationInFrames={s.to - s.from}>
          <Sequence from={-s.from}>
            {s.blur ? (
              <CameraMotionBlur samples={samples} shutterAngle={shutter}>
                {children}
              </CameraMotionBlur>
            ) : (
              children
            )}
          </Sequence>
        </Sequence>
      ))}
    </>
  );
};
