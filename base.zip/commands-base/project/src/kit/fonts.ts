/**
 * Marcel's two families, loaded from public/fonts. FontGate blocks the
 * render until each face is ready, so there is never a fallback frame.
 *
 * Helvetica Neue faces available: Thin 100, Medium 500, Bold 700, Black 900
 * (+ Black Italic). There is no Regular/Light file: for body weight use 500,
 * for the light display look use 100.
 * Apple Garamond: Light 300, Regular 400, Bold 700, each with italic.
 */
import { staticFile } from "remotion";

const faces: [string, string, string, "normal" | "italic"][] = [
  ["HN", "HelveticaNeueThin.otf", "100", "normal"],
  ["HN", "HelveticaNeueMedium.otf", "500", "normal"],
  ["HN", "HelveticaNeueBold.otf", "700", "normal"],
  ["HN", "HelveticaNeueBlack.otf", "900", "normal"],
  ["HN", "HelveticaNeueBlackItalic.otf", "900", "italic"],
  ["AG", "AppleGaramond-Light.ttf", "300", "normal"],
  ["AG", "AppleGaramond-LightItalic.ttf", "300", "italic"],
  ["AG", "AppleGaramond.ttf", "400", "normal"],
  ["AG", "AppleGaramond-Italic.ttf", "400", "italic"],
  ["AG", "AppleGaramond-Bold.ttf", "700", "normal"],
  ["AG", "AppleGaramond-BoldItalic.ttf", "700", "italic"],
];

let loading: Promise<unknown> | null = null;

/** One shared load for the whole tab. FontGate awaits it before the first frame. */
export const loadFaces = () => {
  if (!loading) {
    loading = Promise.all(
      faces.map(([family, file, weight, style]) => {
        const face = new FontFace(family, `url('${staticFile(`fonts/${file}`)}')`, { weight, style });
        (document.fonts as unknown as { add: (f: FontFace) => void }).add(face);
        // a missing font file must never hang the render: fall back to the next family in the stack
        return face.load().catch(() => null);
      })
    );
  }
  return loading;
};

export const SANS = "HN, 'Helvetica Neue', Helvetica, Arial, sans-serif";
export const SERIF = "AG, 'Apple Garamond', Garamond, serif";
export const MONO = "'SF Mono', 'JetBrains Mono', Consolas, monospace";
