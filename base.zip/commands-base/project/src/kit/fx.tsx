/**
 * Render primitives: directional motion blur, grain, glow field.
 *
 * House rule from the old kit, still true: a transform and a filter never
 * live on the same node. The wrapper moves, the inner node blurs.
 */
import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";

/**
 * Directional motion blur from velocity (px per frame). An SVG gaussian with
 * different x and y deviation smears only along the move, like a 180°
 * shutter. Cheaper than CameraMotionBlur and it never bands gradients.
 * sigma = speed * shutter * 0.5; shutter 0.5 = 180°.
 */
export const MotionBlur: React.FC<{
  id: string;
  vx?: number;
  vy?: number;
  shutter?: number;
  max?: number;
  children: React.ReactNode;
  style?: React.CSSProperties;
}> = ({ id, vx = 0, vy = 0, shutter = 0.5, max = 80, children, style }) => {
  const sx = Math.min(max, Math.abs(vx) * shutter * 0.5);
  const sy = Math.min(max, Math.abs(vy) * shutter * 0.5);
  const on = sx > 0.15 || sy > 0.15;
  return (
    <div style={{ filter: on ? `url(#${id})` : undefined, ...style }}>
      {on ? (
        <svg width={0} height={0} style={{ position: "absolute" }}>
          <filter id={id} x="-50%" y="-50%" width="200%" height="200%" colorInterpolationFilters="sRGB">
            <feGaussianBlur stdDeviation={`${sx.toFixed(2)} ${sy.toFixed(2)}`} />
          </filter>
        </svg>
      ) : null}
      {children}
    </div>
  );
};

/** Film grain. New seed every 2 frames; also dithers gradients so they never band. */
export const Grain: React.FC<{ opacity?: number; blend?: React.CSSProperties["mixBlendMode"] }> = ({
  opacity = 0.06,
  blend = "overlay",
}) => {
  const f = useCurrentFrame();
  const seed = Math.floor(f / 2) % 60;
  return (
    <AbsoluteFill style={{ pointerEvents: "none", mixBlendMode: blend, opacity }}>
      <svg width="100%" height="100%">
        <filter id={`grain${seed}`}>
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves={2} seed={seed} stitchTiles="stitch" />
          <feColorMatrix type="saturate" values="0" />
        </filter>
        <rect width="100%" height="100%" filter={`url(#grain${seed})`} />
      </svg>
    </AbsoluteFill>
  );
};

/** One light in a glow field. All values in px of a 1080 wide frame. */
export type Light = { x: number; y: number; w: number; h: number; a?: number };

/** Heat ramp: black, maroon, red, orange, amber, hot core. Pass your own for other brands. */
export const HEAT = ["#FFE7A8", "#FFB21E", "#FF6A00", "#E3140B", "#5A0300"];

/**
 * Apple-Intelligence-style light field. Each light is an ellipse painted
 * with the full colour ramp (core to edge), like a heat map, and lights
 * combine with `lighten`, so overlaps stay as hot as the hottest one
 * instead of turning into mud. A single colour per blurred blob is the
 * cheap look; the ramp is what reads as light.
 */
export const GlowField: React.FC<{ base?: string; lights: Light[]; ramp?: string[]; blur?: number }> = ({
  base = "#000",
  lights,
  ramp = HEAT,
  blur = 36,
}) => {
  const [c0, c1, c2, c3, c4] = ramp;
  const grad = `radial-gradient(closest-side, ${c0} 0%, ${c1} 18%, ${c2} 40%, ${c3} 62%, ${c4} 84%, transparent 100%)`;
  return (
    <AbsoluteFill style={{ background: base, overflow: "hidden" }}>
      <AbsoluteFill style={{ filter: `blur(${blur}px)` }}>
        {lights.map((l, i) => (
          <div
            key={i}
            style={{
              position: "absolute",
              left: l.x - l.w / 2,
              top: l.y - l.h / 2,
              width: l.w,
              height: l.h,
              background: grad,
              opacity: l.a ?? 1,
              mixBlendMode: "lighten",
            }}
          />
        ))}
      </AbsoluteFill>
    </AbsoluteFill>
  );
};
