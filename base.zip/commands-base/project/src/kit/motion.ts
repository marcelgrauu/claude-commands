/**
 * Motion core: curves, keyframe tracks, velocity.
 *
 * Every move in the system is a track of keyframes with an ease per segment.
 * Velocity comes from the track itself (central difference), so motion blur
 * and squash/stretch are always proportional to the real speed of the move.
 */
import { Easing, interpolate } from "remotion";

export type Ease = (t: number) => number;

/* Curves. Named after the speed graph they produce, not after the tool. */
export const EASE = {
  /** fast start, very long tail. The default for anything arriving. */
  out: Easing.bezier(0.16, 1, 0.3, 1),
  /** quart out, a touch less aggressive than expo */
  outSoft: Easing.bezier(0.25, 1, 0.5, 1),
  /** symmetric S, for moves between two rest positions (camera, layout morph) */
  inOut: Easing.bezier(0.65, 0, 0.35, 1),
  /** strong S with a sharp middle: whip pans, push-throughs */
  inOutHard: Easing.bezier(0.83, 0, 0.17, 1),
  /** accelerating exit, for things leaving the frame */
  in: Easing.bezier(0.7, 0, 0.84, 0),
  /** tiny overshoot, ~4%. Never bigger. */
  back: Easing.bezier(0.34, 1.32, 0.64, 1),
  /** linear, only for continuous drifts and rotations */
  linear: (t: number) => t,
} as const;

export const clamp = (v: number, a = 0, b = 1) => Math.min(b, Math.max(a, v));
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

/** 0..1 between two frames, eased and clamped. */
export const prog = (f: number, from: number, to: number, ease: Ease = EASE.out) =>
  interpolate(f, [from, to], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
    easing: ease,
  });

/** Keyframe: [frame, value, ease of the segment that ENDS here]. */
export type Key = [number, number, Ease?];

/** Evaluate a keyframe track at a (fractional) frame. Holds before and after. */
export const track = (f: number, keys: Key[]): number => {
  if (f <= keys[0][0]) return keys[0][1];
  for (let i = 1; i < keys.length; i++) {
    const [f1, v1, e] = keys[i];
    const [f0, v0] = keys[i - 1];
    if (f <= f1) {
      const t = f1 === f0 ? 1 : (f - f0) / (f1 - f0);
      return lerp(v0, v1, (e ?? EASE.inOut)(t));
    }
  }
  return keys[keys.length - 1][1];
};

/** Value of a track and its speed in units per frame. */
export const motion = (f: number, keys: Key[]) => {
  const v = track(f, keys);
  const vel = (track(f + 0.5, keys) - track(f - 0.5, keys));
  return { v, vel };
};

/** Speed per frame of any function of frame. */
export const velocityOf = (fn: (f: number) => number, f: number) => fn(f + 0.5) - fn(f - 0.5);

/** Deterministic hash in [0,1). */
export const hash = (i: number, s = 1) => {
  const x = Math.sin(i * 12.9898 + s * 78.233) * 43758.5453;
  return x - Math.floor(x);
};

/**
 * Damped spring evaluated analytically from a start frame. Used for the
 * secondary motion (a card settling after the camera stops) where an
 * ease cannot fake the second, smaller swing.
 * response = seconds to settle-ish, damping 0..1 (1 = no overshoot).
 */
export const springAt = (f: number, at: number, fps: number, response = 0.5, damping = 0.82) => {
  const t = Math.max(0, (f - at) / fps);
  const w = (2 * Math.PI) / response;
  const z = clamp(damping, 0.01, 0.999);
  const wd = w * Math.sqrt(1 - z * z);
  return 1 - Math.exp(-z * w * t) * (Math.cos(wd * t) + ((z * w) / wd) * Math.sin(wd * t));
};
