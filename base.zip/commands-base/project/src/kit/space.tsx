/**
 * 2.5D space with an orbit camera and depth of field, in CSS 3D.
 *
 *   <Space cam={{ x, y, z: 300, rx: 8, ry: -12 }} focus={300}>
 *     <Layer z={-600}>...</Layer>       far, blurred
 *     <Layer z={0}>...</Layer>          on the target plane
 *   </Space>
 *
 * The camera looks at the target point (x, y, 0) and orbits around it with
 * rx / ry / rz, like an After Effects camera with its point of interest.
 * z dollies toward the target: at z = 0 the target plane is drawn at
 * scale 1, z = 300 is closer, z = -1500 far away. Units are px.
 * `perspective` is the lens: perspective = width * focalMm / 36, so at 1080
 * wide 1050 is a 35mm, 1500 a 50mm, 2550 an 85mm (UI and devices: 2200+).
 * Depth of field: blur = |layer.z + cam.z - focus| * aperture, so a rack
 * focus is just animating `focus` (focus = cam.z keeps the target plane sharp).
 */
import React, { createContext, useContext } from "react";
import { AbsoluteFill } from "remotion";

export type Cam = { x?: number; y?: number; z?: number; rx?: number; ry?: number; rz?: number };

const Ctx = createContext<{ camZ: number; focus: number; aperture: number; maxBlur: number }>({
  camZ: 0,
  focus: 0,
  aperture: 0,
  maxBlur: 0,
});

export const Space: React.FC<{
  cam?: Cam;
  perspective?: number;
  focus?: number;
  aperture?: number;
  maxBlur?: number;
  children: React.ReactNode;
  style?: React.CSSProperties;
}> = ({ cam = {}, perspective = 1400, focus = 0, aperture = 0.02, maxBlur = 30, children, style }) => {
  const { x = 0, y = 0, z = 0, rx = 0, ry = 0, rz = 0 } = cam;
  return (
    <AbsoluteFill style={{ perspective, perspectiveOrigin: "50% 50%", overflow: "hidden", ...style }}>
      <AbsoluteFill
        style={{
          transformStyle: "preserve-3d",
          transform: `translateZ(${z}px) rotateZ(${rz}deg) rotateX(${rx}deg) rotateY(${ry}deg) translate3d(${-x}px, ${-y}px, 0px)`,
        }}
      >
        <Ctx.Provider value={{ camZ: z, focus, aperture, maxBlur }}>{children}</Ctx.Provider>
      </AbsoluteFill>
    </AbsoluteFill>
  );
};

/**
 * A flat plane in the space. Position is its centre relative to frame
 * centre. The blur lives on the inner node, the transform on the outer.
 */
export const Layer: React.FC<{
  x?: number;
  y?: number;
  z?: number;
  rx?: number;
  ry?: number;
  rz?: number;
  scale?: number;
  /** extra blur on top of depth of field (e.g. motion) */
  blur?: number;
  noDof?: boolean;
  opacity?: number;
  children: React.ReactNode;
  style?: React.CSSProperties;
}> = ({ x = 0, y = 0, z = 0, rx = 0, ry = 0, rz = 0, scale = 1, blur = 0, noDof, opacity = 1, children, style }) => {
  const { camZ, focus, aperture, maxBlur } = useContext(Ctx);
  // focus is measured from the camera: distance of this layer to the focal plane
  const dist = Math.abs(z + camZ - focus);
  const dof = noDof ? 0 : Math.min(maxBlur, dist * aperture);
  const b = dof + blur;
  return (
    <div
      style={{
        position: "absolute",
        left: "50%",
        top: "50%",
        transformStyle: "preserve-3d",
        transform: `translate(-50%, -50%) translate3d(${x}px, ${y}px, ${z}px) rotateZ(${rz}deg) rotateX(${rx}deg) rotateY(${ry}deg) scale(${scale})`,
        opacity,
      }}
    >
      <div style={{ filter: b > 0.2 ? `blur(${b.toFixed(2)}px)` : undefined, ...style }}>{children}</div>
    </div>
  );
};
