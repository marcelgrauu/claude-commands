/**
 * Typography in motion.
 *
 *  FontGate  render nothing until every face is decoded, so measureText and
 *            the first frame both use the real font.
 *  Phrase    words that arrive one by one while the line re-centres itself
 *            around them (the Apple keynote move). Widths are measured.
 *  Chars     per-letter rise with resolving blur, from a soft mask.
 *  Roll      odometer number: each digit rolls with vertical motion blur
 *            through a feathered window (never a hard clip edge).
 */
import React, { useEffect, useState } from "react";
import { continueRender, delayRender, useCurrentFrame } from "remotion";
import { measureText } from "@remotion/layout-utils";
import { EASE, Ease, lerp, prog, track, Key } from "./motion";
import { MotionBlur } from "./fx";
import { loadFaces } from "./fonts";

export const FontGate: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [handle] = useState(() => delayRender("fonts", { timeoutInMilliseconds: 120000, retries: 2 }));
  const [ready, setReady] = useState(false);
  useEffect(() => {
    loadFaces().then(() => {
      setReady(true);
      continueRender(handle);
    });
  }, [handle]);
  return ready ? <>{children}</> : null;
};

export type Word = {
  text: string;
  at: number;
  style?: React.CSSProperties;
  /** text fill, e.g. a gradient via backgroundImage + backgroundClip */
};

/**
 * A centred line whose words arrive at their own frame. Each new word grows
 * its slot from 0 to its width, so the words already on screen slide aside
 * to make room instead of jumping.
 */
export const Phrase: React.FC<{
  words: Word[];
  fontFamily: string;
  fontSize: number;
  fontWeight?: number | string;
  letterSpacing?: number;
  color?: string;
  dur?: number;
  blur?: number;
  rise?: number;
  ease?: Ease;
  gap?: number;
  style?: React.CSSProperties;
}> = ({
  words,
  fontFamily,
  fontSize,
  fontWeight = 500,
  letterSpacing = 0,
  color = "#fff",
  dur = 18,
  blur = 14,
  rise = 0.25,
  ease = EASE.out,
  gap = 0.26,
  style,
}) => {
  const f = useCurrentFrame();
  const widths = words.map(
    (w) =>
      measureText({
        text: w.text,
        fontFamily,
        fontSize,
        fontWeight: String(w.style?.fontWeight ?? fontWeight),
        letterSpacing: `${letterSpacing}px`,
      }).width
  );
  const gapPx = gap * fontSize;
  const pres = words.map((w) => prog(f, w.at, w.at + dur, ease));
  const slot = widths.map((w, i) => (w + (i === 0 ? 0 : gapPx)) * pres[i]);
  const total = slot.reduce((a, b) => a + b, 0);
  let x = -total / 2;
  return (
    <div style={{ position: "relative", height: fontSize * 1.2, ...style }}>
      {words.map((w, i) => {
        const left = x + (i === 0 ? 0 : gapPx * pres[i]);
        x += slot[i];
        const q = pres[i];
        if (q <= 0) return null;
        return (
          <div
            key={i}
            style={{
              position: "absolute",
              left: `calc(50% + ${left}px)`,
              top: 0,
              transform: `translateY(${lerp(rise * fontSize, 0, q)}px) scale(${lerp(0.94, 1, q)})`,
              transformOrigin: "50% 100%",
              opacity: Math.min(1, q * 1.5),
            }}
          >
            <div
              style={{
                filter: q < 0.999 ? `blur(${lerp(blur, 0, q)}px)` : undefined,
                fontFamily,
                fontSize,
                fontWeight,
                letterSpacing,
                color,
                whiteSpace: "nowrap",
                lineHeight: 1.2,
                ...w.style,
              }}
            >
              {w.text}
            </div>
          </div>
        );
      })}
    </div>
  );
};

/** Per-letter rise. Mask is a feathered gradient, never overflow:hidden. */
export const Chars: React.FC<{
  text: string;
  at: number;
  stagger?: number;
  dur?: number;
  from?: number;
  blur?: number;
  ease?: Ease;
  style?: React.CSSProperties;
  charStyle?: (i: number, q: number) => React.CSSProperties;
}> = ({ text, at, stagger = 1.6, dur = 20, from = 0.9, blur = 18, ease = EASE.out, style, charStyle }) => {
  const f = useCurrentFrame();
  return (
    <div style={{ display: "flex", whiteSpace: "pre", ...style }}>
      {Array.from(text).map((ch, i) => {
        const st = at + i * stagger;
        const q = prog(f, st, st + dur, ease);
        return (
          <span
            key={i}
            style={{
              display: "inline-block",
              transform: `translateY(${lerp(from, 0, q)}em)`,
              opacity: Math.min(1, q * 2),
            }}
          >
            <span style={{ display: "inline-block", filter: q < 0.999 ? `blur(${lerp(blur, 0, q)}px)` : undefined, ...charStyle?.(i, q) }}>
              {ch}
            </span>
          </span>
        );
      })}
    </div>
  );
};

/**
 * Odometer. keys drive the numeric value over time; each digit column
 * rolls continuously (the 1s digit spins fast and blurs, the 100s barely
 * moves), exactly like a mechanical counter. Feathered top/bottom window.
 */
export const Roll: React.FC<{
  id: string;
  keys: Key[];
  digits: number;
  decimals?: number;
  prefix?: string;
  suffix?: React.ReactNode;
  /** thousands separator, e.g. "," -> 84,320 */
  thousands?: string;
  fontSize: number;
  style?: React.CSSProperties;
  digitWidth?: number;
}> = ({ id, keys, digits, decimals = 0, prefix = "", suffix, thousands, fontSize, style, digitWidth = 0.6 }) => {
  const f = useCurrentFrame();
  const scale = Math.pow(10, decimals);
  const val = track(f, keys) * scale;
  const valPrev = track(f - 1, keys) * scale;
  const cols = [];
  const lineH = fontSize * 1.05;
  for (let c = digits - 1; c >= 0; c--) {
    const place = Math.pow(10, c);
    const pos = (val / place) % 10; // continuous position of this wheel
    const posPrev = (valPrev / place) % 10;
    let d = pos - posPrev;
    if (d < -5) d += 10;
    const speed = d * lineH; // px per frame
    const settled = Math.abs(d) < 0.002;
    const isLeadingZero = val < place - 0.5 && c > decimals;
    const shown = settled ? Math.round(pos) % 10 : pos;
    cols.push(
      <React.Fragment key={c}>
        {c === decimals - 1 ? <span>.</span> : null}
        <span
          style={{
            position: "relative",
            display: "inline-block",
            width: isLeadingZero ? 0 : `${digitWidth}em`,
            height: lineH,
            opacity: isLeadingZero ? 0 : 1,
            WebkitMaskImage: settled
              ? undefined
              : "linear-gradient(to bottom, transparent 0%, #000 28%, #000 72%, transparent 100%)",
          }}
        >
          <MotionBlur id={`${id}-${c}`} vy={speed} style={{ position: "absolute", inset: 0 }}>
            <span style={{ position: "absolute", left: 0, right: 0, top: 0, transform: `translateY(${-(shown % 1) * lineH}px)` }}>
              {(settled ? [0] : [0, 1]).map((k) => (
                <span key={k} style={{ display: "block", height: lineH, lineHeight: `${lineH}px`, textAlign: "center" }}>
                  {(Math.floor(shown) + k) % 10}
                </span>
              ))}
            </span>
          </MotionBlur>
        </span>
        {thousands && c - decimals > 0 && (c - decimals) % 3 === 0 && !isLeadingZero ? <span>{thousands}</span> : null}
      </React.Fragment>
    );
  }
  return (
    <div style={{ display: "inline-flex", alignItems: "flex-start", fontSize, lineHeight: `${lineH}px`, fontVariantNumeric: "tabular-nums", ...style }}>
      {prefix ? <span>{prefix}</span> : null}
      {cols}
      {suffix}
    </div>
  );
};
