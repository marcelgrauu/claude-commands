/**
 * UI motion primitives (refs: prompt-motion 001 twoclipping, Apple HIG).
 *
 *  ShapeShifter  ONE container that morphs size, radius and fill from UI
 *                state to UI state. The morph is fast (10 to 14 f @60) and the
 *                whole shape blurs in proportion to how fast it is changing
 *                size, so it reads as one physical object, never as a cut.
 *  StateContent  the content of one state: hidden during the morph,
 *                children arrive in a cascade with blur -> sharp.
 *  Cursor        macOS arrow that travels in arcs and presses (scale .86).
 */
import React from "react";
import { useCurrentFrame } from "remotion";
import { EASE, Ease, Key, clamp, lerp, prog, track } from "./motion";

export type ShapeState = {
  /** frame where the morph INTO this state starts */
  at: number;
  w: number;
  h: number;
  r: number;
  bg: string;
  /** morph duration in frames */
  dur?: number;
  ease?: Ease;
};

const hexToRgb = (h: string) => {
  const n = parseInt(h.replace("#", ""), 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
};
const mixHex = (a: string, b: string, t: number) => {
  const A = hexToRgb(a);
  const B = hexToRgb(b);
  return `rgb(${A.map((v, i) => Math.round(lerp(v, B[i], t))).join(",")})`;
};

/** Which state is active at frame f, and how far the morph into it has gone. */
export const shapeAt = (f: number, states: ShapeState[]) => {
  let i = 0;
  while (i < states.length - 1 && f >= states[i + 1].at) i++;
  const cur = states[i];
  const prev = states[Math.max(0, i - 1)];
  const dur = cur.dur ?? 12;
  const t = i === 0 ? 1 : prog(f, cur.at, cur.at + dur, cur.ease ?? EASE.out);
  return { i, t, cur, prev };
};

export const ShapeShifter: React.FC<{
  states: ShapeState[];
  /** extra scale (press feedback, pops) */
  scale?: number;
  children?: React.ReactNode;
  shadow?: string;
}> = ({ states, scale = 1, children, shadow = "0 2px 4px rgba(0,0,0,0.06), 0 18px 40px rgba(0,0,0,0.16)" }) => {
  const f = useCurrentFrame();
  const dims = (fr: number) => {
    const { t, cur, prev } = shapeAt(fr, states);
    return { w: lerp(prev.w, cur.w, t), h: lerp(prev.h, cur.h, t), r: lerp(prev.r, cur.r, t), t, cur, prev };
  };
  const d = dims(f);
  const d1 = dims(f + 1);
  const speed = Math.abs(d1.w - d.w) + Math.abs(d1.h - d.h);
  const blur = Math.min(14, speed * 0.09);
  return (
    <div style={{ transform: `scale(${scale})` }}>
      <div
        style={{
          position: "relative",
          width: d.w,
          height: d.h,
          borderRadius: d.r,
          background: mixHex(d.prev.bg, d.cur.bg, d.t),
          boxShadow: shadow,
          filter: blur > 0.3 ? `blur(${blur.toFixed(2)}px)` : undefined,
          overflow: "hidden",
        }}
      >
        {children}
      </div>
    </div>
  );
};

/**
 * Content of one state. `from` is when the morph into it ends, `to` when
 * the next morph starts. Children get their own index for the cascade.
 */
export const StateContent: React.FC<{
  from: number;
  to: number;
  stagger?: number;
  children: React.ReactNode;
  style?: React.CSSProperties;
}> = ({ from, to, stagger = 4, children, style }) => {
  const f = useCurrentFrame();
  if (f < from - 2 || f > to + 2) return null;
  const out = prog(f, to - 5, to, EASE.in);
  const kids = React.Children.toArray(children);
  return (
    <div style={{ position: "absolute", inset: 0, ...style }}>
      {kids.map((k, i) => {
        const q = prog(f, from + i * stagger, from + i * stagger + 16, EASE.out);
        const o = q * (1 - out);
        return (
          <React.Fragment key={i}>
            {React.isValidElement(k)
              ? React.cloneElement(k as React.ReactElement<{ style?: React.CSSProperties }>, {
                  style: {
                    ...((k as React.ReactElement<{ style?: React.CSSProperties }>).props.style ?? {}),
                    opacity: o,
                    filter: o < 0.99 ? `blur(${((1 - q) * 8 + out * 6).toFixed(2)}px)` : undefined,
                    translate: `0 ${lerp(10, 0, q)}px`,
                  },
                })
              : k}
          </React.Fragment>
        );
      })}
    </div>
  );
};

/** Cursor keys: [frame, x, y]; clicks: frames where it presses. Moves arc like a hand. */
export const Cursor: React.FC<{ path: [number, number, number][]; clicks?: number[]; scale?: number }> = ({
  path,
  clicks = [],
  scale = 1.6,
}) => {
  const f = useCurrentFrame();
  const xs: Key[] = path.map(([t, x], i) => [t, x, i === 0 ? undefined : EASE.inOut]);
  const ys: Key[] = path.map(([t, , y], i) => [t, y, i === 0 ? undefined : EASE.inOut]);
  let x = track(f, xs);
  let y = track(f, ys);
  // arc: perpendicular offset that peaks mid-move, 6% of the travel
  for (let i = 1; i < path.length; i++) {
    const [t0, x0, y0] = path[i - 1];
    const [t1, x1, y1] = path[i];
    if (f > t0 && f < t1) {
      const s = Math.sin(Math.PI * clamp((f - t0) / (t1 - t0)));
      const dx = x1 - x0;
      const dy = y1 - y0;
      x += -dy * 0.06 * s;
      y += dx * 0.06 * s;
    }
  }
  const press = clicks.reduce((acc, c) => Math.max(acc, f >= c - 3 && f <= c + 6 ? 1 - Math.abs(f - c) / 6 : 0), 0);
  return (
    <div style={{ position: "absolute", left: x, top: y, transform: `scale(${scale * (1 - press * 0.14)})`, transformOrigin: "0 0", pointerEvents: "none" }}>
      <svg width={26} height={34} viewBox="0 0 26 34" style={{ filter: "drop-shadow(0 2px 3px rgba(0,0,0,0.3))" }}>
        <path d="M2 2 L2 27 L8.5 21 L12.8 31 L17 29.2 L12.8 19.6 L21.5 19.6 Z" fill="#000" stroke="#fff" strokeWidth={2} strokeLinejoin="round" />
      </svg>
    </div>
  );
};
