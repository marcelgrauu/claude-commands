# Claude video commands (83)

Every command is a Claude Code skill. Type `/orbit` (or any other) with your clip in the folder and Claude builds the effect on top of it.

## Install (2 minutes)

1. You need Claude Code, Node 18+, Python 3 and ffmpeg.
2. Copy ALL the folders in this pack (including `commands-base`) into `~/.claude/skills/`.
3. Open Claude Code in the folder with your clip and type, for example: `/orbit use my clip video.mp4`.

The first run takes a bit longer because it installs Remotion.

Typography: the effects are designed in Helvetica Neue and Apple Garamond. If you own them, drop the font files in `commands-fx/public/fonts/` (names in `src/kit/fonts.ts`); if not, they fall back to Helvetica and Garamond automatically.

## To make them look perfect

Shoot (or generate) the clip on a locked camera, vertical, with room around your head. Every command tells you which shot suits it best.

## All of them

| Command | What it does |
|---|---|
| /orbit | Small reel cards orbit around your body while the line lands in two voices above your head. |
| /liquid-glass-graph | A thick liquid glass slab floats up in front of you with a graph that climbs. |
| /match-cut | Macro shots of real printed pages cut faster and faster on one word that never moves. |
| /apple-ui-toggles | An iOS settings group in liquid glass whose switches flip on one line at a time. |
| /glass-type | Giant 3D glass letters standing in the room, behind you. |
| /over-the-shoulder-zoom | Proof cards land beside your head: a small BEFORE, then a big AFTER that counts up. |
| /ui-world | Claude's interface becomes the ceiling and you sit under it. |
| /screen-push-digital | Words light up on a macro LED wall and the camera flies through them. |
| /pov-carousel-spin | A clean gallery ring of your reels around your head that tilts into 3D and spins. |
| /shutter-strike | Photo prints of you slam in with a camera flash. |
| /headline-wall | The wall behind you fills with headlines and thumbnails. |
| /claude-beside-me | A Claude window swings out from behind your head and types. |
| /frame-break | You are inside an Instagram reel and you break out of the frame. |
| /digital-zoom | A punch-in zoom with motion blur and a word that snaps into focus. |
| /phone-mockup | A real iPhone slides out from behind you and a finger taps Approve. |
| /screen-push | Particles pour into a container on a split screen. |
| /before-after | A seam of light turns your room into a white studio. |
| /glass-card | A dark liquid glass card with a big title, a number and one line. |
| /jiggle-delete | Your editing apps jiggle and get deleted until only Claude is left. |
| /reel-feed | Your video becomes an Instagram Reels feed scrolled by thumb. |
| /word-stack | Giant words stack up next to your head. |
| /cursor-click | A cursor clicks Generate and the result appears. |
| /typewriter-cut | A typed page flicks behind you while one word stays locked in place. |
| /reel-fan | Your reels fan out behind your head like a hand of cards. |
| /growth-chart | 3D bars climb behind you to a big final number. |
| /pixel-title | Your title assembles from flying dots above your head. |
| /couch-wall | The wall behind you fills with your reels and their views. |
| /checklist | An iOS Reminders style list that ticks itself off. |
| /all-at-once | The orbit and the reel fan fire on the same beat. |
| /zoom-through-cut | The camera flies into a frame on the wall and comes out in the next shot. |
| /chart-grow | An iPhone Screen Time style chart grows above your head. |
| /pull-back-reveal | Tight on you, then the camera pulls back and you are inside Claude Code. |
| /green-screen | Your background is keyed out and replaced by a moving set. |
| /paper-cut | You become a paper sticker on torn kraft paper. |
| /doodle-boil | Hand drawn doodles around you that boil. |
| /vertigo | A dolly zoom: the room stretches while you stay the same size. |
| /cover-story | You are the cover of a magazine. |
| /kinetic-hook | The hook slams in word by word in different weights and blocks. |
| /gravity-drop | Letters fall with gravity and bounce into place. |
| /giant-captions | One giant caption word behind you, the small caption under it. |
| /prompt-bar | A clean prompt bar floats over your head and sends itself. |
| /storyboard-deck | A deck of storyboard frames deals out across your chest. |
| /icon-strike | Your old editing apps get struck out. |
| /file-drop | Your clip flies into a drop zone and uploads. |
| /nle-timeline | Claude cuts the dead air on a real editing timeline. |
| /grade-slider | A before and after colour grade slider sweeps across you. |
| /eyedropper-grade | An eyedropper samples colours off the shot and builds the palette. |
| /film-look | Your shot turns into 16 mm film. |
| /title-card | A full frame title card that wipes open on your shot. |
| /playing-grid | You shrink into one tile of a grid of playing videos. |
| /video-card | The shot shrinks into a widescreen video card. |
| /comment-cta | Your keyword comment pops in and the auto reply lands under it. |
| /comment-drop | The keyword letters drop in giant into a comment box. |
| /hero-number | A giant number counts up behind you. |
| /notif-stack | iPhone notifications stack up over your head. |
| /comment-rain | Comments with your keyword rain all over the screen. |
| /price-strike | The price gets struck out and a FREE stamp slams in. |
| /progress-track | A progress bar advances step by step. |
| /callout | Labels with lines point at parts of the shot. |
| /search-bar | A search bar types the question and the results drop. |
| /prompt-card | The prompt types itself live and the button switches to Copied. |
| /stamp | A stamp slams in and the shot shakes. |
| /brand-lockup | An end card with your name and the brand, for collabs. |
| /orbit-posters | Design posters orbit around your head and turn in 3D. |
| /logo-orbit | Your tool logos orbit around your head on a tilted ring. |
| /effect-list | The running list of the video pinned in a corner, the current one lit. |
| /name-tag | A lower third with your handle, a Follow tag and one line of who you are. |
| /creator-list | A sheet of creator profiles scrolls and one gets picked. |
| /code-reveal | The effect's code types itself, then folds into the rendered result. |
| /hand-cards | Two cards float between your hands and flip to show the combination. |
| /split-notes | The top half becomes a clean board with notes and a prompt box. |
| /app-tutorial | Claude's desktop app on the top half, a cursor walks through the steps. |
| /caption-pill | Your words type into a chat pill with your avatar. |
| /glass-explainer | A black stage with a chapter tab and two glass tiles, one number rolls to a million. |
| /explainer-panel | A close-up of you on top, a bottom panel cycles explainer cards. |
| /cinematic-type | Full colour cards with a big serif italic phrase and a line that comes in word by word. |
| /image-cluster | Metaphor images drop in and overlap behind your head. |
| /cutout-grid | A 2x2 grid of images fills the frame behind you and changes with each idea. |
| /cutout-backdrop | You cut out over one full-screen image per idea. |
| /depth-ui | An interface card behind your head and a serif word on your chest. |
| /split-reel | Face on top, a dark panel below with a title, $1 vs a rolling number and thumbnails. |
| /split-document | A document on the left fills in with highlights, you on the right. |
| /song-card | A now playing card on a clean stage, then the shot wipes in with one word. |

If you would rather not use skills, every folder ends with a **direct prompt** you can paste straight into Claude Code.
