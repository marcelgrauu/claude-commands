import React from "react";
import { Composition } from "remotion";
import "./index.css";
import { FontGate } from "./FontGate";
import { AppleToggles } from "./fx/AppleToggles";
import { GlassType } from "./fx/GlassType";
import { ClaudeBesideMe, FrameBreak, HeadlineWall, ShutterStrike } from "./fx/Grid1";
import { BeforeAfter, CursorClick, DigitalZoom, GlassCard, ScreenPush, WordStack } from "./fx/Grid2";
import { JiggleDelete } from "./fx/Grid3";
import { AllAtOnce, Checklist, CouchWall, GrowthChart, PixelTitle, ReelFan, TypewriterCut } from "./fx/Grid4";
import { ChartGrow, CoverStory, DoodleBoil, GreenScreen, PaperCut, PullBackReveal, Vertigo, ZoomThroughCut } from "./fx/Grid5";
import { CommentCta, CommentDrop, EyedropperGrade, FileDrop, FilmLook, GiantCaptions, GradeSlider, GravityDrop, IconStrike, KineticHook, NleTimeline, PlayingGrid, PromptBar, StoryboardDeck, TitleCard, VideoCard } from "./fx/Grid6";
import { BrandLockup, Callout, CommentRain, HeroNumber, NotifStack, OrbitPosters, PriceStrike, ProgressTrack, PromptCard, SearchBar, Stamp } from "./fx/Grid7";
import { AppTutorial, CaptionPill, CodeReveal, CreatorList, EffectList, HandCards, LogoOrbit, NameTag, SplitNotes } from "./fx/Grid8";
import { CinematicType, CutoutBackdrop, CutoutGrid, DepthUi, ExplainerPanel, GlassExplainer, ImageCluster, SongCard, SplitDocument, SplitReel } from "./fx/Grid9";
import { LiquidGlassGraph } from "./fx/LiquidGlassGraph";
import { MatchCut } from "./fx/MatchCut";
import { Orbit } from "./fx/Orbit";
import { OverShoulder } from "./fx/OverShoulder";
import { PovCarouselSpin } from "./fx/PovCarousel";
import { PhoneMockup, ReelFeed } from "./fx/RefMatch";
import { ScreenPushDigital } from "./fx/ScreenPushDigital";
import { UiWorld } from "./fx/UiWorld";

// clip + its cutout, both starting at the same frame
export const c = (name: string, startFrom: number) => ({ clip: { src: `clips/${name}.mp4`, startFrom }, cut: { src: `clips/${name}-alpha.mov`, startFrom } });

// Claude: add one Composition per effect the user asks for, e.g.
// <Composition id="fx-orbit" component={() => <FontGate><Orbit {...c("input", 0)} /></FontGate>} durationInFrames={110} fps={30} width={1080} height={1920} />
export const RemotionRoot: React.FC = () => <></>;
