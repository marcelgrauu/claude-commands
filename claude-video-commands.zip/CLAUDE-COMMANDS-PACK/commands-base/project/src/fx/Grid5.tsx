/**
 * Grid effects, part 5: @tenfoldmarc 9 to 16.
 * /zoom-through-cut, /chart-grow, /pull-back-reveal, /green-screen, /paper-cut,
 * /doodle-boil, /vertigo, /cover-story
 */
import React from "react";
import { AbsoluteFill, OffthreadVideo, interpolate, staticFile, useCurrentFrame } from "remotion";
import { EXPO_OUT, EXPO_IN, BACK_OUT, QUINT_INOUT, SOFT, p, hash } from "../kit";
import { EASE, prog } from "../kit/motion";
import { Clip, ClipProps, Cutout, Scene, FilmGrain, MONO, SANS, SERIF, TIGHT, Y } from "./common";

export const G5_DUR = 100;

/* ---------------------------------------------------------- /zoom-through-cut */
// the camera flies into the picture frame on the wall behind you and comes out in the next shot
export const ZoomThroughCut: React.FC<{ clip: ClipProps; next: string; target?: [number, number] }> = ({ clip, next, target = [840, 470] }) => {
  const f = useCurrentFrame();
  const fly = p(f, 18, 44, EXPO_IN);
  const out = p(f, 44, 70, EXPO_OUT);
  const s1 = 1 + fly * 9;
  const blur = Math.min(14, (p(f, 30, 44, (x) => x) - p(f, 44, 52, (x) => x)) * 14);
  return (
    <AbsoluteFill style={{ background: "#000", overflow: "hidden" }}>
      {f < 44 ? (
        <AbsoluteFill style={{ transformOrigin: `${target[0]}px ${target[1]}px`, transform: `scale(${s1})` }}>
          <AbsoluteFill style={{ filter: blur > 0.3 ? `blur(${blur}px)` : undefined }}><Clip {...clip} /></AbsoluteFill>
        </AbsoluteFill>
      ) : (
        <AbsoluteFill style={{ transform: `scale(${2.4 - 1.4 * out})` }}>
          <AbsoluteFill style={{ filter: blur > 0.3 ? `blur(${blur}px)` : undefined }}>
            <OffthreadVideo src={staticFile(next)} muted startFrom={30} style={{ width: 1080, height: 1920 }} />
          </AbsoluteFill>
        </AbsoluteFill>
      )}
      <AbsoluteFill style={{ background: "#fff", opacity: Math.max(0, 1 - Math.abs(f - 44) / 3) * 0.5 }} />
      <AbsoluteFill style={{ background: "radial-gradient(ellipse 85% 65% at 50% 45%, transparent 55%, rgba(0,0,0,0.38) 100%)" }} />
      <FilmGrain />
    </AbsoluteFill>
  );
};

/* ---------------------------------------------------------- /chart-grow */
// an iPhone Screen Time style weekly chart grows above your head
const DAYS = ["M", "T", "W", "T", "F", "S", "S"];
const VALS = [0.35, 0.5, 0.42, 0.66, 0.58, 0.82, 1];
export const ChartGrow: React.FC<{ clip: ClipProps; cut: ClipProps }> = ({ clip, cut }) => {
  const f = useCurrentFrame();
  const enter = p(f, 2, 18, EXPO_OUT);
  const chart = (
    <div style={{ position: "absolute", left: 150, top: 150, width: 780, height: 430, opacity: enter, transform: `translateY(${(1 - enter) * -40}px)` }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
        <div style={{ fontFamily: SANS, fontWeight: 600, fontSize: 30, color: "rgba(255,255,255,0.75)" }}>Views this week</div>
        <div style={{ fontFamily: TIGHT, fontWeight: 800, fontSize: 64, color: "#fff", letterSpacing: -2, fontVariantNumeric: "tabular-nums" }}>{(Math.round(interpolate(p(f, 14, 70, QUINT_INOUT), [0, 1], [0, 48])) / 10).toFixed(1)}M</div>
      </div>
      <div style={{ position: "absolute", left: 0, right: 0, bottom: 50, height: 300, display: "flex", alignItems: "flex-end", gap: 30 }}>
        {VALS.map((v, i) => {
          const g = p(f, 12 + i * 5, 34 + i * 5, BACK_OUT);
          return <div key={i} style={{ flex: 1, height: `${v * 100 * g}%`, borderRadius: 14, background: i === 6 ? Y : "rgba(255,255,255,0.88)", boxShadow: i === 6 ? "0 0 30px rgba(255,229,0,0.5)" : undefined }} />;
        })}
      </div>
      {[0, 1, 2].map((g) => <div key={g} style={{ position: "absolute", left: 0, right: 0, bottom: 50 + g * 100, height: 1, background: "rgba(255,255,255,0.18)" }} />)}
      <div style={{ position: "absolute", left: 0, right: 0, bottom: 0, display: "flex", gap: 30 }}>
        {DAYS.map((d, i) => <div key={i} style={{ flex: 1, textAlign: "center", fontFamily: SANS, fontWeight: 600, fontSize: 26, color: "rgba(255,255,255,0.7)" }}>{d}</div>)}
      </div>
    </div>
  );
  return <Scene clip={clip} cut={cut} dur={G5_DUR} push={[1, 1.05]} origin={[540, 700]} back={chart} />;
};

/* ---------------------------------------------------------- /pull-back-reveal */
// tight on you, then the camera pulls back and you are inside Claude's desktop app, tasks ticking
const TASKS = ["Transcribed 1 clip", "Picked the best take", "Cut 3 silences", "Added captions", "Rendered 4K"];
export const PullBackReveal: React.FC<{ clip: ClipProps }> = ({ clip }) => {
  const f = useCurrentFrame();
  const pull = p(f, 8, 40, QUINT_INOUT);
  // video rect inside the app window
  const VX = 470, VY = 420, VW = 520, VH = 924;
  const x = interpolate(pull, [0, 1], [0, VX]);
  const y = interpolate(pull, [0, 1], [0, VY]);
  const w = interpolate(pull, [0, 1], [1080, VW]);
  const h = interpolate(pull, [0, 1], [1920, VH]);
  const app = p(f, 20, 40, EXPO_OUT);
  return (
    <AbsoluteFill style={{ background: "#ECEAE4", overflow: "hidden" }}>
      <div style={{ position: "absolute", left: 40, top: 300, width: 1000, height: 1140, borderRadius: 34, background: "#FAF9F5", boxShadow: "0 40px 90px rgba(0,0,0,0.2)", opacity: app }}>
        <div style={{ position: "absolute", left: 26, top: 24, display: "flex", gap: 10 }}>{["#FF5F57", "#FEBC2E", "#28C840"].map((c) => <div key={c} style={{ width: 18, height: 18, borderRadius: 9, background: c }} />)}</div>
        <div style={{ position: "absolute", left: 40, top: 80, fontFamily: SANS, fontWeight: 700, fontSize: 30, color: "#1F1E1B" }}>✳ Claude Code</div>
        <div style={{ position: "absolute", left: 40, top: 140, width: 370 }}>
          {TASKS.map((t, i) => {
            const k = p(f, 34 + i * 9, 42 + i * 9, BACK_OUT);
            return (
              <div key={t} style={{ display: "flex", alignItems: "center", gap: 14, padding: "16px 0", opacity: 0.35 + 0.65 * Math.min(1, k * 1.5), borderBottom: "1px solid #ECE8DE" }}>
                <div style={{ width: 30, height: 30, borderRadius: 15, background: k > 0.1 ? "#30D158" : "#E6E2D8", display: "grid", placeItems: "center", transform: `scale(${0.7 + 0.3 * k})` }}>
                  {k > 0.1 && <svg width={20} height={20} viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth={3.4} strokeLinecap="round" strokeLinejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5" /></svg>}
                </div>
                <div style={{ fontFamily: SANS, fontSize: 26, color: "#2A2925" }}>{t}</div>
              </div>
            );
          })}
        </div>
        <div style={{ position: "absolute", left: 40, right: 40, bottom: 30, height: 70, borderRadius: 20, border: "1.5px solid #E4DFD2", display: "flex", alignItems: "center", padding: "0 24px", fontFamily: SANS, fontSize: 26, color: "#A29E93" }}>Reply to Claude…</div>
      </div>
      <div style={{ position: "absolute", left: x, top: y, width: w, height: h, borderRadius: 24 * pull, overflow: "hidden", boxShadow: pull > 0.1 ? "0 20px 50px rgba(0,0,0,0.25)" : undefined }}>
        <div style={{ position: "absolute", left: 0, top: 0, width: 1080, height: 1920, transform: `scale(${w / 1080})`, transformOrigin: "0 0" }}><Clip {...clip} /></div>
      </div>
    </AbsoluteFill>
  );
};

/* ---------------------------------------------------------- /green-screen */
// your background is keyed away and replaced by a moving landing page set
export const GreenScreen: React.FC<{ clip: ClipProps; cut: ClipProps }> = ({ clip, cut }) => {
  const f = useCurrentFrame();
  const key = p(f, 10, 30, QUINT_INOUT);
  const drift = f * 0.6;
  const set = (
    <AbsoluteFill style={{ clipPath: `inset(0 0 ${100 - key * 100}% 0)` }}>
      {/* the new set: a flat yellow seamless with a soft floor falloff, nothing generic */}
      <AbsoluteFill style={{ background: "radial-gradient(ellipse 80% 55% at 50% 38%, #FFEB3B 0%, #FFE500 45%, #E9CF00 100%)" }} />
      <AbsoluteFill style={{ background: "linear-gradient(180deg, transparent 58%, rgba(120,95,0,0.22) 100%)" }} />
      <div style={{ position: "absolute", left: 70, top: 150, fontFamily: TIGHT, fontWeight: 900, fontSize: 150, letterSpacing: -7, lineHeight: 0.86, color: "#0A0A0A", transform: `translateX(${(1 - prog(f, 26, 44, EASE.out)) * -60}px)`, opacity: prog(f, 24, 32) }}>Ship it</div>
      <div style={{ position: "absolute", left: 76, top: 290, fontFamily: SERIF, fontStyle: "italic", fontWeight: 400, fontSize: 130, letterSpacing: -3, lineHeight: 0.9, color: "#0A0A0A", transform: `translateX(${(1 - prog(f, 32, 50, EASE.out)) * -60}px)`, opacity: prog(f, 30, 38) }}>today.</div>
      <div style={{ position: "absolute", left: 0, right: 0, top: 1180, height: 120, background: "radial-gradient(ellipse 40% 50% at 50% 50%, rgba(90,70,0,0.35), transparent 70%)" }} />
    </AbsoluteFill>
  );
  // a green flash sweeping down is the "key" moment
  const sweep = (
    <div style={{ position: "absolute", left: 0, right: 0, top: `${key * 100}%`, height: 10, background: "#3CFF6E", boxShadow: "0 0 24px rgba(60,255,110,0.8)", opacity: key > 0 && key < 1 ? 1 : 0 }} />
  );
  return <Scene clip={clip} cut={cut} dur={G5_DUR} push={[1, 1.05]} origin={[540, 800]} back={<>{set}{sweep}</>} />;
};

/* ---------------------------------------------------------- /paper-cut */
// you become a paper sticker: thick white border, lifted shadow, on torn kraft paper
export const PaperCut: React.FC<{ cut: ClipProps }> = ({ cut }) => {
  const f = useCurrentFrame();
  const pop = p(f, 4, 20, BACK_OUT);
  const wob = Math.sin(f / 7) * 1.2;
  const W = 14;
  const outline = [0, 45, 90, 135, 180, 225, 270, 315].map((a) => `drop-shadow(${(Math.cos((a * Math.PI) / 180) * W).toFixed(1)}px ${(Math.sin((a * Math.PI) / 180) * W).toFixed(1)}px 0 #fff)`).join(" ");
  return (
    <AbsoluteFill style={{ background: "#C9A97A", overflow: "hidden" }}>
      <AbsoluteFill style={{ backgroundImage: "radial-gradient(rgba(80,50,20,0.25) 1px, transparent 1.4px)", backgroundSize: "7px 7px" }} />
      <div style={{ position: "absolute", left: -40, right: -40, top: 240, height: 360, background: "#F3EEE2", transform: "rotate(-4deg)", clipPath: "polygon(0 8%, 6% 0, 14% 6%, 22% 1%, 31% 7%, 40% 0, 52% 6%, 63% 2%, 74% 8%, 86% 1%, 100% 6%, 100% 94%, 88% 100%, 76% 93%, 64% 99%, 50% 92%, 38% 100%, 26% 94%, 12% 100%, 0 93%)" }} />
      <div style={{ position: "absolute", left: 0, right: 0, top: 300, textAlign: "center", fontFamily: TIGHT, fontWeight: 900, fontSize: 170, letterSpacing: -8, color: "#151515", transform: "rotate(-4deg)" }}>CUT IT</div>
      <AbsoluteFill style={{ transformOrigin: "540px 1100px", transform: `rotate(${wob}deg) scale(${0.9 + 0.1 * pop}) translateY(${(1 - pop) * 120}px)` }}>
        <AbsoluteFill style={{ filter: `${outline} drop-shadow(0 30px 30px rgba(0,0,0,0.45))` }}><Cutout {...cut} /></AbsoluteFill>
      </AbsoluteFill>
      <FilmGrain opacity={0.08} />
    </AbsoluteFill>
  );
};

/* ---------------------------------------------------------- /doodle-boil */
// hand drawn doodles around you that "boil" (redraw every 3 frames)
const jit = (i: number, f: number, amt = 4) => (hash(i * 7 + Math.floor(f / 3), 3) - 0.5) * amt;
const Doodle: React.FC<{ d: string; f: number; seed: number; color?: string; at: number }> = ({ d, f, seed, color = "#fff", at }) => {
  const t = p(f, at, at + 12, (x) => x);
  return (
    <svg width={1080} height={1920} style={{ position: "absolute", left: 0, top: 0, overflow: "visible" }}>
      <path d={d} fill="none" stroke={color} strokeWidth={7} strokeLinecap="round" strokeLinejoin="round" pathLength={1} strokeDasharray={`${t} 1`} transform={`translate(${jit(seed, f)} ${jit(seed + 1, f)}) rotate(${jit(seed + 2, f, 1.5)} 540 900)`} />
    </svg>
  );
};
export const DoodleBoil: React.FC<{ clip: ClipProps; cut: ClipProps }> = ({ clip, cut }) => {
  const f = useCurrentFrame();
  const back = (
    <>
      <Doodle f={f} seed={1} at={4} d="M 230 520 C 260 380, 420 330, 540 340 C 690 350, 830 420, 850 560" />
      <Doodle f={f} seed={4} at={10} color={Y} d="M 150 330 l 20 -60 l 20 60 l 60 0 l -50 36 l 20 60 l -50 -36 l -50 36 l 20 -60 l -50 -36 z" />
      <Doodle f={f} seed={7} at={16} color="#FF6B9A" d="M 880 300 c -20 -40 -80 -30 -70 20 c 10 40 70 70 70 70 c 0 0 60 -30 70 -70 c 10 -50 -50 -60 -70 -20 z" />
      <Doodle f={f} seed={9} at={22} d="M 120 760 q 40 -40 80 0 t 80 0 t 80 0" />
      <Doodle f={f} seed={11} at={26} d="M 820 760 l 70 -30 M 830 820 l 80 0 M 820 880 l 70 30" />
    </>
  );
  // a boiling white outline around the person
  const W = 6;
  const o = (k: number) => [0, 90, 180, 270].map((a) => `drop-shadow(${(Math.cos((a * Math.PI) / 180) * W + jit(k + a, f, 3)).toFixed(1)}px ${(Math.sin((a * Math.PI) / 180) * W + jit(k + a + 1, f, 3)).toFixed(1)}px 0 #fff)`).join(" ");
  const outline = <AbsoluteFill style={{ filter: o(1), opacity: p(f, 2, 10) }}><Cutout {...cut} /></AbsoluteFill>;
  return <Scene clip={clip} cut={cut} dur={G5_DUR} push={[1, 1.04]} origin={[540, 800]} back={<>{back}{outline}</>} />;
};

/* ---------------------------------------------------------- /vertigo */
// dolly zoom: the room stretches behind you while you stay the same size
export const Vertigo: React.FC<{ clip: ClipProps; cut: ClipProps }> = ({ clip, cut }) => {
  const f = useCurrentFrame();
  const z = interpolate(f, [0, 10, 80, G5_DUR], [1, 1, 1.75, 1.8], { easing: QUINT_INOUT, extrapolateRight: "clamp" });
  const t = p(f, 24, 40, EXPO_OUT);
  return (
    <AbsoluteFill style={{ background: "#000", overflow: "hidden" }}>
      <AbsoluteFill style={{ transformOrigin: "540px 820px", transform: `scale(${z})` }}>
        <AbsoluteFill style={{ filter: `blur(${(z - 1) * 3}px)` }}><Clip {...clip} /></AbsoluteFill>
      </AbsoluteFill>
      {/* streaks pulling out */}
      <AbsoluteFill style={{ background: `repeating-conic-gradient(from 0deg at 50% 43%, rgba(255,255,255,${0.08 * (z - 1)}) 0deg 1deg, transparent 1deg 8deg)` }} />
      <AbsoluteFill><Cutout {...cut} /></AbsoluteFill>
      <div style={{ position: "absolute", left: 0, right: 0, top: 1300, textAlign: "center", fontFamily: TIGHT, fontWeight: 800, fontSize: 110, letterSpacing: -5, color: "#fff", opacity: t, transform: `scale(${1.3 - 0.3 * t})`, textShadow: "0 8px 30px rgba(0,0,0,0.6)" }}>wait <span style={{ color: Y }}>what?</span></div>
      <AbsoluteFill style={{ background: "radial-gradient(ellipse 85% 65% at 50% 45%, transparent 55%, rgba(0,0,0,0.38) 100%)" }} />
      <FilmGrain />
    </AbsoluteFill>
  );
};

/* ---------------------------------------------------------- /cover-story */
// you are the cover of a magazine: masthead behind your head, coverlines, barcode
export const CoverStory: React.FC<{ clip: ClipProps; cut: ClipProps }> = ({ clip, cut }) => {
  const f = useCurrentFrame();
  const m = p(f, 2, 22, EXPO_OUT);
  const lines = ["The editor that never sleeps", "20 effects, one command", "Inside the new workflow"];
  const masthead = (
    <div style={{ position: "absolute", left: 0, right: 0, top: 230, textAlign: "center", fontFamily: "AG, serif", fontWeight: 800, fontSize: 330, letterSpacing: -14, color: "#F5F1E8", lineHeight: 0.9, opacity: m, transform: `translateY(${(1 - m) * -80}px)`, textShadow: "0 10px 40px rgba(0,0,0,0.35)" }}>EDIT</div>
  );
  const front = (
    <>
      <div style={{ position: "absolute", left: 60, top: 110, right: 60, display: "flex", justifyContent: "space-between", fontFamily: MONO, fontSize: 24, letterSpacing: 4, color: "#F5F1E8", opacity: p(f, 8, 18) }}><span>ISSUE 01</span><span>OCTOBER 2026</span></div>
      {lines.map((l, i) => (
        <div key={l} style={{ position: "absolute", left: 60, top: 1180 + i * 110, width: 380, fontFamily: "AG, serif", fontWeight: 600, fontSize: 44, lineHeight: 1.05, color: "#F5F1E8", opacity: p(f, 20 + i * 6, 32 + i * 6), transform: `translateX(${(1 - p(f, 20 + i * 6, 34 + i * 6, EXPO_OUT)) * -40}px)`, textShadow: "0 3px 12px rgba(0,0,0,0.5)" }}>
          <span style={{ display: "block", width: 46, height: 6, background: Y, marginBottom: 10 }} />{l}
        </div>
      ))}
      <div style={{ position: "absolute", right: 60, bottom: 120, width: 170, height: 110, background: "#fff", padding: 10, opacity: p(f, 36, 46) }}>
        <div style={{ width: "100%", height: 70, background: "repeating-linear-gradient(90deg,#111 0 3px,transparent 3px 6px,#111 6px 7px,transparent 7px 11px)" }} />
        <div style={{ fontFamily: MONO, fontSize: 14, color: "#111", marginTop: 6 }}>9 771234 567003</div>
      </div>
    </>
  );
  return <Scene clip={clip} cut={cut} dur={G5_DUR} push={[1, 1.05]} origin={[540, 760]} back={masthead} front={front} />;
};
