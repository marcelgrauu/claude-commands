/**
 * Claude mobile app (dark, Code tab), recreated for the reel.
 * One <ChatBeat> = attach clip, type /command, send, "Editando con ...",
 * result card loads through a dot mask, then grows to full screen.
 *
 * Timeline of a beat (frames @30fps), all relative to the beat start:
 *   0  composer + keyboard already up, "/" typed
 *   2  letters typed every TYPE_STEP frames, key popup on each
 *   SEND        tap on send
 *   SEND+2..10  keyboard drops, message flies to the top, composer collapses
 *   STATUS      "Editando con ..." line
 *   CARD        result card in, dot mask reveal until CARD_CLEAR
 *   ZOOM..ZOOM_END  card grows to full screen, UI falls away
 *   BEAT        end
 */
import React from "react";
import { AbsoluteFill, OffthreadVideo, Img, interpolate, staticFile, useCurrentFrame, Sequence } from "remotion";
import { EXPO_OUT, QUINT_INOUT, BACK_OUT, p, lerp } from "../kit";

export const UI = {
  bg: "#262624",
  surface: "#30302E",
  surface2: "#3A3936",
  line: "rgba(255,255,255,0.08)",
  text: "#F5F4EF",
  muted: "#A6A39A",
  faint: "#75726B",
  orange: "#D97757",
  send: "#C6613F",
  pill: "#3B302B",
  key: "#4A4946",
  keyDark: "#363533",
  kb: "#1E1E1D",
  font: "HN, Helvetica, Arial, sans-serif",
};

export const TYPE_START = 3;
export const TYPE_STEP = 2.1;

/**
 * Human typing: 1.5 to 2.7 frames per key (50 to 90 ms), small bursts, a breath after "/"
 * and before each "-". Returns the frame each character of the command lands on.
 */
export const charTimes = (cmd: string) => {
  const out: number[] = [];
  let t = TYPE_START + 2.5; // "/" is typed at TYPE_START, then a short breath
  for (let i = 0; i < cmd.length; i++) {
    const h = Math.abs(Math.sin((i + 1) * 12.9898 + cmd.length * 78.233) * 43758.5453) % 1;
    t += 1.5 + h * 1.2 + (cmd[i] === "-" ? 1.6 : 0);
    out.push(t);
  }
  return out;
};

/** Beat timeline. `shift` adds hold before the zoom so the zoom lands on a music beat. */
export const beatTimes = (cmd: string, shift = 0) => {
  const ct = charTimes(cmd);
  const typed = Math.ceil(ct[ct.length - 1]);
  const SEND = typed + 5;
  const STATUS = SEND + 5;
  const CARD = STATUS + 2;
  const CARD_CLEAR = CARD + 12;
  const ZOOM = CARD_CLEAR + 6 + shift;
  const ZOOM_END = ZOOM + 12;
  const BEAT = ZOOM_END + 28;
  return { typed, SEND, STATUS, CARD, CARD_CLEAR, ZOOM, ZOOM_END, BEAT };
};

/* ------------------------------------------------------------- icons */

const Asterisk: React.FC<{ size: number; rot?: number; color?: string }> = ({ size, rot = 0, color = UI.orange }) => (
  <svg width={size} height={size} viewBox="-12 -12 24 24" style={{ transform: `rotate(${rot}deg)`, flex: "none" }}>
    {Array.from({ length: 10 }).map((_, i) => {
      const len = i % 2 ? 9.2 : 11;
      return (
        <rect key={i} x={-1.05} y={-len} width={2.1} height={len} rx={1.05} fill={color}
          transform={`rotate(${i * 36 + (i % 3) * 4})`} />
      );
    })}
  </svg>
);
export { Asterisk };

const IconMenu = () => (
  <svg width={46} height={46} viewBox="0 0 24 24" fill="none" stroke={UI.text} strokeWidth={1.8} strokeLinecap="round">
    <path d="M5 9h14M5 15h9" />
  </svg>
);
const IconEdit = () => (
  <svg width={44} height={44} viewBox="0 0 24 24" fill="none" stroke={UI.text} strokeWidth={1.7} strokeLinecap="round" strokeLinejoin="round">
    <path d="M12 4H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-6" />
    <path d="M17.5 3.5a2.1 2.1 0 0 1 3 3L13 14l-4 1 1-4z" />
  </svg>
);
const IconPlus = ({ c = UI.muted, s = 40 }) => (
  <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth={1.8} strokeLinecap="round">
    <path d="M12 5v14M5 12h14" />
  </svg>
);
const IconSliders = ({ c = UI.muted }) => (
  <svg width={40} height={40} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth={1.7} strokeLinecap="round">
    <path d="M4 8h9M17 8h3M4 16h3M11 16h9" />
    <circle cx={15} cy={8} r={2} />
    <circle cx={9} cy={16} r={2} />
  </svg>
);
const IconMic = ({ c = UI.muted }) => (
  <svg width={40} height={40} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth={1.7} strokeLinecap="round">
    <rect x={9} y={3} width={6} height={11} rx={3} />
    <path d="M5.5 11a6.5 6.5 0 0 0 13 0M12 17.5V21" />
  </svg>
);
const IconArrowUp = ({ c = "#fff", s = 34 }) => (
  <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth={2.4} strokeLinecap="round" strokeLinejoin="round">
    <path d="M12 19V5M6 11l6-6 6 6" />
  </svg>
);
const IconX = () => (
  <svg width={18} height={18} viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth={3} strokeLinecap="round">
    <path d="M6 6l12 12M18 6L6 18" />
  </svg>
);
const IconPlay = () => (
  <svg width={16} height={16} viewBox="0 0 24 24"><path d="M7 4l13 8-13 8z" fill="#fff" /></svg>
);

/* ------------------------------------------------------------- top bar */

export const TopBar: React.FC<{ opacity?: number }> = ({ opacity = 1 }) => (
  <div style={{ position: "absolute", left: 0, right: 0, top: 42, height: 96, display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 44px", opacity }}>
    <div style={{ width: 84, height: 84, borderRadius: 42, display: "grid", placeItems: "center" }}><IconMenu /></div>
    <div style={{ display: "flex", background: "#1E1E1C", borderRadius: 999, padding: 6, gap: 4, border: `1px solid ${UI.line}` }}>
      <div style={{ padding: "14px 34px", fontFamily: UI.font, fontSize: 30, color: UI.muted, fontWeight: 500 }}>Chat</div>
      <div style={{ padding: "14px 34px", fontFamily: UI.font, fontSize: 30, color: UI.text, fontWeight: 500, background: UI.surface2, borderRadius: 999 }}>Code</div>
    </div>
    <div style={{ width: 84, height: 84, display: "grid", placeItems: "center" }}><IconEdit /></div>
  </div>
);

/* ------------------------------------------------------------- keyboard */

const ROWS = ["qwertyuiop", "asdfghjkl", "zxcvbnm"];
const KB_TOP = 1236;
const KEY_W = 90;
const KEY_H = 118;
const KEY_GAP = 14;
const ROW_GAP = 26;
const SUGG_H = 104;

const keyRect = (ch: string) => {
  for (let r = 0; r < ROWS.length; r++) {
    const i = ROWS[r].indexOf(ch);
    if (i < 0) continue;
    const n = ROWS[r].length;
    const rowW = n * KEY_W + (n - 1) * KEY_GAP;
    const x0 = (1080 - rowW) / 2;
    return { x: x0 + i * (KEY_W + KEY_GAP), y: KB_TOP + SUGG_H + r * (KEY_H + ROW_GAP) };
  }
  return null;
};

export const Keyboard: React.FC<{ typed: string; pressedChar: string | null; pressT: number; y: number }> = ({ typed, pressedChar, pressT, y }) => {
  const word = typed.replace(/^\//, "");
  return (
    <div style={{ position: "absolute", left: 0, top: 0, width: 1080, height: 1920, transform: `translateY(${y}px)` }}>
      <div style={{ position: "absolute", left: 0, right: 0, top: KB_TOP, bottom: 0, background: UI.kb, borderTop: `1px solid ${UI.line}` }} />
      {/* predictive bar */}
      <div style={{ position: "absolute", left: 0, right: 0, top: KB_TOP, height: SUGG_H, display: "flex", alignItems: "center", fontFamily: UI.font, fontSize: 34, color: UI.text }}>
        <div style={{ flex: 1, textAlign: "center", opacity: word ? 1 : 0 }}>“{word}”</div>
        <div style={{ width: 1, height: 44, background: UI.line }} />
        <div style={{ flex: 1 }} />
        <div style={{ width: 1, height: 44, background: UI.line }} />
        <div style={{ flex: 1 }} />
      </div>
      {ROWS.map((row, r) =>
        row.split("").map((ch) => {
          const k = keyRect(ch)!;
          return (
            <div key={ch} style={{ position: "absolute", left: k.x, top: k.y, width: KEY_W, height: KEY_H, borderRadius: 14, background: UI.key, boxShadow: "0 3px 0 rgba(0,0,0,0.45)", display: "grid", placeItems: "center", fontFamily: UI.font, fontSize: 46, color: UI.text }}>
              {ch}
            </div>
          );
        })
      )}
      {/* shift + delete */}
      <div style={{ position: "absolute", left: 24, top: KB_TOP + SUGG_H + 2 * (KEY_H + ROW_GAP), width: 132, height: KEY_H, borderRadius: 14, background: UI.keyDark, boxShadow: "0 3px 0 rgba(0,0,0,0.45)", display: "grid", placeItems: "center" }}>
        <svg width={44} height={44} viewBox="0 0 24 24" fill="none" stroke={UI.text} strokeWidth={1.7} strokeLinejoin="round"><path d="M12 4l8 8h-4.5v7h-7v-7H4z" /></svg>
      </div>
      <div style={{ position: "absolute", right: 24, top: KB_TOP + SUGG_H + 2 * (KEY_H + ROW_GAP), width: 132, height: KEY_H, borderRadius: 14, background: UI.keyDark, boxShadow: "0 3px 0 rgba(0,0,0,0.45)", display: "grid", placeItems: "center" }}>
        <svg width={48} height={48} viewBox="0 0 24 24" fill="none" stroke={UI.text} strokeWidth={1.7} strokeLinejoin="round"><path d="M9 5h11v14H9l-6-7z" /><path d="M12.5 9.5l5 5M17.5 9.5l-5 5" strokeLinecap="round" /></svg>
      </div>
      {/* bottom row */}
      {(() => {
        const ry = KB_TOP + SUGG_H + 3 * (KEY_H + ROW_GAP);
        return (
          <>
            <div style={{ position: "absolute", left: 24, top: ry, width: 132, height: KEY_H, borderRadius: 14, background: UI.keyDark, display: "grid", placeItems: "center", fontFamily: UI.font, fontSize: 36, color: UI.text, boxShadow: "0 3px 0 rgba(0,0,0,0.45)" }}>123</div>
            <div style={{ position: "absolute", left: 172, top: ry, width: 104, height: KEY_H, borderRadius: 14, background: UI.keyDark, display: "grid", placeItems: "center", boxShadow: "0 3px 0 rgba(0,0,0,0.45)" }}>
              <svg width={46} height={46} viewBox="0 0 24 24" fill="none" stroke={UI.text} strokeWidth={1.6}><circle cx={12} cy={12} r={8.5} /><path d="M8.5 14.5c1.8 2 5.2 2 7 0" strokeLinecap="round" /><circle cx={9.3} cy={10} r={0.9} fill={UI.text} /><circle cx={14.7} cy={10} r={0.9} fill={UI.text} /></svg>
            </div>
            <div style={{ position: "absolute", left: 292, top: ry, width: 520, height: KEY_H, borderRadius: 14, background: UI.key, display: "grid", placeItems: "center", fontFamily: UI.font, fontSize: 36, color: UI.text, boxShadow: "0 3px 0 rgba(0,0,0,0.45)" }}>space</div>
            <div style={{ position: "absolute", right: 24, top: ry, width: 228, height: KEY_H, borderRadius: 14, background: UI.keyDark, display: "grid", placeItems: "center", fontFamily: UI.font, fontSize: 36, color: UI.text, boxShadow: "0 3px 0 rgba(0,0,0,0.45)" }}>return</div>
          </>
        );
      })()}
      {/* popup of the pressed key */}
      {pressedChar && keyRect(pressedChar) && (() => {
        const k = keyRect(pressedChar)!;
        const s = interpolate(pressT, [0, 0.25, 1], [0.85, 1, 1], { extrapolateRight: "clamp" });
        return (
          <div style={{ position: "absolute", left: k.x - 26, top: k.y - 150, width: KEY_W + 52, height: KEY_H + 150, borderRadius: 22, background: "#5E5D59", boxShadow: "0 10px 30px rgba(0,0,0,0.5)", transform: `scale(${s})`, transformOrigin: "50% 100%", display: "flex", justifyContent: "center", paddingTop: 22, fontFamily: UI.font, fontSize: 84, fontWeight: 300, color: UI.text }}>
            {pressedChar}
          </div>
        );
      })()}
    </div>
  );
};

/* ------------------------------------------------------------- composer */

const Thumb: React.FC<{ src: string; size: number; badge?: boolean; play?: boolean }> = ({ src, size, badge, play }) => (
  <div style={{ position: "relative", width: size, height: size, borderRadius: 18, overflow: "visible", flex: "none" }}>
    <Img src={staticFile(src)} style={{ width: size, height: size, objectFit: "cover", borderRadius: 18, border: `1px solid ${UI.line}` }} />
    {play && <div style={{ position: "absolute", left: 8, bottom: 8 }}><IconPlay /></div>}
    {badge && (
      <div style={{ position: "absolute", right: -10, top: -10, width: 34, height: 34, borderRadius: 17, background: "#1A1A19", border: "2px solid #4A4946", display: "grid", placeItems: "center" }}><IconX /></div>
    )}
  </div>
);

export const Composer: React.FC<{
  top: number; text: string; caret: boolean; thumb?: string; placeholder?: string; collapsed?: number; sendPress?: number;
}> = ({ top, text, caret, thumb, placeholder = "Reply to Claude…", collapsed = 0, sendPress = 0 }) => {
  const h = lerp(thumb ? 330 : 200, 124, collapsed);
  const sendScale = 1 - 0.12 * Math.sin(Math.min(1, sendPress) * Math.PI);
  return (
    <div style={{ position: "absolute", left: 28, right: 28, top, height: h, borderRadius: 40, background: UI.surface, border: `1px solid ${UI.line}`, boxShadow: "0 -10px 40px rgba(0,0,0,0.25)", overflow: "hidden" }}>
      {thumb && collapsed < 1 && (
        <div style={{ position: "absolute", left: 30, top: 30, opacity: Math.max(0, 1 - collapsed * 2.5) }}>
          <Thumb src={thumb} size={150} badge play />
        </div>
      )}
      <div style={{ position: "absolute", left: lerp(36, 92, collapsed), right: 36, bottom: lerp(98, 34, collapsed), fontFamily: UI.font, fontSize: 40, color: text ? UI.text : UI.faint, display: "flex", alignItems: "center", whiteSpace: "nowrap" }}>
        {text || (collapsed > 0.5 ? placeholder : "")}
        {caret && <div style={{ width: 3, height: 48, background: UI.orange, marginLeft: 3, borderRadius: 2 }} />}
      </div>
      <div style={{ position: "absolute", left: 22, right: 22, bottom: lerp(18, 30, collapsed), height: 70, display: "flex", alignItems: "center", gap: 22, opacity: 1 }}>
        <IconPlus />
        {collapsed < 0.5 && <IconSliders />}
        <div style={{ flex: 1 }} />
        <IconMic />
        <div style={{ width: 70, height: 70, borderRadius: 20, background: text || collapsed < 0.5 ? UI.send : "#4A4946", display: "grid", placeItems: "center", transform: `scale(${sendScale})` }}>
          <IconArrowUp />
        </div>
      </div>
    </div>
  );
};

/* ------------------------------------------------------------- slash menu */

export const SlashMenu: React.FC<{ top: number; cmd: string; desc: string; t: number }> = ({ top, cmd, desc, t }) => (
  <div style={{ position: "absolute", left: 28, right: 28, top, height: 128, borderRadius: 30, background: "#2E2E2C", border: `1px solid ${UI.line}`, padding: "24px 34px", opacity: t, transform: `translateY(${(1 - t) * 24}px) scale(${0.97 + 0.03 * t})`, transformOrigin: "50% 100%" }}>
    <div style={{ fontFamily: UI.font, fontSize: 38, color: UI.text, fontWeight: 500 }}>/{cmd}</div>
    <div style={{ fontFamily: UI.font, fontSize: 26, color: UI.muted, marginTop: 8 }}>{desc}</div>
  </div>
);

/* ------------------------------------------------------------- status */

export const Status: React.FC<{ text: string; frame: number; top: number; t: number }> = ({ text, frame, top, t }) => {
  const sweep = ((frame * 2.2) % 160) - 30;
  return (
    <div style={{ position: "absolute", left: 50, top, display: "flex", alignItems: "center", gap: 18, opacity: t, transform: `translateY(${(1 - t) * 16}px)` }}>
      <Asterisk size={44} rot={frame * 7} />
      <div style={{ fontFamily: UI.font, fontSize: 34, fontWeight: 500, backgroundImage: `linear-gradient(100deg, ${UI.muted} ${sweep - 30}%, #F5F4EF ${sweep}%, ${UI.muted} ${sweep + 30}%)`, WebkitBackgroundClip: "text", backgroundClip: "text", color: "transparent", whiteSpace: "nowrap" }}>
        {text}
      </div>
    </div>
  );
};

/* ------------------------------------------------------------- the beat */

const CARD = { x: 52, y: 470, w: 640, h: 1138 };

export const ChatBeat: React.FC<{
  cmd: string;
  desc: string;
  thumb?: string;
  fx?: string;
  card?: React.ReactNode;
  greeting?: string;
  status?: string;
  fxStart?: number;
  shift?: number;
}> = ({ cmd, desc, thumb, fx, card, greeting, status, fxStart = 0, shift = 0 }) => {
  const f = useCurrentFrame();
  const T = beatTimes(cmd, shift);
  const full = "/" + cmd;

  // typing, with a human cadence
  const ct = charTimes(cmd);
  const n = ct.filter((t) => f >= t).length;
  const typed = f < T.SEND + 2 ? (f < TYPE_START ? "" : "/" + cmd.slice(0, n)) : "";
  const idx = n; // next key to be pressed
  const lastAt = n > 0 ? ct[n - 1] : TYPE_START;
  const pressT = Math.min(1, (f - lastAt) / 2.2);
  const pressing = n > 0 && f - lastAt < 2.2 && f < T.SEND ? cmd[n - 1] : null;
  void idx;

  // after send
  const drop = p(f, T.SEND + 2, T.SEND + 12, QUINT_INOUT);
  const msgIn = p(f, T.SEND + 2, T.SEND + 14, EXPO_OUT);
  const statusIn = p(f, T.STATUS, T.STATUS + 8);
  const cardIn = p(f, T.CARD, T.CARD + 10, EXPO_OUT);
  const reveal = p(f, T.CARD + 2, T.CARD_CLEAR, Easing_inout);
  const zoom = p(f, T.ZOOM, T.ZOOM_END, QUINT_INOUT);

  const CH = thumb ? 330 : 200;
  const composerTop = lerp(KB_TOP - CH - 22, 1920 - 124 - 40, drop);
  const menuT = f < T.SEND + 2 ? p(f, ct[0], ct[0] + 7) : 1 - p(f, T.SEND + 1, T.SEND + 6);

  // card rect -> full screen
  const cx = lerp(CARD.x, 0, zoom);
  const cy = lerp(CARD.y, 0, zoom);
  const cw = lerp(CARD.w, 1080, zoom);
  const ch = lerp(CARD.h, 1920, zoom);
  const radius = lerp(34, 0, zoom);
  const dot = lerp(0, 13, reveal);
  // zoom blur: proportional to how fast the card is growing, zero when it lands
  const zv = Math.abs(p(f + 0.5, T.ZOOM, T.ZOOM_END, QUINT_INOUT) - p(f - 0.5, T.ZOOM, T.ZOOM_END, QUINT_INOUT));
  const zBlur = Math.min(7, zv * 60);
  const uiFade = 1 - p(f, T.ZOOM + 2, T.ZOOM + 10);

  return (
    <AbsoluteFill style={{ background: UI.bg, overflow: "hidden" }}>
      <div style={{ position: "absolute", inset: 0, opacity: uiFade }}>
        <TopBar />
        {/* message at the top right */}
        {f >= T.SEND + 2 && (
          <div style={{ position: "absolute", right: 40, top: 160, display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 18, opacity: msgIn, transform: `translateY(${(1 - msgIn) * 240}px) scale(${0.9 + 0.1 * msgIn})`, transformOrigin: "100% 100%" }}>
            {thumb && <Thumb src={thumb} size={196} play />}
            <div style={{ background: UI.pill, borderRadius: 30, padding: "16px 28px", fontFamily: UI.font, fontSize: 38, color: UI.orange }}>{full}</div>
          </div>
        )}
        {f >= T.STATUS && <Status text={status ?? `Editing with ${cmd}…`} frame={f} top={402} t={statusIn} />}
        {greeting && (
          <div style={{ position: "absolute", left: 0, right: 0, top: 470, display: "flex", flexDirection: "column", alignItems: "center", gap: 26, opacity: 1 - drop }}>
            <Asterisk size={86} rot={f * 1.5} />
            <div style={{ fontFamily: "AG, serif", fontSize: 66, color: UI.text, letterSpacing: -0.5 }}>{greeting}</div>
          </div>
        )}
        <SlashMenu top={KB_TOP - CH - 22 - 150} cmd={cmd} desc={desc} t={Math.max(0, menuT) * (1 - drop)} />
        <Composer
          top={composerTop}
          text={typed}
          caret={f < T.SEND + 2 && Math.floor(f / 8) % 2 === 0}
          thumb={drop < 1 ? thumb : undefined}
          collapsed={drop}
          sendPress={p(f, T.SEND, T.SEND + 5, (x) => x)}
        />
        <Keyboard typed={typed} pressedChar={pressing} pressT={pressT} y={drop * 760} />
      </div>

      {/* result card */}
      {f >= T.CARD && (
        <div style={{ position: "absolute", left: cx, top: cy, width: cw, height: ch, borderRadius: radius, overflow: "hidden", background: "#111", opacity: cardIn, transform: `translateY(${(1 - cardIn) * 30}px)`, boxShadow: zoom < 1 ? "0 20px 60px rgba(0,0,0,0.45)" : "none", border: zoom < 0.9 ? `1px solid ${UI.line}` : "none" }}>
          <div style={{ position: "absolute", inset: 0, WebkitMaskImage: reveal < 1 ? `radial-gradient(circle, #000 ${dot}px, transparent ${dot + 1}px)` : "none", WebkitMaskSize: "22px 22px", maskImage: reveal < 1 ? `radial-gradient(circle, #000 ${dot}px, transparent ${dot + 1}px)` : "none", maskSize: "22px 22px" }}>
            <Sequence from={T.CARD} layout="none">
              <div style={{ position: "absolute", left: 0, top: 0, width: 1080, height: 1920, transform: `scale(${cw / 1080})`, transformOrigin: "0 0" }}>
               <div style={{ position: "absolute", inset: 0, filter: zBlur > 0.3 ? `blur(${zBlur.toFixed(2)}px)` : undefined }}>
                {card ?? (fx && <OffthreadVideo src={staticFile(fx)} muted startFrom={fxStart} style={{ width: 1080, height: 1920 }} />)}
               </div>
              </div>
            </Sequence>
          </div>
          {reveal < 1 && <div style={{ position: "absolute", inset: 0, background: `rgba(38,38,36,${0.55 * (1 - reveal)})` }} />}
        </div>
      )}
    </AbsoluteFill>
  );
};

const Easing_inout = (t: number) => (t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2);
